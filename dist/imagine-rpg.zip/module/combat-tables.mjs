// @START (CODE)
// @MARKER COMBAT TABLES
//==================================================================================================================
// GENERATED FILE -- do not edit by hand.
// Produced by tools/extract/extract_combat_tables.py from the original Roll20 sheet-worker.
// Regenerate rather than editing, or this will drift from his sheet.
//==================================================================================================================

// @MARKER ATTACK CHARTS
// From attackSkillValuesDetails (sheet-worker.js:82108). The d20 attack roll, after modifiers, is
// read against these to find both whether the blow lands and where. Each value is the LOWEST
// roll that reaches that result -- "19+" and "9-11" are read by their first number, exactly as
// his code does with parseInt. "-" means the result cannot occur at that skill.
//              0          1         2          3         4           5          6           7         8          9           10
//              MissHigh   HitHigh   MissLeft   HitLeft   HitCenter   HitRight   MissRight   HitLow    MissLow    MissShort   CalledShot
export const ATTACK_CHARTS = {
	"Beginner":    ["9-11", "17", "6-8", "16", "19+", "18", "12-14", "15", "3-5", "1-2", "20"],
	"Novice":      ["7-9", "15", "4-6", "14", "17+", "16", "10-12", "13", "1-3", "-", "19"],
	"Intermediate": ["6-7", "13", "3-5", "12", "15+", "14", "8-10", "11", "1-2", "-", "18"],
	"Advanced":    ["5-6", "11", "3-4", "10", "13+", "12", "7-8", "9", "1-2", "-", "17"],
	"Expert":      ["4", "9", "2-3", "8", "11+", "10", "5-6", "7", "1", "-", "16"],
	"Master":      ["3", "7", "2", "6", "9+", "8", "4", "5", "1", "-", "15"],
	"Grandmaster": ["1", "4", "1", "3", "6+", "5", "1", "2", "1", "-", "14"],
	"None":        ["-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-"],
};

// The skill levels in order, weakest first. Weapon Lore reads the chart one step up.
export const ATTACK_SKILL_ORDER = ["Beginner", "Novice", "Intermediate", "Advanced", "Expert", "Master", "Grandmaster"];

// @MARKER BODY CHARTS
// From getBodyList (sheet-worker.js:175002). Each body type is a list of areas written as
// "Name(Type:xMultiplier)". An area's Endurance is the character's Endurance times its
// multiplier, rounded up. His evoke mutations (extra limbs, wings, tails) add further
// areas on top of these and are not reflected here.
export const BODY_CHARTS = {
	"Amorphous/Sectional": "Vital Area(Vital:x1),Non-Vital(Limb:x1)",
	"Arachen": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Abdomen(Vital:x2),Underbelly(Vital:x1),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Left Fore Shin(Limb:x1/2),Right Fore Shin(Limb:x1/2),Left Fore Foot(Limb:x1/2),Right Fore Foot(Limb:x1/2),Left Mid Leg(Limb:x1),Right Mid Leg(Limb:x1),Left Mid Shin(Limb:x1/2),Right Mid Shin(Limb:x1/2),Left Mid Foot(Limb:x1/2),Right Mid Foot(Limb:x1/2),Left Hind Leg(Limb:x1),Right Hind Leg(Limb:x1),Left Hind Shin(Limb:x1/2),Right Hind Shin(Limb:x1/2),Left Hind Foot(Limb:x1/2),Right Hind Foot(Limb:x1/2)",
	"Bird": "Head(Vital:x1),Neck(Vital:x1/2),Upper Torso(Vital:x2),Lower Torso(Vital:x2),Left Wing(Wing:x1),Right Wing(Wing:x1),Left Leg(Limb:x1),Right Leg(Limb:x1),Left Claw(Limb:x1/2),Right Claw(Limb:x1/2),Tail(Limb:x1/2)",
	"Brachara": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Mid Torso(Vital:x1),Left Mid Arm(Limb:x1),Right Mid Arm(Limb:x1),Left Mid Forearm(Limb:x1/2),Right Mid Forearm(Limb:x1/2),Left Pincer(Limb:x1/2),Right Pincer(Limb:x1/2),Abdomen(Vital:x2),Underbelly(Vital:x1),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Left Fore Shin(Limb:x1/2),Right Fore Shin(Limb:x1/2),Left Fore Foot(Limb:x1/2),Right Fore Foot(Limb:x1/2),Left Mid Leg(Limb:x1),Right Mid Leg(Limb:x1),Left Mid Shin(Limb:x1/2),Right Mid Shin(Limb:x1/2),Left Mid Foot(Limb:x1/2),Right Mid Foot(Limb:x1/2),Left Hind Leg(Limb:x1),Right Hind Leg(Limb:x1),Left Hind Shin(Limb:x1/2),Right Hind Shin(Limb:x1/2),Left Hind Foot(Limb:x1/2),Right Hind Foot(Limb:x1/2)",
	"Centaur": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Underbelly(Vital:x1),Forequarters(Vital:x2),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Left Fore Shin(Limb:x1/2),Right Fore Shin(Limb:x1/2),Hindquarters(Vital:x2),Left Hindleg(Limb:x1),Right Hindleg(Limb:x1),Left Hind Shin(Limb:x1/2),Right Hind Shin(Limb:x1/2),Tail(Limb:x1/2)",
	"Crustacean": "Cephalothorax/Head(Vital:x2),Left Claw(Limb:x2),Right Claw(Limb:x2),Left Foreleg(Limb:x1/2),Right Foreleg(Limb:x1/2),Left Frontal Midleg(Limb:x1/2),Right Frontal Midleg(Limb:x1/2),Left Back Hindleg(Limb:x1/2),Right Back Hindleg(Limb:x1/2),Left Hindleg(Limb:x1/2),Right Hindleg(Limb:x1/2),Abdomen/Tail(Vital:x1)",
	"Fish": "Head(Vital:x1),Main Trunk(Vital:x2),Left Fin(Limb:x1/2),Right Fin(Limb:x1/2),Dorsal Fin(Limb:x1/2),Rear Trunk(Vital:x2),Fluke/Tail(Limb:x1)",
	"Floating Orb": "Orb(Vital:x2),Eye(Other:x1),Left Upper Tentacle(Limb:x1/2),Left Mid Tentacle(Limb:x1/2),Left Lower Tentacle(Limb:x1/2),Right Upper Tentacle(Limb:x1/2),Right Mid Tentacle(Limb:x1/2),Right Lower Tentacle(Limb:x1/2)",
	"Giant Insect": "Head(Vital:x1),Prothorax(Vital:x2),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Mesathorax(Vital:x2),Left Midleg(Limb:x1),Right Midleg(Limb:x1),Metathorax(Vital:x2),Left Hindleg(Limb:x1),Right Hindleg(Limb:x1)",
	"Giant Insect(Wings)": "Head(Vital:x1),Prothorax(Vital:x2),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Mesathorax(Vital:x2),Left Midleg(Limb:x1),Right Midleg(Limb:x1),Metathorax(Vital:x2),Left Hindleg(Limb:x1),Right Hindleg(Limb:x1),Left Lower Wing(Wing:x1/2),Right Lower Wing(Wing:x1/2),Left Upper Wing(Wing:x1/2),Right Upper Wing(Wing:x1/2)",
	"Giant Spider": "Cephalothorax/Head(Vital:x1),Abdomen(Vital:x2),Left Front Foreleg(Limb:x1),Right Front Foreleg(Limb:x1),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Left Hindleg(Limb:x1),Right Hindleg(Limb:x1),Left Back Hindleg(Limb:x1),Right Back Hindleg(Limb:x1)",
	"Humanoid": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2)",
	"Humanoid(Fish Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Finned Tail(Limb:x2)",
	"Humanoid(Hooves)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Hoof(Limb:x1/2),Right Hoof(Limb:x1/2)",
	"Humanoid(Hooves/Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Hoof(Limb:x1/2),Right Hoof(Limb:x1/2),Tail(Limb:x1/2)",
	"Humanoid(Hooves/Large Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Hoof(Limb:x1/2),Right Hoof(Limb:x1/2),Tail(Limb:x1)",
	"Humanoid(Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Tail(Limb:x1/2)",
	"Humanoid(Large Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Tail(Limb:x1)",
	"Humanoid(Wings)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Left Wing(Wing:x1),Right Wing(Wing:x1)",
	"Humanoid(Wings/Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Left Wing(Wing:x1),Right Wing(Wing:x1),Tail(Limb:x1/2)",
	"Humanoid(Wings/Large Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Left Wing(Wing:x1),Right Wing(Wing:x1),Tail(Limb:x1)",
	"Humanoid(Hooves/Wings/Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Hoof(Limb:x1/2),Right Hoof(Limb:x1/2),Left Wing(Wing:x1),Right Wing(Wing:x1),Tail(Limb:x1/2)",
	"Humanoid(Hooves/Wings/Large Tail)": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Hoof(Limb:x1/2),Right Hoof(Limb:x1/2),Left Wing(Wing:x1),Right Wing(Wing:x1),Tail(Limb:x1)",
	"Insectoid": "Head(Vital:x1),Thorax(Vital:x2),Left Upper Arm(Limb:x1),Right Upper Arm(Limb:x1),Left Upper Forearm(Limb:x1),Right Upper Forearm(Limb:x1),Left Upper Hand(Limb:x1/2),Right Upper Hand(Limb:x1/2),Left Mid Arm(Limb:x1),Right Mid Arm(Limb:x1),Left Mid Forearm(Limb:x1),Right Mid Forearm(Limb:x1),Left Mid Claw/Hand(Limb:x1/2),Right Mid Claw/Hand(Limb:x1/2),Left Leg(Limb:x1),Right Leg(Limb:x1),Left Lower Leg(Limb:x1),Right Lower Leg(Limb:x1),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Abdomen(Vital:x2)",
	"Insectoid(Wings)": "Head(Vital:x1),Thorax(Vital:x2),Left Upper Arm(Limb:x1),Right Upper Arm(Limb:x1),Left Upper Forearm(Limb:x1),Right Upper Forearm(Limb:x1),Left Upper Hand(Limb:x1/2),Right Upper Hand(Limb:x1/2),Left Mid Arm(Limb:x1),Right Mid Arm(Limb:x1),Left Mid Forearm(Limb:x1),Right Mid Forearm(Limb:x1),Left Mid Claw/Hand(Limb:x1/2),Right Mid Claw/Hand(Limb:x1/2),Left Leg(Limb:x1),Right Leg(Limb:x1),Left Lower Leg(Limb:x1),Right Lower Leg(Limb:x1),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Abdomen(Vital:x2),Left Wingcase(Limb:x1),Right Wingcase(Limb:x1),Left Outer Wing(Wing:x1/4),Right Outer Wing(Wing:x1/4),Left Inner Wing(Wing:x1/4),Right Inner Wing(Wing:x1/4)",
	"Insectoid(Wings/Stinger)": "Head(Vital:x1),Thorax(Vital:x2),Left Upper Arm(Limb:x1),Right Upper Arm(Limb:x1),Left Upper Forearm(Limb:x1),Right Upper Forearm(Limb:x1),Left Upper Hand(Limb:x1/2),Right Upper Hand(Limb:x1/2),Left Mid Arm(Limb:x1),Right Mid Arm(Limb:x1),Left Mid Forearm(Limb:x1),Right Mid Forearm(Limb:x1),Left Mid Claw/Hand(Limb:x1/2),Right Mid Claw/Hand(Limb:x1/2),Left Leg(Limb:x1),Right Leg(Limb:x1),Left Lower Leg(Limb:x1),Right Lower Leg(Limb:x1),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Abdomen(Vital:x2),Left Wingcase(Limb:x1),Right Wingcase(Limb:x1),Left Outer Wing(Wing:x1/4),Right Outer Wing(Wing:x1/4),Left Inner Wing(Wing:x1/4),Right Inner Wing(Wing:x1/4),Stinger(Limb:x1/2)",
	"Mollusk": "Head/Foot(Vital:x1),Limb1(Limb:x1),Limb2(Limb:x1),Limb3(Limb:x1),Limb4(Limb:x1),Limb5(Limb:x1),Limb6(Limb:x1),Limb7(Limb:x1),Limb8(Limb:x1),Visceral Mass(Vital:x2)",
	"Mollusk(No Limbs)": "Head/Foot(Vital:x1),Visceral Mass(Vital:x2)",
	"Plant": "Stem(Other:x1),Leaves(Other:x1/2),Roots(Other:x1/2)",
	"Quadruped": "Head(Vital:x1),Neck(Vital:x1),Forequarters(Vital:x2),Right Foreleg(Limb:x1/2),Left Foreleg(Limb:x1/2),Right Forefoot(Limb:x1/2),Left Forefoot(Limb:x1/2),Underbelly(Vital:x1),Hindquarters(Vital:x2),Right Hindleg(Limb:x1/2),Left Hindleg(Limb:x1/2),Right Hindfoot(Limb:x1/2),Left Hindfoot(Limb:x1/2)",
	"Quadruped(Tail)": "Head(Vital:x1),Neck(Vital:x1),Forequarters(Vital:x2),Right Foreleg(Limb:x1/2),Left Foreleg(Limb:x1/2),Right Forefoot(Limb:x1/2),Left Forefoot(Limb:x1/2),Underbelly(Vital:x1),Hindquarters(Vital:x2),Right Hindleg(Limb:x1/2),Left Hindleg(Limb:x1/2),Right Hindfoot(Limb:x1/2),Left Hindfoot(Limb:x1/2),Tail(Limb:x1/2)",
	"Quadruped(Wings)": "Head(Vital:x1),Neck(Vital:x1),Forequarters(Vital:x2),Right Foreleg(Limb:x1/2),Left Foreleg(Limb:x1/2),Right Forefoot(Limb:x1/2),Left Forefoot(Limb:x1/2),Underbelly(Vital:x1),Hindquarters(Vital:x2),Right Hindleg(Limb:x1/2),Left Hindleg(Limb:x1/2),Right Hindfoot(Limb:x1/2),Left Hindfoot(Limb:x1/2),Right Wing(Limb:x1/2),Left Wing(Limb:x1/2)",
	"Quadruped(Tail/Wings)": "Head(Vital:x1),Neck(Vital:x1),Forequarters(Vital:x2),Right Foreleg(Limb:x1/2),Left Foreleg(Limb:x1/2),Right Forefoot(Limb:x1/2),Left Forefoot(Limb:x1/2),Underbelly(Vital:x1),Hindquarters(Vital:x2),Right Hindleg(Limb:x1/2),Left Hindleg(Limb:x1/2),Right Hindfoot(Limb:x1/2),Left Hindfoot(Limb:x1/2),Right Wing(Limb:x1/2),Left Wing(Limb:x1/2),Tail(Limb:x1/2)",
	"Reptile": "Head(Vital:x1),Neck(Vital:x1),Forequarters(Vital:x2),Right Foreleg(Limb:x1/2),Left Foreleg(Limb:x1/2),Right Foreclaw(Limb:x1/2),Left Foreclaw(Limb:x1/2),Underbelly(Vital:x1),Hindquarters(Vital:x2),Right Hindleg(Limb:x1/2),Left Hindleg(Limb:x1/2),Right Hindclaw(Limb:x1/2),Left Hindclaw(Limb:x1/2),Upper Tail(Limb:x1),Lower Tail(Limb:x1/2)",
	"Saurian": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Torso(Vital:x2),Left Thigh(Limb:x1),Right Thigh(Limb:x1),Left Shin(Limb:x1/2),Right Shin(Limb:x1/2),Left Foot(Limb:x1/2),Right Foot(Limb:x1/2),Tail(Limb:x2)",
	"Sea Mammal": "Head(Vital:x1),Main Trunk(Vital:x2),Left Flipper(Limb:x1/2),Right Flipper(Limb:x1/2),Rear Trunk(Vital:x2),Fluke/Tail(Limb:x1)",
	"Sea Mammal(Dorsal Finned)": "Head(Vital:x1),Main Trunk(Vital:x2),Left Flipper(Limb:x1/2),Right Flipper(Limb:x1/2),Dorsal Fin(Limb:x1/2),Rear Trunk(Vital:x2),Fluke/Tail(Limb:x1)",
	"Sea Mammal(Tusk)": "Head(Vital:x1),Main Trunk(Vital:x2),Left Flipper(Limb:x1/2),Right Flipper(Limb:x1/2),Rear Trunk(Vital:x2),Fluke/Tail(Limb:x1),Tusk(Limb:x1/2)",
	"Segmented Worm": "Maw(Vital:x1),Brain Segment1(Vital:x1),Left Foot1(Limb:x1/2),Right Foot1(Limb:x1/2),Heart Segment1(Vital:x1),Left Foot2(Limb:x1/2),Right Foot2(Limb:x1/2),Body Segment1(Vital:x1),Left Foot3(Limb:x1/2),Right Foot3(Limb:x1/2),Body Segment2(Vital:x1),Left Foot4(Limb:x1/2),Right Foot4(Limb:x1/2),Brain Segment2(Vital:x1),Left Foot5(Limb:x1/2),Right Foot5(Limb:x1/2),Heart Segment2(Vital:x1),Left Foot6(Limb:x1/2),Right Foot6(Limb:x1/2),Body Segment3(Vital:x1),Left Foot7(Limb:x1/2),Right Foot7(Limb:x1/2),Body Segment4(Vital:x1),Left Foot8(Limb:x1/2),Right Foot8(Limb:x1/2),Brain Segment3(Vital:x1),Left Foot9(Limb:x1/2),Right Foot9(Limb:x1/2),Heart Segment3(Vital:x1),Left Foot10(Limb:x1/2),Right Foot10(Limb:x1/2),Body Segment5(Vital:x1),Left Foot11(Limb:x1/2),Right Foot11(Limb:x1/2),Body Segment6(Vital:x1),Left Foot12(Limb:x1/2),Right Foot12(Limb:x1/2),Body Segment7(Vital:x1),Left Foot12(Limb:x1/2),Right Foot12(Limb:x1/2),Heart Segment4(Vital:x1),Left Foot13(Limb:x1/2),Right Foot13(Limb:x1/2),Body Segment8(Vital:x1),Left Foot14(Limb:x1/2),Right Foot14(Limb:x1/2),Body Segment9(Vital:x1),Left Foot15(Limb:x1/2),Right Foot15(Limb:x1/2),Body Segment10(Vital:x1),Left Foot16(Limb:x1/2),Right Foot16(Limb:x1/2)",
	"Scethen": "Head(Vital:x1),Neck(Vital:x1/2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Upper Torso(Vital:x2),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Mid Torso(Vital:x1),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Abdomen(Vital:x2),Underbelly(Vital:x1),Left Foreleg(Limb:x1),Right Foreleg(Limb:x1),Left Fore Shin(Limb:x1/2),Right Fore Shin(Limb:x1/2),Left Fore Foot(Limb:x1/2),Right Fore Foot(Limb:x1/2),Left Mid Leg(Limb:x1),Right Mid Leg(Limb:x1),Left Mid Shin(Limb:x1/2),Right Mid Shin(Limb:x1/2),Left Mid Foot(Limb:x1/2),Right Mid Foot(Limb:x1/2),Left Hind Leg(Limb:x1),Right Hind Leg(Limb:x1),Left Hind Shin(Limb:x1/2),Right Hind Shin(Limb:x1/2),Left Hind Foot(Limb:x1/2),Right Hind Foot(Limb:x1/2),Segment Tail(Limb:x1),Barb(Limb:x1/2)",
	"Small": "Body(Vital:x1),Limbs(Limb:x1/2)",
	"Snake": "Head(Vital:x1),Upper Length(Vital:x2),Lower Length(Vital:x1),Tail(Limb:x1/2)",
	"Snake(Arms)": "Head(Vital:x1),Upper Length(Vital:x2),Left Shoulder(Limb:x1),Right Shoulder(Limb:x1),Left Arm(Limb:x1),Right Arm(Limb:x1),Left Forearm(Limb:x1/2),Right Forearm(Limb:x1/2),Left Hand(Limb:x1/2),Right Hand(Limb:x1/2),Lower Length(Vital:x1),Tail(Limb:x1/2)",
	"Tiny": "Entire Body(Vital:x1)",
	"Tree": "Low Trunk(Vital:x3),Trunk(Vital:x2),Roots(Vital:x1),Limbs(Limb:x1),Branches(Limb:x1/2)",
};

// @MARKER ARMOUR BLOCKING
// From armorblockingdict. Incoming damage is compared with the total armour at the struck area
// and falls into one of four bands. The Smashing row is the book's (p.189), half through between
// half and full armour, on his bug report 0.22.7:1 -- the one cell where his dictionary differed
// from his table (BLOCKING_CORRECTIONS in the generator). For that band's value:
//     negative  ->  damage + (total armour x value)     armour subtracts a fraction of itself
//     positive  ->  damage x value                      only that share gets through
//     zero      ->  no damage at all
//                        0            1             2            3
//                        UnderQuarter QuarterToHalf HalfToFull   OverArmour
export const ARMOR_BLOCKING = {
	"Cutting":         [0, 0, 0.25, -0.5],
	"Thrusting":       [0, 0, 0.25, -0.5],
	"Piercing":        [0, 0, 0.25, -0.25],
	"Smashing":        [0, 0, 0.5, -0.5],
	"Crushing":        [0, -0.25, -0.25, -0.25],
	"Constricting":    [0, 0, 0, -1],
	"Force":           [-1, -1, -1, -1],
	"Poison":          [0, 0, 0, 0],
	"Disease":         [0, 0, 0, 0],
	"Light":           [-1, -1, -1, -1],
	"Sonic":           [-1, -1, -1, -1],
	"Frost":           [-1, -1, -1, -1],
	"Kinetic":         [-1, -1, -1, -1],
	"Flame":           [-1, -1, -1, -1],
	"Electricity":     [-1, -1, -1, -1],
	"Acid":            [-1, -1, -1, -1],
	"Aura/Divine":     [-1, -1, -1, -1],
	"Life/Death":      [-1, -1, -1, -1],
	"Obliteration":    [-1, -1, -1, -1],
	"Other":           [-1, -1, -1, -1],
};

// @MARKER DAMAGE TYPE SPELLINGS
// A creature's attack, a spell and a weapon mode do not all spell a damage type the way the
// armour tables do: his creature select (CREATURE_DAMAGE_TYPES, creature-tables.mjs) offers "Aura",
// "Divine", "Holy", "Unholy", "Death", "Life" and "Draining", where ARMOR_BLOCKING and ENDURED_BY
// know only "Aura/Divine", "Life/Death" and "Other". Found in the quality pass of 2026-10-07: a
// "Death" bite matched no row, the damage dialog fell back to its FIRST option, Cutting, and a
// 30-point bite against armour 20 landed 20 instead of 10. Every lookup goes through
// getBlockingDamageType (combat-rules.mjs), which reads this; a spelling not here is itself.
// Not from his sheet: kept in the generator (BLOCKING_TYPE_OF), not read from it.
//   as written       as the armour tables have it
export const BLOCKING_TYPE_OF = {
	"Aura":            "Aura/Divine",
	"Divine":          "Aura/Divine",
	"Holy":            "Aura/Divine",
	"Unholy":          "Aura/Divine",
	"Life":            "Life/Death",
	"Death":           "Life/Death",
	"Draining":        "Life/Death",
	"Fire":            "Flame",
	"Cold":            "Frost",
	"Lightning":       "Electricity",
	"Electric":        "Electricity",
};

// @MARKER ARMOUR DEGRADATION
// From armordamagedict. Armour takes (damage / divider) points of damage itself, using the
// divider for the damage's family and the strongest material covering the struck area.
//                           0      1        2       3
//                           Cut    Thrust   Crush   Constrict
export const ARMOR_DAMAGE_DIVIDERS = {
	"Rags":                    [2, 5, 20, 20],
	"Silk":                    [2, 5, 20, 20],
	"Cloth":                   [2, 5, 20, 20],
	"Woven":                   [2, 5, 20, 20],
	"Wool":                    [3, 5, 20, 20],
	"Padding":                 [3, 5, 20, 20],
	"Soft Leather":            [3, 5, 20, 20],
	"Fur":                     [5, 5, 20, 20],
	"Leather":                 [5, 5, 20, 20],
	"Gambeson":                [3, 5, 20, 20],
	"Hard Leather":            [5, 5, 20, 20],
	"Giant Leather":           [5, 5, 5, 5],
	"Copper":                  [5, 5, 20, 20],
	"Studded Leather":         [5, 5, 20, 20],
	"Gambeson/Thick":          [3, 5, 20, 20],
	"Brass":                   [10, 10, 20, 20],
	"Wood":                    [10, 10, 20, 20],
	"Lacquered Wood":          [10, 10, 20, 20],
	"Gambeson/Heavy":          [3, 5, 20, 20],
	"Bolted Leather":          [5, 5, 20, 20],
	"Ring Mail":               [10, 10, 20, 20],
	"Bone":                    [10, 10, 5, 20],
	"Heavy Bone":              [15, 10, 5, 20],
	"Giant Chitin":            [10, 15, 10, 10],
	"Bronze":                  [15, 10, 5, 20],
	"Chain":                   [15, 10, 15, 20],
	"Heavy Chain":             [15, 10, 15, 20],
	"Banded Chain":            [15, 10, 15, 20],
	"Scale":                   [15, 10, 15, 20],
	"Heavy Scale":             [15, 10, 15, 20],
	"Giant Scales":            [15, 20, 15, 20],
	"Plate":                   [20, 25, 20, 25],
	"Laminar":                 [20, 25, 20, 25],
	"Heavy Plate":             [20, 25, 20, 25],
	"Stainless Steel":         [20, 25, 20, 25],
	"Bloodracite":             [20, 25, 20, 25],
	"Pearlacite":              [20, 25, 20, 25],
	"Stone":                   [20, 25, 20, 25],
	"Tempered Plate":          [20, 25, 20, 25],
	"Titanium":                [25, 30, 25, 30],
};

// @MARKER ARMOUR MATERIAL RANK
// From getArmorValue (sheet-worker.js:118903). Higher is stronger. Used to pick which material's
// degradation divider applies when several layers cover one area.
export const ARMOR_MATERIAL_RANK = {
	"Rags":                    1,
	"Silk":                    1,
	"Cloth":                   2,
	"Woven":                   2,
	"Wool":                    3,
	"Padding":                 3,
	"Soft Leather":            4,
	"Fur":                     5,
	"Leather":                 5,
	"Gambeson":                6,
	"Hard Leather":            6,
	"Copper":                  7,
	"Giant Leather":           7,
	"Studded Leather":         8,
	"Brass":                   9,
	"Gambeson/Thick":          9,
	"Wood":                    10,
	"Lacquered Wood":          11,
	"Gambeson/Heavy":          12,
	"Bolted Leather":          12,
	"Ring Mail":               12,
	"Bone":                    13,
	"Heavy Bone":              14,
	"Giant Chitin":            14,
	"Bronze":                  15,
	"Chain":                   15,
	"Heavy Chain":             16,
	"Banded Chain":            17,
	"Scale":                   18,
	"Heavy Scale":             19,
	"Giant Scales":            19,
	"Plate":                   20,
	"Laminar":                 21,
	"Heavy Plate":             22,
	"Stainless Steel":         22,
	"Bloodracite":             23,
	"Pearlacite":              23,
	"Stone":                   23,
	"Tempered Plate":          24,
	"Titanium":                25,
};

// @MARKER ARMOUR COVERAGE BY BODY TYPE
// From getArmorValuesByBodyTypeAndArmor (sheet-worker.js:105929). Which armour slot covers each
// area, for the eight body-type families his code handles. A family matches by substring, so
// "Humanoid" serves every Humanoid variant. Any family absent here -- Bird, Quadruped, Fish
// and the rest -- takes no protection from worn armour, which is what his sheet does too.
//
// Keyed by area NAME rather than by position. His version switches on the area's position in
// the body chart, and two of his branches have drifted out of step with the charts they serve,
// so a position-keyed port would put armour on the wrong limb. See docs/UPSTREAM-ISSUES.md.
export const ARMOR_COVERAGE_BY_BODY_TYPE = {
	"Humanoid": {
		"Head":                    "head",
		"Neck":                    "neck",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Upper Torso":             "torsoUpper",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Mid Torso":               "torsoMid",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
		"Lower Torso":             "torsoLower",
		"Left Thigh":              "thighLeft",
		"Right Thigh":             "thighRight",
		"Left Shin":               "shinLeft",
		"Right Shin":              "shinRight",
		"Left Foot":               "footLeft",
		"Right Foot":              "footRight",
		"Finned Tail":             "thighLeft",
		"Left Hoof":               "footLeft",
		"Right Hoof":              "footRight",
	},
	"Saurian": {
		"Head":                    "head",
		"Neck":                    "neck",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Upper Torso":             "torsoUpper",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Mid Torso":               "torsoMid",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
		"Lower Torso":             "torsoLower",
		"Left Thigh":              "thighLeft",
		"Right Thigh":             "thighRight",
		"Left Shin":               "shinLeft",
		"Right Shin":              "shinRight",
		"Left Foot":               "footLeft",
		"Right Foot":              "footRight",
		"Tail":                    "tail",
	},
	"Insectoid": {
		"Head":                    "head",
		"Thorax":                  "torsoUpper",
		"Left Upper Arm":          "armLeft",
		"Right Upper Arm":         "armRight",
		"Left Upper Forearm":      "forearmLeft",
		"Right Upper Forearm":     "forearmRight",
		"Left Upper Hand":         "handLeft",
		"Right Upper Hand":        "handRight",
		"Left Mid Arm":            "armLeft",
		"Right Mid Arm":           "armRight",
		"Left Mid Forearm":        "forearmLeft",
		"Right Mid Forearm":       "forearmRight",
		"Left Mid Claw/Hand":      "handLeft",
		"Right Mid Claw/Hand":     "handRight",
		"Left Leg":                "thighLeft",
		"Right Leg":               "thighRight",
		"Left Lower Leg":          "shinLeft",
		"Right Lower Leg":         "shinRight",
		"Left Foot":               "footLeft",
		"Right Foot":              "footRight",
		"Abdomen":                 "torsoLower",
	},
	"Snake": {
		"Head":                    "head",
		"Upper Length":            "torsoUpper",
		"Lower Length":            "torsoLower",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
	},
	"Centaur": {
		"Head":                    "head",
		"Neck":                    "neck",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Upper Torso":             "torsoUpper",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
		"Forequarters":            "torsoLower",
		"Left Foreleg":            "torsoLower",
		"Right Foreleg":           "torsoLower",
		"Hindquarters":            "torsoLower",
		"Left Hindleg":            "torsoLower",
		"Right Hindleg":           "torsoLower",
	},
	"Arachen": {
		"Head":                    "head",
		"Neck":                    "neck",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Upper Torso":             "torsoUpper",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Mid Torso":               "torsoMid",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
		"Abdomen":                 "torsoLower",
		"Left Foreleg":            "torsoLower",
		"Right Foreleg":           "torsoLower",
		"Left Mid Leg":            "torsoLower",
		"Right Mid Leg":           "torsoLower",
		"Left Hind Leg":           "torsoLower",
		"Right Hind Leg":          "torsoLower",
	},
	"Scethen": {
		"Head":                    "head",
		"Neck":                    "neck",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Upper Torso":             "torsoUpper",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Mid Torso":               "torsoMid",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
		"Abdomen":                 "torsoLower",
		"Left Foreleg":            "torsoLower",
		"Right Foreleg":           "torsoLower",
		"Left Mid Leg":            "torsoLower",
		"Right Mid Leg":           "torsoLower",
		"Left Hind Leg":           "torsoLower",
		"Right Hind Leg":          "torsoLower",
	},
	"Brachara": {
		"Head":                    "head",
		"Neck":                    "neck",
		"Left Shoulder":           "shoulderLeft",
		"Right Shoulder":          "shoulderRight",
		"Upper Torso":             "torsoUpper",
		"Left Arm":                "armLeft",
		"Right Arm":               "armRight",
		"Left Forearm":            "forearmLeft",
		"Right Forearm":           "forearmRight",
		"Left Hand":               "handLeft",
		"Right Hand":              "handRight",
		"Mid Torso":               "torsoMid",
		"Left Mid Arm":            "armLeft",
		"Right Mid Arm":           "armRight",
		"Left Mid Forearm":        "forearmLeft",
		"Right Mid Forearm":       "forearmRight",
		"Abdomen":                 "torsoLower",
		"Left Foreleg":            "torsoLower",
		"Right Foreleg":           "torsoLower",
		"Left Mid Leg":            "torsoLower",
		"Right Mid Leg":           "torsoLower",
		"Left Hind Leg":           "torsoLower",
		"Right Hind Leg":          "torsoLower",
	},
};

// Areas that take armour only from a particular item -- a Centaur's quarters and legs are
// covered by barding and by nothing else.
export const ARMOR_REQUIRES_ITEM = {
	"Centaur": {
		"Forequarters":            "Centaur Barding",
		"Left Foreleg":            "Centaur Barding",
		"Right Foreleg":           "Centaur Barding",
		"Hindquarters":            "Centaur Barding",
		"Left Hindleg":            "Centaur Barding",
		"Right Hindleg":           "Centaur Barding",
	},
	"Arachen": {
		"Abdomen":                 "Insectaur Barding",
		"Left Foreleg":            "Insectaur Barding",
		"Right Foreleg":           "Insectaur Barding",
		"Left Mid Leg":            "Insectaur Barding",
		"Right Mid Leg":           "Insectaur Barding",
		"Left Hind Leg":           "Insectaur Barding",
		"Right Hind Leg":          "Insectaur Barding",
	},
	"Scethen": {
		"Abdomen":                 "Insectaur Barding",
		"Left Foreleg":            "Insectaur Barding",
		"Right Foreleg":           "Insectaur Barding",
		"Left Mid Leg":            "Insectaur Barding",
		"Right Mid Leg":           "Insectaur Barding",
		"Left Hind Leg":           "Insectaur Barding",
		"Right Hind Leg":          "Insectaur Barding",
	},
	"Brachara": {
		"Abdomen":                 "Insectaur Barding",
		"Left Foreleg":            "Insectaur Barding",
		"Right Foreleg":           "Insectaur Barding",
		"Left Mid Leg":            "Insectaur Barding",
		"Right Mid Leg":           "Insectaur Barding",
		"Left Hind Leg":           "Insectaur Barding",
		"Right Hind Leg":          "Insectaur Barding",
	},
};

// @MARKER SHIELD COVERAGE BY HANDEDNESS
// From equipShield (sheet-worker.js:103777). Which areas a shield covers, by body-type
// family, shield size and the wielder's handedness. A shield is a FIFTH layer, added on
// top of the four worn ones, and every area it covers gains the shield's own armour value.
//
// A shield is held in the off hand, so a right-hander is covered down the LEFT side. His
// code tests only for "Left" and takes everything else as right-handed, which is how an
// Ambidextrous character -- a real value his racial code sets -- ends up on the right.
//
// A Buckler appears twice: on the hand, or strapped to the forearm, which is the choice
// his equip_buckler_on_wrist flag makes. The larger sizes add an area each as they grow --
// forearm and hand, then the arm, then the shoulder, and a Body shield the whole flank.
//
// Keyed by area NAME, not by his positions. His Snake and Centaur branches are displaced
// by one in exactly the way his armour branches are -- docs/UPSTREAM-ISSUES.md items 17
// and 18, showing up a second time here. Families absent below take no shield cover.
export const SHIELD_COVERAGE = {
	"Humanoid": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Right Thigh", "Right Shin", "Right Foot", "Right Hoof"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Left Thigh", "Finned Tail", "Left Shin", "Left Foot", "Left Hoof"] },
	},
	"Saurian": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Right Thigh", "Right Shin", "Right Foot"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Left Thigh", "Left Shin", "Left Foot"] },
	},
	"Insectoid": {
		"Buckler(Wrist)":  { "Left": ["Right Upper Forearm"], "Right": ["Left Upper Forearm"] },
		"Buckler":         { "Left": ["Right Upper Hand"], "Right": ["Left Upper Hand"] },
		"Small":           { "Left": ["Right Upper Forearm", "Right Upper Hand"], "Right": ["Left Upper Forearm", "Left Upper Hand"] },
		"Medium":          { "Left": ["Right Upper Arm", "Right Upper Forearm", "Right Upper Hand"], "Right": ["Left Upper Arm", "Left Upper Forearm", "Left Upper Hand"] },
		"Large":           { "Left": ["Right Upper Arm", "Right Upper Forearm", "Right Upper Hand"], "Right": ["Left Upper Arm", "Left Upper Forearm", "Left Upper Hand"] },
		"Body":            { "Left": ["Right Upper Arm", "Right Upper Forearm", "Right Upper Hand", "Right Leg", "Right Lower Leg", "Right Foot"], "Right": ["Left Upper Arm", "Left Upper Forearm", "Left Upper Hand", "Left Leg", "Left Lower Leg", "Left Foot"] },
	},
	"Snake": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Lower Length", "Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Tail"], "Right": ["Lower Length", "Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Tail"] },
	},
	"Centaur": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Right Foreleg", "Right Fore Shin"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Left Foreleg", "Left Fore Shin"] },
	},
	"Arachen": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Right Foreleg", "Right Fore Shin", "Right Fore Foot"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Left Foreleg", "Left Fore Shin", "Left Fore Foot"] },
	},
	"Scethen": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Right Foreleg", "Right Fore Shin", "Right Fore Foot"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Left Foreleg", "Left Fore Shin", "Left Fore Foot"] },
	},
	"Brachara": {
		"Buckler(Wrist)":  { "Left": ["Right Forearm"], "Right": ["Left Forearm"] },
		"Buckler":         { "Left": ["Right Hand"], "Right": ["Left Hand"] },
		"Small":           { "Left": ["Right Forearm", "Right Hand"], "Right": ["Left Forearm", "Left Hand"] },
		"Medium":          { "Left": ["Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Arm", "Left Forearm", "Left Hand"] },
		"Large":           { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand"] },
		"Body":            { "Left": ["Right Shoulder", "Right Arm", "Right Forearm", "Right Hand", "Right Foreleg", "Right Fore Shin", "Right Fore Foot"], "Right": ["Left Shoulder", "Left Arm", "Left Forearm", "Left Hand", "Left Foreleg", "Left Fore Shin", "Left Fore Foot"] },
	},
};

// The five sizes, smallest first, as his equipShield tests them. A shield's name carries
// its size, so "Shield(Large/Steel)" is a Large.
export const SHIELD_SIZES = ["Buckler", "Small", "Medium", "Large", "Body"];

// @MARKER ENDURING DAMAGE
// From getIsEndured (sheet-worker.js:120871). A blow of a damage type that is endured
// does NOTHING -- his handler branches past the whole apply block, so there is no damage,
// no armour wear and no effect. Each type is endured by a tag on anything worn.
//
// Note that "Enduring All" covers nine of the ten and NOT Obliteration, which accepts only
// its own tag. That is his switch as written; see docs/UPSTREAM-ISSUES.md item 20.
export const ENDURED_BY = {
	"Light":               ["Enduring Light", "Enduring All"],
	"Sonic":               ["Enduring Sonic", "Enduring All"],
	"Frost":               ["Enduring Frost", "Enduring All"],
	"Kinetic":             ["Enduring Kinetic", "Enduring All"],
	"Flame":               ["Enduring Flame", "Enduring All"],
	"Electricity":         ["Enduring Electricity", "Enduring All"],
	"Acid":                ["Enduring Acid", "Enduring All"],
	"Aura/Divine":         ["Enduring Aura/Divine", "Enduring All"],
	"Life/Death":          ["Enduring Life/Death", "Enduring All"],
	"Obliteration":        ["Enduring Obliteration"],
};

// The damage types a "Rebound" item turns back, from the same handler
// (sheet-worker.js:71222). Only the five physical kinds rebound.
export const REBOUNDED_TYPES = ["Cutting", "Thrusting", "Smashing", "Crushing", "Constricting"];

// @MARKER PROJECTILES AND LAUNCHERS
// From isWeaponProjectile (sheet-worker.js:86191), isWeaponLauncher (86425) and
// getNormalProjectileFromLauncher (86660). Each is an ordered chain of name tests.
//
// THE ORDER MATTERS and is preserved exactly. "Bolted" is tested before "Bolt" so a
// bolted-leather piece does not read as a crossbow bolt, and several pairs work that way.
// Read them by walking the list and taking the FIRST substring the name contains.
export const PROJECTILE_MATCHES = [["Bolted", false], ["Arrow", true], ["Bolt", true], ["Rock", true], ["Bullet", true], ["Boulder", true], ["Pebble", true], ["Dart", true], ["Javelin(Wood)", true], ["Stick(Throwing)", true], ["Lead Ball(Early Gun)", true], ["Ball(Cannon)", true], ["Greek Fire", true], ["Chain Shot", true], ["Grape Shot", true], ["Exploding", true]];

export const LAUNCHER_MATCHES = [["Bow(Long)", true], ["Fairy Composite Bow", true], ["Fairy Great Bow", true], ["Fairy Long Bow", true], ["Fairy Short Bow", true], ["Fairy Hand Crossbow", true], ["Fairy Heavy Crossbow", true], ["Fairy Crossbow", true], ["Fairy Sling", true], ["Giant Short Bow", true], ["Giant Long Bow", true], ["Giant Great Bow", true], ["Titan Bow", true], ["Bow(Composite)", true], ["Bow(Compound)", true], ["Bow(Great)", true], ["Bow(Horn)", true], ["Bow(Recurve)", true], ["Bow(Short)", true], ["Bow(Welsh)", true], ["Crossbow", true], ["Crossbow(Double)", true], ["Crossbow(Over-Under)", true], ["Crossbow(Repeating)", true], ["Crossbow(Hand)", true], ["Crossbow(Hand/Double)", true], ["Crossbow(Hand/Over-Under)", true], ["Crossbow(Hand/Repeating)", true], ["Crossbow(Heavy)", true], ["Crossbow(Heavy/Double)", true], ["Crossbow(Heavy/Over-Under)", true], ["Crossbow(Heavy/Repeating)", true], ["Wrist Sling", true], ["Sling", true], ["Bow(Primitive)", true], ["At’alta(Javelin Thrower)", true], ["Blow Gun", true], ["Ballista", true], ["Ballista(Heavy)", true], ["Ballista(Light)", true], ["Catapult", true], ["Trebuchet", true], ["Cannon(Early)", true], ["Cannon", true], ["Cannon(Heavy)", true], ["Early Derringer", true], ["Single Shot Pistol", true], ["Blunder Buss", true], ["Long Rifle", true]];

// Which projectile a launcher normally fires, so a Long Bow's lore is read off its Arrow.
export const LAUNCHER_PROJECTILE = [["Fairy Composite Bow", "Arrow(Fairy Composite Bow/Normal)"], ["Fairy Great Bow", "Arrow(Fairy Great Bow/Normal)"], ["Fairy Long Bow", "Arrow(Fairy Long Bow/Normal)"], ["Fairy Short Bow", "Arrow(Fairy Short Bow/Normal)"], ["Fairy Hand Crossbow", "Arrow(Fairy Hand Crossbow/Normal)"], ["Fairy Heavy Crossbow", "Arrow(Fairy Heavy Crossbow/Normal)"], ["Fairy Crossbow", "Arrow(Fairy Crossbow/Normal)"], ["Fairy Sling", "Pebble(Fairy Sling)"], ["Giant Short Bow", "Arrow(Giant Short Bow/Normal)"], ["Giant Long Bow", "Arrow(Giant Long Bow/Normal)"], ["Giant Great Bow", "Arrow(Giant Great Bow/Normal)"], ["Titan Bow", "Arrow(Titan Bow/Normal)"], ["Bow(Long)", "Arrow(Long Bow/Normal)"], ["Bow(Composite)", "Arrow(Composite Bow/Normal)"], ["Bow(Compound)", "Arrow(Compound Bow/Normal)"], ["Bow(Great)", "Arrow(Great Bow/Normal)"], ["Bow(Horn)", "Arrow(Horn Bow/Normal)"], ["Bow(Recurve)", "Arrow(Recurve Bow/Normal)"], ["Bow(Short)", "Arrow(Short Bow/Normal)"], ["Bow(Welsh)", "Arrow(Welsh Bow/Normal)"], ["Early Derringer", "Lead Ball(Early Gun)"], ["Single Shot Pistol", "Lead Ball(Early Gun)"], ["Blunder Buss", "Lead Ball(Early Gun)"], ["Long Rifle", "Lead Ball(Early Gun)"], ["Crossbow(Heavy)", "Bolt(Heavy Crossbow/Normal)"], ["Crossbow(Heavy/Double)", "Bolt(Heavy Crossbow/Normal)"], ["Crossbow(Heavy/Over-Under)", "Bolt(Heavy Crossbow/Normal)"], ["Crossbow(Heavy/Repeating)", "Bolt(Heavy Crossbow/Normal)"], ["Crossbow(Hand)", "Bolt(Hand Crossbow/Normal)"], ["Crossbow(Hand/Double)", "Bolt(Hand Crossbow/Normal)"], ["Crossbow(Hand/Over-Under)", "Bolt(Hand Crossbow/Normal)"], ["Crossbow(Hand/Repeating)", "Bolt(Hand Crossbow/Normal)"], ["Crossbow", "Bolt(Crossbow/Normal)"], ["Crossbow(Double)", "Bolt(Crossbow/Normal)"], ["Crossbow(Over-Under)", "Bolt(Crossbow/Normal)"], ["Crossbow(Repeating)", "Bolt(Crossbow/Normal)"], ["Wrist Sling", "Rock(Wrist Sling)"], ["Sling", "Rock(Sling)"], ["Bow(Primitive)", "Arrow(Primitive Bow)"], ["Blow Gun", "Dart(Blow Gun)"], ["At’alta(Javelin Thrower)", "Stick(Throwing)"], ["Ballista", "Bolt(Ballista/Normal)"], ["Ballista(Heavy)", "Bolt(Heavy Ballista/Normal)"], ["Ballista(Light)", "Bolt(Light Ballista/Normal)"], ["Catapult", "Boulder(Catapult)"], ["Trebuchet", "Boulder(Trebuchet)"], ["Cannon(Early)", "Ball(Cannon)"], ["Cannon", "Ball(Cannon)"], ["Cannon(Heavy)", "Ball(Cannon)"]];

// @MARKER OFF-HAND PENALTIES
// From getOffhandMeleeAdj (sheet-worker.js:83329), getOffhandDamageAdj (83305) and
// getOffhandSkillAdj (83349). What it costs to fight with the wrong hand, banded by Agility.
//
// Each row is [lowest Agility, highest Agility, penalty]. Read by walking the list and
// taking the first band the rating falls in; ANY rating outside every band is zero, which
// covers both his "<=0" branch and the open top of each chain without special-casing either.
//
// THE THREE DO NOT SHARE BAND EDGES. Melee reaches zero at Agility 19, damage and skills
// at 20, and only the damage table breaks out 16 and 17 as single values. Do not assume
// one shape from another -- that is why these are generated.
//
// An Ambidextrous character takes NO off-hand penalty at all: all three of his functions
// short-circuit on handedness before they ever look at Agility. Ambidexterity is therefore
// the absence of the cost rather than a bonus on top of it.
export const OFFHAND_PENALTIES = {
	melee:  [[1, 9, -4], [10, 12, -3], [13, 16, -2], [17, 18, -1]],
	damage: [[1, 9, -6], [10, 12, -5], [13, 15, -4], [16, 16, -3], [17, 17, -2], [18, 19, -1]],
	skill:  [[1, 9, -20], [10, 15, -15], [16, 17, -10], [18, 19, -5]]
};

// @MARKER MOVEMENT BASE BY AGILITY
// From calcMovement (sheet-worker.js:30856), the base distances every character
// walks, jogs and runs before its race is taken into account.
//
// A RACE'S MOVEMENT FIGURES ARE MODIFIERS, NOT FINISHED RATES. His switch reads
//     move_walk_hourly: 2+racetmpwalkhourly+tmpwalktemphourlymod
// so the race's number is ADDED to the base below. A race carrying 0/0/0 --
// Human(Civilized) among them -- is a race with no modifier, and walks at the full
// base for its Agility. It is NOT a race with no movement, and must never be
// "fixed" by inventing figures for it.
//
// Each row is [lowest Agility, highest Agility, bases], and each of walk/jog/run is
// [hourly (miles), 10 seconds (feet), 1 second (feet)]. His bands are irregular --
// 0-1, 2-4, then singles, then 11-12 and 13-14 -- which is why this is generated.
//
// His switch stops at Agility 30 and has no default, so a higher rating would leave
// the previous values in place. The port clamps to the top band instead.
export const MOVEMENT_BASE = [
	[ 0,  1, { walk: [0.0, 0.0, 0.0], jog: [0.0, 0.0, 0.0], run: [0.0, 0.0, 0.0], jumpStand: 0.0, jumpUp: 0.0 }],
	[ 2,  4, { walk: [0.5, 5.0, 0.5], jog: [1.0, 10.0, 1.0], run: [2.0, 10.0, 1.0], jumpStand: 1.0, jumpUp: 0.5 }],
	[ 5,  5, { walk: [1.0, 10.0, 1.0], jog: [2.0, 10.0, 1.0], run: [3.0, 20.0, 2.0], jumpStand: 2.0, jumpUp: 0.5 }],
	[ 6,  6, { walk: [1.0, 10.0, 1.0], jog: [2.0, 20.0, 2.0], run: [3.0, 30.0, 3.0], jumpStand: 3.0, jumpUp: 1.0 }],
	[ 7,  7, { walk: [2.0, 20.0, 2.0], jog: [4.0, 30.0, 3.0], run: [6.0, 50.0, 5.0], jumpStand: 3.0, jumpUp: 1.0 }],
	[ 8,  8, { walk: [2.0, 20.0, 2.0], jog: [4.0, 40.0, 4.0], run: [6.0, 60.0, 6.0], jumpStand: 4.0, jumpUp: 1.5 }],
	[ 9,  9, { walk: [3.0, 30.0, 3.0], jog: [6.0, 50.0, 5.0], run: [9.0, 80.0, 8.0], jumpStand: 4.0, jumpUp: 1.5 }],
	[10, 10, { walk: [3.0, 30.0, 3.0], jog: [6.0, 60.0, 6.0], run: [9.0, 90.0, 9.0], jumpStand: 5.0, jumpUp: 2.0 }],
	[11, 12, { walk: [4.0, 40.0, 4.0], jog: [8.0, 70.0, 7.0], run: [12.0, 110.0, 11.0], jumpStand: 5.0, jumpUp: 2.0 }],
	[13, 14, { walk: [4.0, 40.0, 4.0], jog: [8.0, 80.0, 8.0], run: [12.0, 120.0, 12.0], jumpStand: 6.0, jumpUp: 2.5 }],
	[15, 15, { walk: [5.0, 50.0, 5.0], jog: [10.0, 90.0, 9.0], run: [15.0, 140.0, 14.0], jumpStand: 6.0, jumpUp: 2.5 }],
	[16, 16, { walk: [5.0, 50.0, 5.0], jog: [10.0, 100.0, 10.0], run: [15.0, 150.0, 15.0], jumpStand: 7.0, jumpUp: 3.0 }],
	[17, 17, { walk: [6.0, 60.0, 6.0], jog: [12.0, 110.0, 11.0], run: [18.0, 170.0, 17.0], jumpStand: 7.0, jumpUp: 3.0 }],
	[18, 18, { walk: [6.0, 60.0, 6.0], jog: [12.0, 120.0, 12.0], run: [18.0, 180.0, 18.0], jumpStand: 8.0, jumpUp: 3.5 }],
	[19, 19, { walk: [7.0, 70.0, 7.0], jog: [14.0, 130.0, 13.0], run: [21.0, 200.0, 20.0], jumpStand: 8.0, jumpUp: 3.5 }],
	[20, 20, { walk: [7.0, 70.0, 7.0], jog: [14.0, 140.0, 14.0], run: [21.0, 210.0, 21.0], jumpStand: 9.0, jumpUp: 4.0 }],
	[21, 21, { walk: [8.0, 80.0, 8.0], jog: [16.0, 160.0, 16.0], run: [24.0, 240.0, 24.0], jumpStand: 10.0, jumpUp: 4.5 }],
	[22, 22, { walk: [8.0, 80.0, 8.0], jog: [16.0, 160.0, 16.0], run: [24.0, 240.0, 24.0], jumpStand: 11.0, jumpUp: 5.0 }],
	[23, 24, { walk: [9.0, 90.0, 9.0], jog: [18.0, 180.0, 18.0], run: [27.0, 270.0, 27.0], jumpStand: 11.0, jumpUp: 5.0 }],
	[25, 26, { walk: [10.0, 100.0, 10.0], jog: [20.0, 200.0, 20.0], run: [30.0, 300.0, 30.0], jumpStand: 12.0, jumpUp: 5.5 }],
	[27, 28, { walk: [11.0, 110.0, 11.0], jog: [22.0, 220.0, 22.0], run: [33.0, 330.0, 33.0], jumpStand: 13.0, jumpUp: 6.0 }],
	[29, 29, { walk: [12.0, 120.0, 12.0], jog: [24.0, 240.0, 24.0], run: [36.0, 360.0, 36.0], jumpStand: 14.0, jumpUp: 6.5 }],
	[30, 30, { walk: [12.0, 120.0, 12.0], jog: [24.0, 240.0, 24.0], run: [36.0, 360.0, 36.0], jumpStand: 15.0, jumpUp: 7.0 }],
];

// @MARKER MARTIAL ARTS
// From his eight martial arts dictionaries (getMartialKnowAttackValues and siblings,
// sheet-worker.js:100674-100838), the four preset disciplines (setMartialKnowArts, 98801),
// and the three handlers that turn a successful roll into numbers: handleStanceOn (68794),
// handleMartialModifierSet (68113) and handleMartialLoreModifierSet (68276).
//
// Every subskill is rolled against its PARENT skill's chance plus skillMod -- Player's Guide
// p.93, "Subskills": the difference between the parent's rating and the subskill's, x5%.
// Martial Knowledge is rating 16, Martial Lore 18, both read from his skilldict.
// Rows whose skillMod does NOT fit that rule, kept as he wrote them:
//     MARTIAL_MOVES Jump: rating 14 gives +10, his table says +20
//     MARTIAL_MOVES Immoveable Stance: rating 17 gives -5, his table says +5
//
// A move's or throw's speed is kept as his text beside the number: a leading sign means it is
// ADDED to the attack it is combined with (Spinning "+2", Snap "-1"), not a time of its own.

// MARTIAL_ATTACKS -- from martialattackvalueslist, rolled against Martial Knowledge.
//                     rating skillMod speed minSpeed damage special
export const MARTIAL_ATTACKS = {
	"Martial Punch":     { rating: 10, skillMod: 30, speed: 3, minSpeed: 2, damage: "2d4", special: "None" },
	"Martial Kick":      { rating: 12, skillMod: 20, speed: 4, minSpeed: 2, damage: "2d6", special: "None" },
	"Elbow Smash":       { rating: 11, skillMod: 25, speed: 3, minSpeed: 2, damage: "2d4+2", special: "None" },
	"Knee Smash":        { rating: 13, skillMod: 15, speed: 4, minSpeed: 2, damage: "2d6+2", special: "None" },
	"Head Butt":         { rating: 12, skillMod: 20, speed: 3, minSpeed: 2, damage: "1d6+2", special: "None" },
	"Heel Strike":       { rating: 14, skillMod: 10, speed: 3, minSpeed: 2, damage: "2d4+4", special: "None" },
	"Rake":              { rating: 15, skillMod: 5, speed: 3, minSpeed: 2, damage: "3d4+1", special: "vs. 6 armor or less,Attacker takes 1d4 dam vs. metal armor." },
	"Finger Punch":      { rating: 15, skillMod: 5, speed: 2, minSpeed: 1, damage: "1d4+2", special: "vs. 6 armor or less,Attacker takes 1d4 dam vs. metal armor." },
	"Counter Punch":     { rating: 12, skillMod: 20, speed: 3, minSpeed: 2, damage: "3d4+3", special: "vs. a melee attack." },
	"Counter Kick":      { rating: 14, skillMod: 10, speed: 4, minSpeed: 2, damage: "3d6+3", special: "vs. a melee attack." },
	"Scissor Strike":    { rating: 15, skillMod: 5, speed: 3, minSpeed: 2, damage: "2d4", special: "vs. attack from fist/weapon under 1'). 2 attacks: 1 to arm, 1 to forearm. If hits/skill successful x2 damage to both." },
};

// MARTIAL_BLOCKS -- from martialblockvalueslist, rolled against Martial Knowledge.
//                     rating skillMod speed special
export const MARTIAL_BLOCKS = {
	"Arm Block":         { rating: 10, skillMod: 30, speed: 1, special: "If success, attack is blocked by arm or forearm and damage is reduced to 1/2." },
	"Leg Block":         { rating: 12, skillMod: 20, speed: 1, special: "If success, attack is blocked by thigh or shin and damage is reduced to 1/2." },
	"Body Block":        { rating: 14, skillMod: 10, speed: 1, special: "If success, attack is blocked by a torso and damage is reduced to 1/2." },
};

// MARTIAL_HOLDS -- from martialholdvalueslist, rolled against Martial Knowledge.
//                     rating skillMod speed special
export const MARTIAL_HOLDS = {
	"Half Neck":         { rating: 18, skillMod: -10, speed: 3, special: "If success, incapacitates the head, neck and one arm. Escape requires skill versus roll vs AGL or STR Save (once per 3 sec)." },
	"Full Neck":         { rating: 20, skillMod: -20, speed: 5, special: "If success, incapacitates the head, neck and both arms. Escape requires skill versus roll vs AGL Save (once per 5 sec)." },
	"Arm":               { rating: 16, skillMod: 0, speed: 3, special: "If success, incapacitates one arm. Escape requires skill versus roll vs Half AGL Save (once per 3 sec)." },
	"Leg":               { rating: 17, skillMod: -5, speed: 4, special: "If success, incapacitates one leg. Escape requires skill versus roll vs Half AGL Save (once per 4 sec)." },
	"Torso":             { rating: 18, skillMod: -10, speed: 5, special: "If success, incapacitates one torso. Escape requires skill versus roll vs Quarter AGL Save (once per 5 sec)." },
	"Torso(1 Arm)":      { rating: 20, skillMod: -20, speed: 5, special: "If success, incapacitates one torso and one arm. Escape requires skill versus roll vs Quarter AGL Save (once per 5 sec)." },
	"Torso(2 Arms)":     { rating: 22, skillMod: -30, speed: 5, special: "If success, incapacitates one torso and both arms. Escape requires skill versus roll vs Quarter AGL Save (once per 5 sec)." },
};

// MARTIAL_MOVES -- from martialmovevalueslist, rolled against Martial Knowledge.
//                     rating skillMod speed speedText special
export const MARTIAL_MOVES = {
	"Jump":              { rating: 14, skillMod: 20, speed: 1, speedText: "1", special: "Requires 5'. If success, jumping as if +2 AGL. To hit +2, Dam +1, +1 die. Cannot be combined with Spinning. Fail make AGL Save to remain standing." },
	"Flying":            { rating: 16, skillMod: 0, speed: 2, speedText: "2", special: "Requires 10'. If success, jumping as if +2 AGL. To hit +4, Dam x2. Cannot be combined with Spinning. Fail make AGL Save to remain standing." },
	"Immoveable Stance": { rating: 17, skillMod: 5, speed: 3, speedText: "3", special: "If success, amount skill roll is made by, added to any STR Saves. No Defense." },
	"Spinning":          { rating: 15, skillMod: 5, speed: 2, speedText: "+2", special: "If success, To hit +2, +2 Dam per die. Cannot be combined with Jump or Flying. Fail make AGL Save or lose 1-3 seconds." },
	"Sweep":             { rating: 14, skillMod: 10, speed: 2, speedText: "2", special: "After successful Martial Kick. If success, opponent makes an AGL Save or falls prone." },
	"Snap":              { rating: 13, skillMod: 15, speed: -1, speedText: "-1", special: "If success, 1 second is reduced from another martial attack (minimum 1), but no STR modifier applies to that attack." },
	"Tension":           { rating: 15, skillMod: 5, speed: 2, speedText: "2", special: "If success, doubles STR bonus/or halves a STR penalty on an other attack." },
	"Double Attack":     { rating: 13, skillMod: 15, speed: 1, speedText: "+1", special: "If success, allows combo of 2 standard martial attacks(Punch/Kick) at once. Adds 1 second to each attack. Cannot attack with both legs unless prone." },
};

// MARTIAL_THROWS -- from martialthrowvalueslist, rolled against Martial Knowledge.
//                     rating skillMod speed speedText damage special
export const MARTIAL_THROWS = {
	"Arm Throw":         { rating: 16, skillMod: 0, speed: 3, speedText: "3", damage: "1d6", special: "Contest of STR Save vs. opponent's AGL Save or knocked prone. 2nd AGL save to transition into Arm Hold." },
	"Leg Throw":         { rating: 17, skillMod: -5, speed: 4, speedText: "4", damage: "1d4", special: "Contest of STR Save(-20%) vs. opponent's AGL Save or knocked prone. 2nd AGL save to transition into Leg Hold." },
	"Shoulder Throw":    { rating: 18, skillMod: -10, speed: 3, speedText: "3", damage: "1d8", special: "Contest of STR Save(+20%) vs. opponent's AGL Save or knocked prone. 2nd AGL save to transition into Neck Hold." },
	"Body Throw":        { rating: 19, skillMod: -15, speed: 5, speedText: "5", damage: "1d8", special: "Contest of STR Save(+30%) vs. opponent's AGL Save or knocked prone. 2nd AGL save to transition into Arm Hold." },
	"Spin Throw":        { rating: 18, skillMod: -10, speed: 1, speedText: "+1", damage: "+2", special: "Does not require touch before using. Add to another throw. Opponent is -20% to Agility Save. Removes hold chance as the opponent is thrown." },
};

// MARTIAL_LORE_VALUES -- from martiallorevalueslist, rolled against Martial Lore.
//                     type rating skillMod special
export const MARTIAL_LORE_VALUES = {
	"Combined Attack":   { type: "Attack", rating: 17, skillMod: 5, special: "Allows any two martial attacks with any two limbs. Speed for both is the longer of the two attacks." },
	"Stunning Head Blow": { type: "Attack", rating: 15, skillMod: 15, special: "Two martial punches to either side of the head. Doubles chance of unconsciousness per point of physical damage (from 2% to 4%)" },
	"Eye Gouge":         { type: "Attack", rating: 16, skillMod: 10, special: "Two simultaneous Finger Punches if either are successful then an Eye Gouge is made for each. Success equals equals permanent eye loss." },
	"Death Strike":      { type: "Attack", rating: 20, skillMod: -10, special: "vs. 6 or less armor. Attacker must be within 2' of target height. Rake against the neck or Hell Strike to the nose. Causes immediate death if success." },
	"Feather Block":     { type: "Block", rating: 14, skillMod: 20, special: "Combined with any other block, +1 second. If successful all damage is mitigated." },
	"Crushing Hold":     { type: "Hold", rating: 16, skillMod: 10, special: "Combined with any other hold. Does 3d6 crushing damage per 5 seconds to held areas." },
	"Punch Throw":       { type: "Throw", rating: 19, skillMod: -5, special: "Martial Punch to the upper body combined with a Leg Throw. Must make Martial Punch first to roll this skill in place of the Leg Throw." },
	"Kick Throw":        { type: "Throw", rating: 20, skillMod: -10, special: "Martial Kick to the lower body combined with a Arm, Shoulder or Body Throw. Must make Martial Kick first to roll this skill in place of the Throw." },
	"Slam":              { type: "Throw", rating: 21, skillMod: -15, special: "Added to any Throw (except leg). Make a STR Save with skill roll. If both are successful, 1d6 damage per 5 full points of STR. +2 seconds to throw used." },
	"Martial Disarm":    { type: "Throw", rating: 20, skillMod: -10, special: "Disarm an opponent as a contest of this skill roll versus the oppenent's AGL Save. If made by quarter and opponent loses AGL Save the weapon can be taken instead of disarm." },
	"Flip":              { type: "Move", rating: 18, skillMod: 0, special: "Cannot attack. If successful -4 to be hit. Fail requires AGL Save to land on their feet." },
	"Wall Jump":         { type: "Move", rating: 15, skillMod: 15, special: "Combined with jump or flying move, adds +2 more AGL for jump moves." },
};

// The rating each family of subskill is measured against, read from his skilldict.
export const MARTIAL_PARENT_RATINGS = {"knowledge": 16, "lore": 18};

// The five stances, in prose: the learned form (Martial Knowledge) and the mastered one
// (Martial Lore). From martialknowstancevalueslist and martiallorestancevalueslist.
export const MARTIAL_STANCES = {
	"See without eyes":  { knowledge: "If cannot see opponent, penalites are reduced to -4 melee. Gain full defensive modifer against their attacks. Ignores distortion spell effects. Does not apply if target is silenced.",
	                       lore: "If cannot see opponent, penalites are reduced to -2 melee. Gain full defensive modifer against their attacks. Rear/Side bonus against while in theis stance. Ignores distortion spell effects. Does not apply if target is silenced." },
	"Flow as water":     { knowledge: "-6 Defensive modifier. Dodge, Feint and Sidestep are +30%. Offensive actions are -2 to hit, and speed is +1 second.",
	                       lore: "-8 Defensive modifier. Dodge, Feint and Sidestep are +50%. Offensive actions are -1 to hit." },
	"Strike as wind":    { knowledge: "+3 Melee/Missile to hit, Starting weapon speeds are -1 second. Initiative is -2, Critical, Focused Attack, Perfect Shot are +20%.",
	                       lore: "+4 Melee/Missile to hit, Starting weapon speeds are -2 seconds. Initiative is -4, Critical, Focused Attack, Perfect Shot are +50%." },
	"Calm in the storm": { knowledge: "+25% resistances effects which hold or affect movement. +10% Control Resistance. Parries, Disarm and Trap Weapon are +10%, AGL Saves are +20%.",
	                       lore: "+50% resistances effects which hold or affect movement. +20% Control Resistance. Parries, Disarm and Trap Weapon are +25%, AGL Saves are +40%." },
	"Drunken fighting":  { knowledge: "+2 to hit and +1 per die of damage after failing 1 VIT Save for intoxication. +10% to combat skills and Martial Knowledge attacks. If more than 3 VIT Saves for intoxication all modifers are lost.",
	                       lore: "+4 to hit and +2 per die of damage after failing 1 VIT Save for intoxication. +20% to combat skills and Martial Knowledge attacks. If more than 5 VIT Saves for intoxication all modifers are lost." },
};

// What each stance actually DOES, read from the two live branches of each case in his
// handleStanceOn (sheet-worker.js:68794). His third branch per case cannot run and is not read.
//   mod_melee / mod_missile / mod_damage     added to to-hit and damage
//   mod_damage_multi                        a damage multiplier (1 = none)
//   mod_defensive                           added to the defensive adjustment (+ is WORSE)
//   blind_fighting                          what the -8 for fighting blind becomes easier by
//   blind_defense                           "Full Defensive Mod" keeps defence when blind
//   mod_special                             his prose; initiative and speed are read out of it
export const MARTIAL_STANCE_MODS = {
	"See without eyes": {
		knowledge: {"mod_melee": 0, "mod_missile": 0, "mod_damage": 0, "mod_damage_multi": 1, "mod_defensive": 0, "blind_fighting": 4, "blind_defense": "Full Defensive Mod", "mod_special": "Ignores Distortion(spell) effects. Does not apply to silenced opponents."},
		lore:      {"mod_melee": 0, "mod_damage": 0, "mod_missile": 0, "mod_damage_multi": 1, "mod_defensive": 0, "blind_fighting": 6, "blind_defense": "Full Defensive Mod", "mod_special": "Ignores Distortion(spell) effects. Side/Rear modifiers no longer apply against while in this stance. Does not apply to silenced opponents."},
	},
	"Flow as water": {
		knowledge: {"mod_melee": -2, "mod_damage": -2, "mod_missile": -2, "mod_damage_multi": 1, "mod_defensive": -6, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "Dodge, Feint and Sidestep are +30% to skill rolls. +1 second to offensive actions starting speed."},
		lore:      {"mod_melee": -1, "mod_damage": -1, "mod_missile": -1, "mod_damage_multi": 1, "mod_defensive": -8, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "Dodge, Feint and Sidestep are +50% to skill rolls."},
	},
	"Strike as wind": {
		knowledge: {"mod_melee": 3, "mod_damage": 3, "mod_missile": 3, "mod_damage_multi": 1, "mod_defensive": 2, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "Initiative -2. Critical, Focused Attack, and Perfect Shot are +20% to skill rolls. -1 second to offensive actions starting speed."},
		lore:      {"mod_melee": 4, "mod_damage": 4, "mod_missile": 4, "mod_damage_multi": 1, "mod_defensive": 1, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "Initiative -4. Critical, Focused Attack, and Perfect Shot are +50% to skill rolls. -2 seconds to offensive actions starting speed."},
	},
	"Calm in the storm": {
		knowledge: {"mod_melee": 0, "mod_damage": 0, "mod_missile": 0, "mod_damage_multi": 1, "mod_defensive": 0, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "+25% Resistances vs. hold/movement effects. +10% to Control Resist. Parries, Disarm and Trap Weapon skills are at +10%. +20% to all AGL Saves."},
		lore:      {"mod_melee": 0, "mod_damage": 0, "mod_missile": 0, "mod_damage_multi": 1, "mod_defensive": 0, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "+50% Resistances vs. hold/movement effects. +20% to Control Resist. Parries, Disarm and Trap Weapon skills are at +25%. +40% to all AGL Saves."},
	},
	"Drunken fighting": {
		knowledge: {"mod_melee": 2, "mod_damage": 0, "mod_missile": 2, "mod_damage_multi": 1, "mod_defensive": 0, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "+1 Die Dam. +10% to combat skills, martial know/lore skill attack rolls. (modifers are after failing 1 VIT Save for intoxication but not more than 3)"},
		lore:      {"mod_melee": 4, "mod_damage": 0, "mod_missile": 4, "mod_damage_multi": 1, "mod_defensive": 0, "blind_fighting": -8, "blind_defense": "No Defensive Mod", "mod_special": "+2 Die Dam. +20% to combat skills, martial know/lore skill attack rolls. (modifers are after failing 1 VIT Save for intoxication but not more than 5)"},
	},
};

// What a SUCCESSFUL move adds to the attacks after it, from the success branch of each case in
// his handleMartialModifierSet (sheet-worker.js:68113). defensive null means the move does not
// touch it. comboGate: "spinning" -- void if Spinning was also made; "jumpOrFly" -- void if
// Jump or Flying was. Martial Lore lifts both. THESE ARE HIS CODE'S NUMBERS; where they
// disagree with his own move prose, martial-arts.mjs says which is followed and why.
//                        melee damage multiplier defensive special comboGate
export const MARTIAL_MOVE_MODS = {
	"Jump":              { melee: 2, damage: 1, multiplier: 1, defensive: null, special: "Jump at +2 AGL,+1 Die Dam", comboGate: "spinning" },
	"Flying":            { melee: 4, damage: 1, multiplier: 2, defensive: null, special: "Jump at +2 AGL", comboGate: "spinning" },
	"Immoveable Stance": { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "No Defense,+Skill Roll to STR Saves", comboGate: "" },
	"Spinning":          { melee: 4, damage: 0, multiplier: 1, defensive: null, special: "+2 per Die", comboGate: "jumpOrFly" },
	"Snap":              { melee: 0, damage: 0, multiplier: 1, defensive: null, special: "-1 Sec Martial Attack,No STR Mod", comboGate: "" },
	"Tension":           { melee: 0, damage: 0, multiplier: 1, defensive: null, special: "STR Dam bonus x2/STR penalty halved", comboGate: "" },
	"Double Attack":     { melee: 0, damage: 0, multiplier: 1, defensive: null, special: "-1 Sec Martial Attack,2 Martial Attacks at once", comboGate: "" },
};

// What a successful Martial Lore value adds, from handleMartialLoreModifierSet
// (sheet-worker.js:68276). Only Flip changes a number. dynamic marks a line his code finishes
// with a roll made at that moment.
//                        melee damage multiplier defensive special dynamic
export const MARTIAL_LORE_MODS = {
	"Combined Attack":   { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Combine any 2 martial attacks with different limbs", dynamic: false },
	"Stunning Head Blow": { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "4% target unconciousness/per head damage", dynamic: false },
	"Eye Gouge":         { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Loss of eye for each hit finger punch hit", dynamic: false },
	"Death Strike":      { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Target death if Neck Rake or Head Heel Strike with 6 or less armor", dynamic: false },
	"Feather Block":     { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "0 damage for next block", dynamic: false },
	"Crushing Hold":     { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Next Hold does 3d6=", dynamic: true },
	"Punch Throw":       { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Next Martial Punch to the upper body becomes a Leg Throw", dynamic: false },
	"Kick Throw":        { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Next Martial Kick to the lower body becomes a Arm, Shoulder or Body Throw", dynamic: false },
	"Slam":              { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Next Throw takes +2 seconds but adds 3d6=", dynamic: true },
	"Martial Disarm":    { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "Target must make an AGL Save at -", dynamic: true },
	"Flip":              { melee: 0, damage: 0, multiplier: 1, defensive: -4, special: "No Attack", dynamic: false },
	"Wall Jump":         { melee: 0, damage: 0, multiplier: 1, defensive: 0, special: "+2 more AGL for other jump moves", dynamic: false },
};

// The four preset disciplines, from setMartialKnowArts (sheet-worker.js:98801). Custom is not a
// list -- it is whatever the player picks -- so it has no entry here.
export const MARTIAL_DISCIPLINES = {
	"Offensive": {
		attacks: ["Martial Punch", "Martial Kick", "Elbow Smash", "Knee Smash", "Head Butt", "Heel Strike", "Rake", "Finger Punch"],
		blocks:  ["Arm Block", "Leg Block"],
		holds:   [],
		moves:   ["Jump", "Spinning", "Sweep", "Tension", "Double Attack"],
		throws:  ["Arm Throw"],
	},
	"Defensive": {
		attacks: ["Martial Punch", "Martial Kick", "Counter Punch", "Counter Kick", "Scissor Strike"],
		blocks:  ["Arm Block", "Leg Block", "Body Block"],
		holds:   ["Half Neck", "Full Neck", "Arm", "Leg"],
		moves:   ["Jump", "Immoveable Stance", "Spinning", "Sweep"],
		throws:  ["Arm Throw", "Leg Throw", "Shoulder Throw", "Body Throw"],
	},
	"Balanced": {
		attacks: ["Martial Punch", "Martial Kick", "Elbow Smash", "Knee Smash", "Heel Strike"],
		blocks:  ["Arm Block", "Leg Block"],
		holds:   ["Half Neck", "Arm", "Leg"],
		moves:   ["Jump", "Flying", "Spinning", "Sweep", "Snap"],
		throws:  ["Arm Throw", "Leg Throw"],
	},
	"Contact": {
		attacks: ["Martial Punch", "Elbow Smash", "Knee Smash", "Head Butt"],
		blocks:  ["Arm Block", "Leg Block"],
		holds:   ["Half Neck", "Full Neck", "Arm", "Leg", "Torso", "Torso(1 Arm)", "Torso(2 Arms)"],
		moves:   ["Jump", "Flying", "Spinning", "Sweep"],
		throws:  ["Arm Throw", "Leg Throw", "Shoulder Throw", "Body Throw", "Spin Throw"],
	},
};

// Martial Lore's blind fighting, from setMartialLoreDisplayValues (sheet-worker.js:100338): one
// point off the penalty for fighting blind per percentPerLevel of the skill, and the
// defensive adjustment kept when blind from fullDefenseAt.
export const MARTIAL_LORE_BLIND = {"percentPerLevel": 25, "fullDefenseAt": 100};

// @END (CODE)
