// @START (CODE)
// @MARKER RACE ITEM DATA MODEL
//==================================================================================================================
// Schema for a race.
//
// Fields map onto the 62 columns of raceStatsAndMoveDetails in the original sheet-worker.
// That dictionary carries no column-header comment, so the layout was recovered by reading
// how the code consumes the row (tempRaceStatMoves, sheet-worker.js:33697-33758) rather than
// transcribed -- see tools/extract/column_maps.py.
//
// A race supplies three kinds of thing:
//   1. modifiers to attributes, characteristics and resistances
//   2. a per-race cap on each attribute, which is separate from and stricter than the
//      being-type cap that title confers
//   3. movement rates, at the three scales the system tracks
//
// These are read directly by the character rather than being turned into Active Effects.
// Effects are for things that come and go -- spells, conditions, injuries. A race is
// permanent character definition, the original sheet stores it as plain fields
// (race_per_mod, race_aff_mod and so on), and the character schema already has raceMod slots
// waiting for it.
//==================================================================================================================

const fields = foundry.data.fields;

	// This is the function which builds a modifier field, used for the twelve attribute
	// modifiers and the characteristic and resistance modifiers.
	function modField() {
		return new fields.NumberField({ required: true, integer: true, initial: 0 });
	}

	// This is the function which builds a per-race attribute cap. A race may not exceed this
	// even where the character's title would otherwise allow a higher rating.
	function limitField() {
		return new fields.NumberField({ required: true, integer: true, initial: 20, min: 0, max: 30 });
	}

	// This is the function which builds one movement rate. Every movement mode is tracked at
	// three scales at once: per hour, per 10 seconds (one combat round) and per second.
	function movementRateField() {
		return new fields.SchemaField({
			hourly: new fields.NumberField({ required: true, initial: 0 }),
			tenSec: new fields.NumberField({ required: true, initial: 0 }),
			oneSec: new fields.NumberField({ required: true, initial: 0 })
		});
	}


export default class ImagineRaceData extends foundry.abstract.TypeDataModel {

	static defineSchema() {
		return {

			// @MARKER ATTRIBUTE MODIFIERS
			// Applied to the character's attribute ratings.
			attributeMods: new fields.SchemaField({
				str: modField(), agl: modField(), vit: modField(),
				int: modField(), wis: modField(), knw: modField(),
				app: modField(), chm: modField(), soc: modField(),
				aur: modField(), pty: modField(), wil: modField()
			}),

			// @MARKER ATTRIBUTE CAPS
			// The highest rating a member of this race may reach in each attribute.
			attributeLimits: new fields.SchemaField({
				str: limitField(), agl: limitField(), vit: limitField(),
				int: limitField(), wis: limitField(), knw: limitField(),
				app: limitField(), chm: limitField(), soc: limitField(),
				aur: limitField(), pty: limitField(), wil: limitField()
			}),

			// @MARKER ENDURANCE
			// Endurance at creation, and how much is gained on each title advance. The title
			// gain is rolled rather than fixed, which is why the dice and maximum are carried
			// separately from the flat modifier.
			//
			// startFormula is a DIE only for Gaunt, whose starting Endurance is rolled: "-1d4="
			// (Epitaph p.7, "Starting Endurance -1d4"; his row's modifier is the live expression
			// 0-getDieRoll(4)). The race document carries startMod 0; when a character takes the
			// race the die is rolled once, the result is written into THAT CHARACTER'S copy of the
			// race as startRoll, and startRolled is set so it is never rolled again -- which is what
			// his sheet does by writing the rolled figure to race_start_tmp_end_mod. Every other race
			// has a blank formula and nothing is rolled. See rollStartingEndurance, race-rules.mjs, and
			// module/race-endurance.mjs for the three places it is rolled.
			//
			//     startMod     the flat figure; never written by the roll
			//     startRoll    the rolled figure, SET (never added to) by the roll; 0 on every document
			//     startRolled  ticked once rolled; false on every document
			//
			// The character's starting-Endurance modifier is startMod + startRoll
			// (getStartingEnduranceMod). The roll has a field of its own so that a Start mod typed by
			// hand is never counted twice and a re-roll replaces rather than stacks. A copy made
			// before startRoll existed reads it as 0.
			endurance: new fields.SchemaField({
				startFormula: new fields.StringField({ required: true, initial: "" }),
				startMod:     modField(),
				startRoll:    modField(),
				startRolled:  new fields.BooleanField({ required: true, initial: false }),
				titleFormula: new fields.StringField({ required: true, initial: "" }),
				titleDice:    new fields.StringField({ required: true, initial: "" }),
				titleMax:     new fields.NumberField({ required: true, integer: true, initial: 0 }),
				titleMod:     modField()
			}),

			// @MARKER CHARACTERISTIC AND RESISTANCE MODIFIERS
			characteristicMods: new fields.SchemaField({
				perception: modField(),
				affinity:   modField(),
				fortune:    modField()
			}),

			resistanceMods: new fields.SchemaField({
				magic:    modField(),
				illusion: modField(),
				control:  modField(),
				poison:   modField(),
				disease:  modField()
			}),

			// @MARKER MOVEMENT
			// specialName holds what the special movement mode actually is -- flying,
			// swimming, scurrying and so on. The multiplier and modifier fields exist because
			// some races derive their special rate from another rate rather than stating it
			// outright.
			movement: new fields.SchemaField({
				speedMultiplier: new fields.NumberField({ required: true, initial: 1 }),
				walk: movementRateField(),
				jog:  movementRateField(),
				run:  movementRateField(),
				specialName: new fields.StringField({ required: true, initial: "" }),
				special: new fields.SchemaField({
					hourly:           new fields.StringField({ required: true, initial: "" }),
					hourlyMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					hourlyMod:        new fields.NumberField({ required: true, initial: 0 }),
					tenSec:           new fields.StringField({ required: true, initial: "" }),
					tenSecMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					tenSecMod:        new fields.NumberField({ required: true, initial: 0 }),
					oneSec:           new fields.StringField({ required: true, initial: "" }),
					oneSecMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					oneSecMod:        new fields.NumberField({ required: true, initial: 0 })
				}),
				// A SECOND special movement, for a race the books give two of. His row has room for
				// one; Legends p.33 gives a Nixie both "Enhanced Swimming (5x walking speed)" and
				// "Magical Flight", and his own Formless copy of the Nixie row is the swim (Swim: Walk
				// x5) where the race row is the flight. Blank for every other race, which is what the
				// initial values give a race document made before this field existed. Same shape and
				// same reading as `special`: see resolveSpecialMovement in combat-rules.mjs.
				secondSpecialName: new fields.StringField({ required: true, initial: "" }),
				secondSpecial: new fields.SchemaField({
					hourly:           new fields.StringField({ required: true, initial: "" }),
					hourlyMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					hourlyMod:        new fields.NumberField({ required: true, initial: 0 }),
					tenSec:           new fields.StringField({ required: true, initial: "" }),
					tenSecMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					tenSecMod:        new fields.NumberField({ required: true, initial: 0 }),
					oneSec:           new fields.StringField({ required: true, initial: "" }),
					oneSecMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					oneSecMod:        new fields.NumberField({ required: true, initial: 0 })
				}),
				jumpStand: new fields.NumberField({ required: true, initial: 0 }),
				jumpUp:    new fields.NumberField({ required: true, initial: 0 })
			}),

			// @MARKER SLIGHT PHYSIQUE
			// What changes for a member of this race who is of slight build, where anything does.
			//
			// Slight Physique in the original rules was the modifier carried by every female of
			// every race. When he built the Roll20 sheet he cut it loose from gender and made it a
			// choice any character may take -- so a stronger female or a slighter male are both
			// ordinary characters now. He confirmed this on 2026-09-20.
			//
			// For all but a handful of races it is only -1 Strength and +1 Agility, which is
			// applied to the ratings and needs nothing here. ONE race still carries a second,
			// larger difference here: GREMLIN flies either way, and its ordinary form gains Climb
			// instead. That trade is the reason this block exists: it cannot be derived from the
			// ordinary row, so both forms are carried and the character's own choice picks
			// between them.
			//
			// FAIRY, FAIRY(DARK), PODLING and SPORELING used to be here too -- each had WINGS in
			// the slight form and none in the ordinary one, and the two Fairies traded that flight
			// for extra racial skills (a wingless Dark Fairy gained Climb and Wood Lore +10%, a
			// wingless Fairy gained Climb and Cover Tracks). As of 2026-09-21 they no longer use
			// this block: his sheet's wings-ARE-slight-physique branch became a second dropdown,
			// and the port split each of the four into a winged and a wingless race document of
			// its own (`Fairy(Winged)`, `Fairy(Wingless)`, and so on) instead of one document with
			// a variant. See @MARKER RACE FORMS below, `physiqueLock`, and DECISIONS.md
			// 2026-09-21 "The races he split with a second dropdown become races of their own".
			//
			// `hasVariant` is false for the hundred-odd races where the two forms are identical
			// (now including those eight split forms, each a single document with no variant of
			// its own), and the rest of the block is then ignored.
			slightPhysique: new fields.SchemaField({
				hasVariant:   new fields.BooleanField({ required: true, initial: false }),
				specialName:  new fields.StringField({ required: true, initial: "" }),
				special: new fields.SchemaField({
					hourly:           new fields.StringField({ required: true, initial: "" }),
					hourlyMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					hourlyMod:        new fields.NumberField({ required: true, initial: 0 }),
					tenSec:           new fields.StringField({ required: true, initial: "" }),
					tenSecMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					tenSecMod:        new fields.NumberField({ required: true, initial: 0 }),
					oneSec:           new fields.StringField({ required: true, initial: "" }),
					oneSecMultiplier: new fields.NumberField({ required: true, initial: 0 }),
					oneSecMod:        new fields.NumberField({ required: true, initial: 0 })
				}),
				// Empty where the slight form's skills match the ordinary form's.
				racialSkills: new fields.ArrayField(new fields.SchemaField({
					name:  new fields.StringField({ required: true, initial: "" }),
					bonus: new fields.StringField({ required: true, initial: "" })
				}), { initial: [] }),
				canSwim: new fields.BooleanField({ required: true, initial: false })
			}),

			// @MARKER RACE FORMS
			// Five of his races are one dictionary entry and more than one race a character can be,
			// because his sheet asks a SECOND question beside the race picker and writes the answer
			// into the name: "Maginos[Clay]", or the slight-physique tick for the faeries. A Foundry
			// race is an Item with no second dropdown to hang off it, so each form is a race
			// document of its own -- the call already made for the classes that split on good/evil.
			//
			// sourceRace is HIS name for the race, and it is what every table keyed by race name is
			// looked up under: the racial skills, the abilities, the fertility list, the ages, the
			// body type, the colours, and the height band. For every other race it is the race's own
			// name, so a reader never has to know which kind they are holding.
			sourceRace: new fields.StringField({ required: true, initial: "" }),

			// Which physique this form is, where the form IS a physique -- "slight" for a winged
			// faerie, "ordinary" for a wingless one, empty for every other race.
			//
			// In his code the slight-physique branch of Fairy, Fairy(Dark), Podling and Sporeling is
			// the branch that sets "Fly:" and the ordinary branch sets "None:", so for those four,
			// slight build is what wings ARE. Michael's call, 2026-09-21: the two are one choice.
			// The generator therefore forces the tick on for a winged form and off for a wingless
			// one, and does not offer it. Gremlin is not one of these -- it flies either way -- and
			// keeps the free choice.
			physiqueLock: new fields.StringField({
				required: true, initial: "", blank: true,
				choices: ["", "slight", "ordinary"]
			}),

			// @MARKER FORMLESS
			// The races a formless race may inhabit. Empty for every race but Formless itself.
			//
			// A Formless is a free-floating psyche and supplies only the MENTAL half of a
			// character: his case at sheet-worker.js:33625 sets INT/WIS/KNW/CHM/AUR/PTY/WIL and
			// touches nothing physical, and setFormlessStartingRace (34880) takes STR/AGL/VIT/APP/
			// SOC, starting Endurance, Perception, movement, jump and swimming from the host. So
			// the character holds TWO race items, as a Half Race does -- but they are not averaged,
			// they are two halves of one whole, and combineFormless puts them together.
			//
			// 106 of his races may be hosts. A Changeling cannot (its body is whatever form it
			// wears), nor a Mechanos, nor Giant(Civilized:Seafaring), and neither Famorian,
			// Maginos nor another Formless is on his list.
			formlessHosts: new fields.ArrayField(new fields.StringField(), { initial: [] }),

			// @MARKER FAMORIAN
			// A Famorian is beast-blooded and its body is BUILT rather than fixed: a d100 gives its
			// breed, the breed says how many "evokes" -- beast traits -- it may take, and the
			// evokes are chosen from a catalogue of about 120. Empty for every race but Famorian.
			//
			// The race's own figures are a Famorian that has taken NO evokes, which is his own
			// else branch throughout the case at sheet-worker.js:33032. Only fifteen evokes change
			// a number; module/famorian-rules.mjs holds those fifteen and cites his line for each,
			// and the rest are described abilities, listed and not applied, as racial abilities
			// already are.
			famorian: new fields.SchemaField({
				isFamorian: new fields.BooleanField({ required: true, initial: false }),
				// The d100 breed table: which band, and what it allows.
				breeds: new fields.ArrayField(new fields.SchemaField({
					breed:  new fields.StringField({ required: true, initial: "" }),
					low:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
					high:   new fields.NumberField({ required: true, integer: true, initial: 0 }),
					// A dice expression, a number, or "All".
					evokes: new fields.StringField({ required: true, initial: "" }),
					when:   new fields.StringField({ required: true, initial: "" })
				}), { initial: [] }),
				// The catalogue. `key` is his own checkbox name, which is what a character stores.
				evokes: new fields.ArrayField(new fields.SchemaField({
					key:    new fields.StringField({ required: true, initial: "" }),
					label:  new fields.StringField({ required: true, initial: "" }),
					detail: new fields.StringField({ required: true, initial: "" })
				}), { initial: [] })
			}),

			// @MARKER TRAITS
			// formless marks a race with no fixed body, which matters to the body chart and to
			// transformation. canSwim is stored per race because it is not universal.
			formless: new fields.BooleanField({ required: true, initial: false }),
			canSwim:  new fields.BooleanField({ required: true, initial: false }),

			// The body chart this race uses, by name -- one of the 45 in BODY_CHARTS
			// (module/combat-tables.mjs), taken from getRacialBodyType in the original sheet.
			// Evoke mutations (extra torsos, limbs, wings, tails) add areas on top of the
			// chart in his sheet; that part is not modelled yet.
			bodyType: new fields.StringField({ required: true, initial: "Humanoid" }),

			// @MARKER RACIAL SKILLS
			// The racial skills a member of this race may choose from, with his bonus on each
			// ("+10%", or blank), from raceSkillDetailValues (getRaceSkillDetails). How MANY may
			// be chosen is not the race's -- Knowledge sets it. The note is his third column, which
			// is empty for every race but one ("Evoke (special type: Tree)" for the Dryad).
			racialSkills: new fields.ArrayField(new fields.SchemaField({
				name:  new fields.StringField({ required: true, initial: "" }),
				bonus: new fields.StringField({ required: true, initial: "" })
			})),
			racialSkillNote: new fields.StringField({ required: true, initial: "" }),

			// @MARKER COLOURING
			// The hair, eye and skin colours a member of this race is found in, from his
			// raceFeatureHair / raceFeatureEyes / raceFeatureSkin. Offered as choices at character
			// creation rather than enforced: his sheet lists them and lets the player type anything.
			// A race with none -- a construct, an elemental -- carries an empty list, which is an
			// answer rather than a gap.
			features: new fields.SchemaField({
				hair: new fields.ArrayField(new fields.StringField()),
				eyes: new fields.ArrayField(new fields.StringField()),
				skin: new fields.ArrayField(new fields.StringField())
			}),

			// @MARKER RACIAL ABILITIES
			// By name, from raceFeatureAbilities (getRacialFeatureAbilities). These are the names
			// his trait compendia describe (abilities, disabilities, immunities). They are listed,
			// not applied: his racial mechanics switch (setTempRacialAbilities) is not ported yet.
			abilities:    new fields.ArrayField(new fields.StringField()),
			disabilities: new fields.ArrayField(new fields.StringField()),
			immunities:   new fields.ArrayField(new fields.StringField()),

			// @MARKER NATURAL WEAPONS
			// The natural weapons a member of this race is born with, by name -- documents in the
			// weapons pack ("Saurian Claws"), from his setRacialNaturalAttacks (sheet-worker.js:100946).
			// A character gets them as ordinary weapons when the race is given to them, and may
			// delete any they do not want. physique is "slight" or "ordinary" for the one attack his
			// switch gives to only one physique (the Apocritara's Stinger), and blank for the rest.
			naturalWeapons: new fields.ArrayField(new fields.SchemaField({
				name:     new fields.StringField({ required: true, initial: "" }),
				physique: new fields.StringField({ required: true, blank: true, initial: "",
				              choices: ["", "slight", "ordinary"] })
			}), { initial: [] }),

			// @MARKER MIXED RACES
			// The races this one can have children with, from racefertiledict -- the list his
			// Half Race picker offers as the second race. Empty means it cannot breed outside itself.
			fertileWith: new fields.ArrayField(new fields.StringField()),

			// @MARKER AGES
			// From getAge: the range a new character's age is rolled within, and the maximum age,
			// which is a number of years or a word ("Immortal") -- so it is text.
			ages: new fields.SchemaField({
				startLow:  new fields.NumberField({ required: true, integer: true, initial: 0 }),
				startHigh: new fields.NumberField({ required: true, integer: true, initial: 0 }),
				maxAge:    new fields.StringField({ required: true, initial: "" })
			}),

			// @MARKER PROVENANCE
			sourcebook:  new fields.StringField({ required: true, initial: "" }),
			page:        new fields.StringField({ required: true, initial: "" }),
			description: new fields.HTMLField({ required: true, initial: "" })
		};
	}

	// @MARKER ADD NEW race data model functions HERE
}
// @END (CODE)
