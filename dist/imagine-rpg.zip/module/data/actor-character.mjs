// @START (CODE)
// @MARKER CHARACTER ACTOR DATA MODEL
//==================================================================================================================
// Schema for a player character in the Imagine Role Playing System.
//
// Field names follow the Roll20 sheet's attributes where they map cleanly, so this can be
// diffed against the original sheet-worker. Anything DERIVED is listed in the comments but
// is NOT stored here -- it is computed in prepareDerivedData() from the attribute tables.
//
// Derivation order matters and is documented in docs/DATA-MODEL.md section 9. The short
// version: attributes -> saves and modifiers -> Endurance -> Shock -> body area maxima.
// Changing Endurance recomputes every body area, exactly as changeCharacteristics() does
// in the original sheet.
//==================================================================================================================

import { ATTRIBUTE_TABLES } from "../config-tables.mjs";
import { explainAvailability } from "../availability.mjs";
import {
	getAttackSkillForTitle, getBodyChart, getAreaEndurance, getStrongestMaterial,
	getInitiativeModifier, getAreaArmor, getAreaShield, getNextAttackSkill, hasLore, parseLoreList,
	getMovementBase, resolveMovementRate, resolveSpecialMovement, specialMovementReplacesOther,
	getOffhandSecondsCap, getBetterAttackSkill, resolveEncumbrance, resolveLoadedMovement,
	getSecondWeaponSlots, resolveSituationalMods, getShockBar, getEncumbranceBand, getWeightDamageAdjust
} from "../combat/combat-rules.mjs";
import { getSlotAllowance } from "../skills-rules.mjs";
import { getTempEffects, resolveTempSpecialMovement } from "../temp-mods-rules.mjs";
import { isChangelingRace, getChangelingFormMods, applyChangelingForm, getFormlessControl,
         CHANGELING_NATURAL } from "../shape-change-rules.mjs";
import { combineHalfRace, getHalfRaceName, isClassBlockedForRaces, canRacesBreed,
	readFormlessPair, combineFormless, resolvePhysiqueLock, getStartingEnduranceMod } from "../race-rules.mjs";
import { applyFamorianEvokes, checkEvokeBudget, describeEvokes } from "../famorian-rules.mjs";
import { buildClassProgression, getClassSkillsToGrant, getClassUsageRestrictions,
         checkClassSkillTitle, countClassSlotsNeeded, getWholeCareerRows } from "../class-rules.mjs";
import { checkClassQualification } from "../chargen-rules.mjs";
import { getNextGoalExp, getExpCap, checkArchMortalQualification } from "../advancement-rules.mjs";
import { MARTIAL_DISCIPLINE_NAMES, getStanceSkillBonus, deriveMartialArts } from "../combat/martial-arts.mjs";
import { getAuraControl, getAuraPool, getAuraRegen, getPietyControl } from "../casting-rules.mjs";
import { getSkillStanding } from "../lore-rules.mjs";
import { getWeaponProfTotals, getChoiceSlots } from "../weapon-choices-rules.mjs";
import { getEquippedArmorSet, isConfigLearned, applyArmorSkills, ARMOR_KNOWLEDGE_BASE,
         ARMOR_PENALTY_SKILLS, describeArmorSkillsLine } from "../armor-know-rules.mjs";
import { CASTING_SKILLS } from "../lore-tables.mjs";
import { getRacialCombatMods } from "../combat/racial-combat-rules.mjs";

const fields = foundry.data.fields;

	// This is the function which builds the schema shared by all twelve attributes.
	// Rating is the stored value; permMod and tempMod are the permanent and temporary
	// adjustments the original sheet kept in attr_perm_*_mod and attr_tmp_*_mod.
	// The save percentage and every derived modifier come from the attribute tables.
	function attributeField(label) {
		return new fields.SchemaField({
			rating:  new fields.NumberField({ required: true, integer: true, initial: 10, min: 0, max: 30, label: label }),
			permMod: new fields.NumberField({ required: true, integer: true, initial: 0 }),
			tempMod: new fields.NumberField({ required: true, integer: true, initial: 0 })
		});
	}

	// This is the function which builds the schema for a derived characteristic.
	// Endurance, Perception, Affinity and Fortune all work the same way: a base value
	// calculated from attributes, plus a racial modifier, plus bonuses rolled on title
	// advancement, plus permanent and temporary adjustments.
	function characteristicField() {
		return new fields.SchemaField({
			titleBonus: new fields.NumberField({ required: true, integer: true, initial: 0 }),
			raceMod:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
			permMod:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
			tempMod:    new fields.NumberField({ required: true, integer: true, initial: 0 })
		});
	}

	// This is the function which builds the schema for one resistance track.
	// The base chance comes from attributes and race; misc is the manual adjustment,
	// standing in for the sheet's various *_other fields.
	// A resistance can also be an outright immunity, which the original sheet handled by
	// replacing the percentage with the word "Immune" -- so it is a state, not a big number.
	function resistanceField() {
		return new fields.SchemaField({
			misc:   new fields.NumberField({ required: true, integer: true, initial: 0 }),
			immune: new fields.BooleanField({ required: true, initial: false })
		});
	}

	// This is the function which builds one movement rate. The Imagine system tracks
	// every movement mode at three scales at once: distance per hour, per 10 seconds
	// (one combat round) and per second.
	function movementRateField() {
		return new fields.SchemaField({
			hourly: new fields.NumberField({ required: true, initial: 0 }),
			tenSec: new fields.NumberField({ required: true, initial: 0 }),
			oneSec: new fields.NumberField({ required: true, initial: 0 })
		});
	}


export default class ImagineCharacterData extends foundry.abstract.TypeDataModel {

	static defineSchema() {
		return {

			// @MARKER IDENTITY
			// Race and class are not referenced by UUID here. They are embedded Items on the
			// actor, found during data preparation, because resolving a UUID synchronously
			// while preparing data is unreliable for compendium content that has not been
			// loaded yet. Dragging the race or class item onto the sheet is what sets them.
			identity: new fields.SchemaField({
				title:       new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				goal:        new fields.NumberField({ required: true, integer: true, initial: 0 }),
				exp:         new fields.NumberField({ required: true, integer: true, initial: 0 }),
				alignment:   new fields.StringField({ required: true, initial: "" }),
				tendencies:  new fields.StringField({ required: true, initial: "" }),
				gender:      new fields.StringField({ required: true, initial: "" }),

				// @MARKER THE LEVEL-UP QUEUE
				// Experience buys goals, and goals are walked one at a time rather than applied
				// in a lump: his titles_to_raise / goals_to_raise, and the step each points at.
				// While either is above zero a level-up is outstanding, and his sheet refuses to
				// add any more experience until it is finished (roll_add_exp, sheet-worker.js:8256).
				//
				// They are queued rather than applied because each step has a decision in it --
				// an attribute roll, skill points to place -- that only a player can make.
				titlesToRaise: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				goalsToRaise:  new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				titleToLevel:  new fields.NumberField({ required: true, integer: true, initial: 0 }),
				goalToLevel:   new fields.NumberField({ required: true, integer: true, initial: 0 }),

				// How many attribute increases the character has been given across their whole
				// career, which is what his minimum-increase floor at goals 12, 27 and 42 is
				// measured against (handleLevelGoal, sheet-worker.js:65704).
				attributeIncreases: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),

				// The one part of the Arch Mortal qualification nothing can check: his data gives
				// about half the classes a requirement written as a sentence ("Known for the
				// recovery of a lost lore spoken of in legend"), and only a Game Master can say
				// whether it has been met. Everything else on that screen is derived.
				archSpecialMet: new fields.BooleanField({ required: true, initial: false }),

				// @MARKER FORMLESS BODIES (OLD RECORD)
				// Free text the table kept before host changes were built (the 2026-09-22 stopgap). Kept,
				// not dropped, so nothing typed into it is lost: the Description tab shows it, read-only,
				// beside the record below, and only when something was ever written in it.
				formlessBodies: new fields.StringField({ required: true, initial: "" }),

				// @MARKER FORMLESS HOST
				// What his sheet keeps about the body a Formless wears (formless_current_host,
				// formless_host_type, formless_periods_occupied, formless_max_periods,
				// formless_period_type, temp_will_formless_free_psyche; sheet-worker.js:128133, 128300).
				// The host itself is the second race item, as at creation; these say how long it has
				// been held and how long it may be. hostHistory is the port's own: every body possessed,
				// oldest first, comma-separated -- his sheet keeps only the current one.
				formless: new fields.SchemaField({
					currentHost:     new fields.StringField({ required: true, blank: true, initial: "" }),
					hostType:        new fields.StringField({ required: true, blank: true, initial: "" }),
					periodType:      new fields.StringField({ required: true, blank: true, initial: "" }),
					periodsOccupied: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
					maxPeriods:      new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
					freePsycheWill:  new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
					hostHistory:     new fields.StringField({ required: true, blank: true, initial: "" })
				}),

				// @MARKER CHANGELING FORM
				// The form a Changeling wears (his race "Changeling[<form>]", sheet-worker.js:127309), the
				// form it was made in (orig_changeling_race), whether it has taken Slight Physique, and the
				// height it was made with (orig_height_*), which bounds every later form. "Natural Form" is
				// his own name for the Changeling's own body. The form's attribute changes are worked out
				// on every prepare (module/shape-change-rules.mjs), not written into the ratings.
				changeling: new fields.SchemaField({
					form:             new fields.StringField({ required: true, blank: true, initial: "" }),
					originalForm:     new fields.StringField({ required: true, blank: true, initial: "Natural Form" }),
					slight:           new fields.BooleanField({ required: true, initial: false }),
					origHeightInches: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 })
				})
				// DERIVED: titleName (from classtitledict), nextGoalExp, archMortal (the
				//          qualification screen), and the per-race attribute caps.
			}),

			// @MARKER ATTRIBUTES
			// The twelve attributes, grouped physical / mental / personal / mystical as the
			// Player's Guide presents them. Listed out individually rather than generated in a
			// loop so the set is visible at a glance.
			attributes: new fields.SchemaField({
				str: attributeField("Strength"),
				agl: attributeField("Agility"),
				vit: attributeField("Vitality"),
				int: attributeField("Intelligence"),
				wis: attributeField("Wisdom"),
				knw: attributeField("Knowledge"),
				app: attributeField("Appearance"),
				chm: attributeField("Charm"),
				soc: attributeField("Social Class"),
				aur: attributeField("Aura"),
				pty: attributeField("Piety"),
				wil: attributeField("Will Force")
				// DERIVED per attribute: max, save, and that attribute's table modifiers
				// (str -> meleeAttack/meleeDamage/loadLimit/weaponSpeed, and so on).
			}),

			// @MARKER CHARACTERISTICS
			// Endurance is the average of the three physical attributes rounded up, then
			// modified. Perception, Affinity and Fortune work the same way off other groupings.
			characteristics: new fields.SchemaField({
				endurance:  characteristicField(),
				perception: characteristicField(),
				affinity:   characteristicField(),
				fortune:    characteristicField()
			}),

			// @MARKER RESISTANCES
			resistances: new fields.SchemaField({
				magic:    resistanceField(),
				illusion: resistanceField(),
				control:  resistanceField(),
				poison:   resistanceField(),
				disease:  resistanceField()
			}),

			// @MARKER BODY AND WOUNDS
			// Imagine does not use a single hit point pool. Endurance is distributed across the
			// body areas of the character's body chart, and damage is tracked per area.
			//
			// The areas themselves are NOT stored. They come from the body chart -- the race's,
			// unless bodyType overrides it (a transformation, say) -- every time the character
			// is prepared. Only what happens to them is stored, keyed by area name: the wounds
			// each has taken and the damage its armour has taken. Keying by name rather than by
			// position means a change of race or body cannot slide existing wounds onto the
			// wrong limbs.
			body: new fields.SchemaField({
				bodyType:    new fields.StringField({ required: true, initial: "" }),  // "" = the race's
				wounds:      new fields.TypedObjectField(new fields.NumberField({ integer: true, min: 0 })),
				armorDamage: new fields.TypedObjectField(new fields.NumberField({ integer: true, min: 0 })),
				hide:        new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				// Damage to OVERALL Endurance, which lands on no one area -- a poison's, by the
				// user's ruling (Master's Manual p.103: "apply to overall Endurance"). It counts in
				// totalWounds, and so toward shock.
				overallWounds: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 })
				// DERIVED: areas (each with its Endurance, wounds, armour and state), shock,
				// totalWounds, inShock. See _prepareBody.
			}),

			// @MARKER MOVEMENT
			movement: new fields.SchemaField({
				walk:    movementRateField(),
				jog:     movementRateField(),
				run:     movementRateField(),
				special: movementRateField(),
				specialName: new fields.StringField({ required: true, initial: "" }),
				travelHours: new fields.NumberField({ required: true, initial: 0 }),
				restHours:   new fields.NumberField({ required: true, initial: 0 }),
				jumpStand:   new fields.NumberField({ required: true, initial: 0 }),
				jumpUp:      new fields.NumberField({ required: true, initial: 0 })
			}),

			// @MARKER PHYSICAL FEATURES
			physical: new fields.SchemaField({
				heightFeet:   new fields.NumberField({ required: true, integer: true, initial: 0 }),
				heightInches: new fields.NumberField({ required: true, integer: true, initial: 0 }),
				frame:        new fields.StringField({ required: true, initial: "" }),
				weight:       new fields.NumberField({ required: true, initial: 0 }),
				hair:         new fields.StringField({ required: true, initial: "" }),
				bodyCovering: new fields.StringField({ required: true, initial: "" }),
				eyes:         new fields.StringField({ required: true, initial: "" }),
				skin:         new fields.StringField({ required: true, initial: "" }),
				handedness:   new fields.StringField({ required: true, initial: "" }),

				// @MARKER FAMORIAN
				// What a Famorian character has made of itself. Empty for every other race.
				//
				// The breed is rolled once (a d100 on his table) and says how many evokes may be
				// taken; the evokes are his own checkbox keys; the three attribute evokes roll 1d3
				// each and the result is KEPT here rather than re-rolled, because a modifier that
				// changed on every re-render would not be a modifier. His animal type is required
				// before the race can be applied at all, which is why it is stored beside them.
				famorian: new fields.SchemaField({
					breed:       new fields.StringField({ required: true, initial: "" }),
					animalType:  new fields.StringField({ required: true, initial: "" }),
					// null-equivalent: -1 means "All", his breed with no ceiling.
					evokesAllowed: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					evokes:      new fields.ArrayField(new fields.StringField(), { initial: [] }),
					strBonus:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
					aglBonus:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
					vitBonus:    new fields.NumberField({ required: true, integer: true, initial: 0 })
				}),

				age:          new fields.NumberField({ required: true, integer: true, initial: 0 }),
				apparentAge:  new fields.NumberField({ required: true, integer: true, initial: 0 }),
				maxAge:       new fields.StringField({ required: true, initial: "" })
			}),

			// @MARKER LANGUAGES
			// How many a character may know is capped by Intelligence; the sheet tracked
			// speaking and writing separately because they have separate limits.
			languages: new fields.ArrayField(new fields.SchemaField({
				name:  new fields.StringField({ required: true, initial: "" }),
				speak: new fields.BooleanField({ required: true, initial: true }),
				write: new fields.BooleanField({ required: true, initial: false })
			})),

			// @MARKER WEALTH
			wealth: new fields.SchemaField({
				copper:   new fields.NumberField({ required: true, integer: true, initial: 0 }),
				silver:   new fields.NumberField({ required: true, integer: true, initial: 0 }),
				gold:     new fields.NumberField({ required: true, integer: true, initial: 0 }),
				platinum: new fields.NumberField({ required: true, integer: true, initial: 0 }),
				special:  new fields.StringField({ required: true, initial: "" }),
				gems:     new fields.StringField({ required: true, initial: "" }),
				jewelry:  new fields.StringField({ required: true, initial: "" })
			}),

			// @MARKER SKILL SLOT TRICKS
			// How many times each of the Player's Guide's slot trades has been made, and how many
			// slots have been given up outright for a bonus. The Knowledge table's allowance is
			// derived; these are the only stored part, because a trade is a decision rather than a
			// calculation and nothing else on the character records that it happened.
			//
			// Kept as counts rather than as a list of moves: his sheet stores exactly the same
			// thing (tmp_race_skill_slots_removed and its siblings), a move is not undoable once
			// the slot it opened has been filled, and the arithmetic in getSlotAllowance only ever
			// needs how many. The 2d4% a sacrifice grants is not here -- it is rolled once and
			// added to the chosen skill's own modifier, which is where a permanent bonus belongs.
			skillSlotMoves: new fields.SchemaField({
				racialToClass:    new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				racialToSocial:   new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				socialToRacial:   new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				socialToClass:    new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				racialSacrificed: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				socialSacrificed: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 })
			}),

			// @MARKER COMBAT ADJUSTMENTS
			// Everything granted by race, class, magic or condition arrives as an Active Effect.
			// These misc fields are the manual override the Game Master can always reach for,
			// and stand in for the original sheet's combat_mod_*_other attributes.
			combat: new fields.SchemaField({
				meleeMisc:      new fields.NumberField({ required: true, integer: true, initial: 0 }),
				missileMisc:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
				damageMisc:     new fields.NumberField({ required: true, integer: true, initial: 0 }),
				defenseMisc:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
				initiativeMisc: new fields.NumberField({ required: true, integer: true, initial: 0 }),
				skillMisc:      new fields.NumberField({ required: true, integer: true, initial: 0 }),

				// @MARKER SPEED SECONDS
				// Extra seconds of action every round from a Speed potion, spell, rune or glyph -- his
				// tmp_speed_seconds, the "Speed Seconds" box among his combat modifiers. Set by hand until
				// those effects are built. Each splits one of the round's first seconds in two on the
				// round clock (module/combat/round-rules.mjs); ten at most, with any the initiative
				// roll itself earned below -10.
				speedSeconds:   new fields.NumberField({ required: true, integer: true, initial: 0, min: 0, max: 10 }),

				// The attack chart a GME fights on. A GME earns no chart by title -- his sheet has the
				// player pick one outright (gme_all_attack_skills_select, Beginner by default) -- so it
				// is stored. Read only while the character holds a non-classed class.
				chosenAttackSkill: new fields.StringField({ required: true, initial: "Beginner",
					choices: ["Beginner", "Novice", "Intermediate", "Advanced", "Expert", "Master"] }),

				// @MARKER PAIN THRESHOLD
				// A SIGNED modifier on every point of damage coming in, applied before armour
				// and before anything magical takes its share. His own note beside the field
				// reads "reduces or adds to all incoming damage (-/+)", so a negative number is
				// a tougher target. (sheet-worker.js:71186-71193, and his sheet at line 56643.)
				painThreshold: new fields.NumberField({ required: true, integer: true, initial: 0 }),

				// The Famorian "High Pain Threshold" evoke, worth one further point off. Nothing
				// sets this yet -- the evoke system is a separate piece of work -- but the field
				// exists so a Game Master can tick it and so the evoke has somewhere to land.
				highPainThreshold: new fields.BooleanField({ required: true, initial: false }),

				// @MARKER DAMAGE ABSORPTION
				// A POOL, not a per-blow reduction. It takes what it can off a blow after armour
				// and hide have had theirs, and is spent by the same amount, so it wears out.
				// (sheet-worker.js:71359-71366.) His checkSpiritForceArmorModifiers refills it to
				// the best of a "Rune Absorption: +N" on worn armour and the Game Master's own
				// modifier whenever equipment changes; runes are a deferred subsystem, so for now
				// the pool is entered and spent by hand.
				damageAbsorb: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),

				// @MARKER MAGICAL PROTECTION
				// These all come off a blow BEFORE any worn armour is asked to block it, in the
				// order his handler applies them (sheet-worker.js:71249-71272). They subtract
				// rather than scale, and each is the BEST of what worn magic items grant and the
				// Game Master's own modifier rather than a sum of them -- which is what his
				// checkSpiritForceArmorModifiers (line 106966) works out. The items that grant
				// them are named by the deferred magic subsystems, so for now these are entered
				// by hand.
				spiritArmor:  new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				forceArmor:   new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				outerKinetic: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				magicShield:  new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),

				// Invulnerability scales rather than subtracts: a weapon with no magical plus
				// does nothing at all, +1/+2 a quarter, +3/+4 a half, +5 and better full damage.
				invulnerable: new fields.BooleanField({ required: true, initial: false }),

				// @MARKER LORE
				// The weapons this character has SPECIFIC Weapon or Missile Lore in, by name.
				// His sheet keeps each as one comma-separated string of simplified names
				// (weapon_lore_list / missile_lore_list); an array is the same thing without the
				// parsing. Having the lore at all comes from the class and the title, so it is
				// derived rather than stored -- these lists only say which weapons are singled
				// out for the larger bonus.
				// Kept as one comma-separated string each, which is his shape exactly
				// (weapon_lore_list / missile_lore_list). A plain string is also the only thing a
				// text field on the sheet can write back, and the parsed arrays are derived.
				weaponLoreList:  new fields.StringField({ required: true, initial: "" }),
				missileLoreList: new fields.StringField({ required: true, initial: "" }),

				// Projectile Lore names AMMUNITION, not the weapon in hand -- an Arrow rather
				// than the Long Bow that fires it. Only six of his 92 classes ever acquire it.
				projectileLoreList: new fields.StringField({ required: true, initial: "" }),

				// @MARKER WEAPON PROFICIENCIES
				// The weapons this character is proficient with, by simplified name -- his weapon_prof_list. One
				// for every whole 10% of Weapon Knowledge; a weapon not on it is at a penalty to hit, once the list
				// has been started (module/weapon-choices-rules.mjs). Ammunition is never on it: an arrow is
				// proficient through its bow.
				weaponProfList: new fields.StringField({ required: true, initial: "" }),

				// The projectiles learned with Projectile Knowledge, his proj_know_list: each one's medium range
				// is pushed out 20% for every 20% of the skill (getProjectileKnowledgeRanges).
				projectileKnowList: new fields.StringField({ required: true, initial: "" }),

				// The launcher/missile combinations learned for firing more than one missile at a
				// time. These are NOT a list of weapons singled out for a larger bonus, the way
				// the three lists above are -- both multi-missile skills are learned one
				// combination at a time ("a skill roll is required to learn each particular
				// combination of missile weapon type and projectile type", Master's Manual), so an
				// entry here is what makes the skill apply at all.
				//
				// Each entry is "Launcher/Missile" -- "Long Bow/Arrow", or "Thrown/Dagger" for a
				// weapon thrown from the hand -- which is his shape (multi_missile_know_list /
				// multi_missile_lore_list).
				multiMissileKnowList: new fields.StringField({ required: true, initial: "" }),
				multiMissileLoreList: new fields.StringField({ required: true, initial: "" }),

				// The weapons this character fights with in the off hand under Second Weapon
				// Knowledge or Lore, by simplified name -- his second_know_list / second_lore_list.
				// A weapon only takes the discipline's benefit when it is named here; see
				// getSecondWeaponFlags in combat-rules.mjs.
				secondWeaponKnowList: new fields.StringField({ required: true, initial: "" }),
				secondWeaponLoreList: new fields.StringField({ required: true, initial: "" }),

				// @MARKER ARMOR KNOWLEDGE AND LORE
				// The armour configurations learned, as his armor_know_list / armor_lore_list: the pieces
				// of one set joined with "|", the sets with ",". Wearing a learned set eases the armour's
				// penalties (_prepareArmorSkills; module/armor-know-rules.mjs).
				armorKnowList: new fields.StringField({ required: true, blank: true, initial: "" }),
				armorLoreList: new fields.StringField({ required: true, blank: true, initial: "" }),

				// @MARKER BRAWLING
				// What the Brawling window has chosen to brawl with -- his all_brawling_weapons, a
				// name off the Brawling Weapons Table (module/combat/brawling-rules.mjs), or "". Stored
				// as his sheet stores it, so the window opens on the last thing used.
				brawlingWeapon: new fields.StringField({ required: true, blank: true, initial: "" }),

				// @MARKER GRAPPLING
				// The move the Grappling window has chosen -- his all_grapple_moves, a name off his
				// grappling table (module/combat/grappling-rules.mjs), or "".
				grapplingMove: new fields.StringField({ required: true, blank: true, initial: "" }),

				// @MARKER SOLDIERING WEAPON
				// The one weapon the social skill Soldiering makes +1 to hit and +1 damage -- his
				// combat_soldiering_weapon_name, a simplified weapon name, "" until one is chosen in the
				// Updater (module/apps/soldiering.mjs). Whether the skill is held is derived
				// (combat.hasSoldiering); the rules are module/soldiering-rules.mjs.
				soldieringWeapon: new fields.StringField({ required: true, blank: true, initial: "" }),

				// @MARKER SITUATION MODS
				// What the Situation Mods window has ticked, which every attack of that kind reads
				// until it is cleared -- his situational_mod_* bar. Stored, because it outlives any
				// one attack and because the character's own defence changes with it while others
				// attack them. Totalled by resolveSituationalMods in combat-rules.mjs.
				situation: new fields.SchemaField({
					// blank: true outright -- Foundry sets it false the moment choices are given, which
					// is what failed the first real import (see commit 3374e19).
					kind:     new fields.StringField({ required: true, blank: true, initial: "", choices: ["", "melee", "missile"] }),
					selected: new fields.ArrayField(new fields.StringField({ required: true, blank: false })),
					// The weapon whose skills modifier a roll for Critical, Perfect Shot and the rest
					// is made with -- his sit_weapon_slot_melee / sit_weapon_slot_missile.
					weaponId: new fields.StringField({ required: true, initial: "" })
				})
			}),

			// @MARKER TEMPORARY MODIFIERS
			// What his "Add/Remove Temporary Modifiers" panel holds that has no slot of its own elsewhere
			// (module/temp-mods-rules.mjs has the table of where every modifier lives; module/apps/
			// temp-modifiers.mjs is the window). The rest of his rows reuse fields that already exist --
			// attributes.<k>.tempMod, characteristics.<k>.tempMod, resistances.<k>.misc and the combat
			// *Misc fields -- so nothing is held twice.
			tempMods: new fields.SchemaField({
				// The MAGIC half of an attribute modifier (tempMod above is the mundane half). Held to the
				// attribute's magical maximum rather than its natural one, as his tmp_mod_<attr>_magic is.
				magicAttr: new fields.SchemaField({
					str: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					agl: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					vit: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					int: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					wis: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					knw: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					app: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					chm: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					soc: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					aur: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					pty: new fields.NumberField({ required: true, integer: true, initial: 0 }),
					wil: new fields.NumberField({ required: true, integer: true, initial: 0 })
				}),

				// Movement. Walk, jog, run and the special rate each take ONE figure that becomes three: hourly,
				// x10 for ten seconds, x1 for one second (his tmp_walk_mod and the rest).
				walk:      new fields.NumberField({ required: true, initial: 0 }),   // tmp_walk_mod
				jog:       new fields.NumberField({ required: true, initial: 0 }),   // tmp_jog_mod
				run:       new fields.NumberField({ required: true, initial: 0 }),   // tmp_run_mod
				special:   new fields.NumberField({ required: true, initial: 0 }),   // tmp_move_special_mod
				dailyMove: new fields.NumberField({ required: true, initial: 0 }),   // tmp_move_daily_move_mod
				dailyRest: new fields.NumberField({ required: true, initial: 0 }),   // tmp_move_daily_rest_mod
				standJump: new fields.NumberField({ required: true, initial: 0 }),   // tmp_move_stand_jump_mod
				upJump:    new fields.NumberField({ required: true, initial: 0 }),   // tmp_move_up_jump_mod
				// A temporary multiplier that replaces the racial one; 1 is none (tmp_multi_mod).
				moveMulti: new fields.NumberField({ required: true, initial: 1 }),
				// The special movement type that replaces the race's ("" = the race's own), and its speed
				// multiplier (temp_special_move, temp_special_speed_mod).
				specialType:  new fields.StringField({ required: true, blank: true, initial: "" }),
				specialSpeed: new fields.NumberField({ required: true, initial: 1 }),

				// Combat figures with no field of their own.
				weaponSpeed: new fields.NumberField({ required: true, integer: true, initial: 0 }),   // tmp_weapon_speed_mod
				extraDice:   new fields.NumberField({ required: true, integer: true, initial: 0 }),   // tmp_extra_dice
				extraPerDie: new fields.NumberField({ required: true, integer: true, initial: 0 }),   // tmp_extra_per_die
				fumble:      new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),   // tmp_fumble_mod
				calledShot:  new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),   // tmp_calledshot_mod
				ambidextrous: new fields.BooleanField({ required: true, initial: false }),   // tmp_ambidextrous
				shockImmune:  new fields.BooleanField({ required: true, initial: false }),   // tmp_mod_shock_immunity

				// Equipment: multipliers on what is carried and on what may be (tmp_equip_weight_mod,
				// tmp_equip_capacity_mod). 2 is x2, .5 is x1/2; 1 is none.
				weightMulti:   new fields.NumberField({ required: true, initial: 1 }),
				capacityMulti: new fields.NumberField({ required: true, initial: 1 }),

				// Fatigue and mental fatigue (tmp_fatigue_level, tmp_mental_fatigue_level and their immunities).
				fatigue: new fields.SchemaField({
					level:        new fields.NumberField({ required: true, integer: true, initial: 0, min: 0, max: 10 }),
					immune:       new fields.BooleanField({ required: true, initial: false }),
					mentalLevel:  new fields.NumberField({ required: true, integer: true, initial: 0, min: 0, max: 10 }),
					mentalImmune: new fields.BooleanField({ required: true, initial: false })
				}),

				// Where the BERSERK / AFTER / CLEAR buttons have got to: "", "berserk" or "after".
				berserk: new fields.StringField({ required: true, blank: true, initial: "" })
			}),

			// @MARKER MARTIAL ARTS
			// What a martial artist KNOWS and what they have IN PLAY, kept as his sheet keeps them:
			// comma-separated strings of names (martial_know_attacks, martial_lore_list,
			// martial_stance_list and the rest), so a text field can write one back and his lists
			// read across unchanged. Everything worked out from them -- the rows with their chances
			// and times, what a stance or a made move does -- is derived in _prepareMartialArts.
			//
			// The discipline is chosen once, when Martial Knowledge is acquired, and brings its own
			// list of subskills (MARTIAL_DISCIPLINES). The learned* strings hold what is known
			// BEYOND it: a Custom discipline's picks, and anything added later with Martial Lore.
			martial: new fields.SchemaField({
				discipline:       new fields.StringField({ required: true, blank: true, initial: "",
					choices: ["", ...MARTIAL_DISCIPLINE_NAMES] }),
				learnedAttacks:   new fields.StringField({ required: true, blank: true, initial: "" }),
				learnedBlocks:    new fields.StringField({ required: true, blank: true, initial: "" }),
				learnedHolds:     new fields.StringField({ required: true, blank: true, initial: "" }),
				learnedMoves:     new fields.StringField({ required: true, blank: true, initial: "" }),
				learnedThrows:    new fields.StringField({ required: true, blank: true, initial: "" }),
				// The twelve Martial Lore values learned, his martial_lore_list.
				loreValues:       new fields.StringField({ required: true, blank: true, initial: "" }),
				// Stances learned with Martial Knowledge, and those mastered with Martial Lore -- his
				// martial_stance_list and martial_mastered_stances_list.
				stances:          new fields.StringField({ required: true, blank: true, initial: "" }),
				masteredStances:  new fields.StringField({ required: true, blank: true, initial: "" }),
				// In play. Only one stance at a time (Mysteries of the Planes p.167). A move or Lore
				// value is here once its skill roll has been made, and stays until cleared -- his
				// martialN_move_success boxes and the SET/CLEAR buttons beside them.
				activeStance:     new fields.StringField({ required: true, blank: true, initial: "" }),
				activeMoves:      new fields.StringField({ required: true, blank: true, initial: "" }),
				activeLoreValues: new fields.StringField({ required: true, blank: true, initial: "" }),
				// The two things a stance's bonuses depend on that only the player can say: VIT saves
				// failed for intoxication (the Drunken stance works from 1 to 3, 5 mastered), and
				// whether a hold or movement effect is being resisted now (Calm in the storm).
				intoxication:     new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),
				resistingHold:    new fields.BooleanField({ required: true, initial: false })
			}),

			// @MARKER MAGIC
			// What casting and invoking keep between one cast and the next -- his Aura and Divine
			// panels. Aura Control, the pool's size, Piety Control and the rest are DERIVED from class,
			// title and attributes (_prepareMagic, module/casting-rules.mjs); only these are stored:
			//                                                                     his attribute
			magic: new fields.SchemaField({
				drainedAura:      new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }), // drained_aura
				additionalAura:   new fields.NumberField({ required: true, integer: true, initial: 0 }),         // additional_aura
				auraControlBoost: new fields.NumberField({ required: true, integer: true, initial: 0 }),         // aura_control_boost
				auraRegenDouble:  new fields.BooleanField({ required: true, initial: false }),                   // aura_regen_double
				magicSuppressed:  new fields.BooleanField({ required: true, initial: false }),                   // magic_suppression
				halfMagic:        new fields.BooleanField({ required: true, initial: false }),                   // half_magic
				pietyLevelBoost:  new fields.NumberField({ required: true, integer: true, initial: 0 }),         // piety_level_boost
				divineDenial:     new fields.BooleanField({ required: true, initial: false }),                   // divine_denial
				// The devotions an invoker prays through, comma-separated as his current_devotions is,
				// and his tick to ignore them.
				devotions:        new fields.StringField({ required: true, blank: true, initial: "" }),         // current_devotions
				ignoreDevotions:  new fields.BooleanField({ required: true, initial: false }),                   // ignore_devotions
				// "Spell: Fly, Invoke: Chill" -- what the caster has running on themselves. His cases
				// read it to refuse a second copy ("already in use"); a cast adds to it and the tab's
				// cross takes one off. His tmp_effect_list, holding only these.
				effectList:       new fields.StringField({ required: true, blank: true, initial: "" })          // tmp_effect_list
			}),

			// @MARKER GM EXPERIENCE TOOLS
			// What the Game Master has set on his Character Sheet Config tab for valuing this character in
			// experience (module/gm-exp-rules.mjs): whether the value is shown at the bottom of the main
			// tab (show_experience_value), and his Experience Bonuses ticks (exp_poison_type, exp_slaying,
			// exp_character_class, exp_caster, exp_damage_touch, exp_drain_touch, exp_breath_attk,
			// exp_convert, exp_gaze_attk, exp_chameleon, exp_mind_control, exp_invisibility). The value
			// itself is worked out from the character each time it is shown, not stored.
			gmExp: new fields.SchemaField({
				show:           new fields.BooleanField({ required: true, initial: false }),
				poisonType:     new fields.StringField({ required: true, blank: true, initial: "" }),
				slaying:        new fields.BooleanField({ required: true, initial: false }),
				characterClass: new fields.BooleanField({ required: true, initial: false }),
				caster:         new fields.BooleanField({ required: true, initial: false }),
				damageTouch:    new fields.BooleanField({ required: true, initial: false }),
				drainTouch:     new fields.BooleanField({ required: true, initial: false }),
				breath:         new fields.BooleanField({ required: true, initial: false }),
				convert:        new fields.BooleanField({ required: true, initial: false }),
				gaze:           new fields.BooleanField({ required: true, initial: false }),
				chameleon:      new fields.BooleanField({ required: true, initial: false }),
				mindControl:    new fields.BooleanField({ required: true, initial: false }),
				invisibility:   new fields.BooleanField({ required: true, initial: false })
			}),

			// @MARKER NOTES
			biography: new fields.HTMLField({ required: true, initial: "" })
		};
	}

	//==========================================================================================
	// @MARKER BASE DATA
	//==========================================================================================
	// Everything Active Effects are allowed to target must exist by the end of this step,
	// because effects are applied between prepareBaseData and prepareDerivedData.
	//
	// The effect target is attributes.<attr>.value. Putting it here and deriving everything
	// else from it in the next step means a single "+2 Strength" effect correctly cascades
	// into the save, the melee and damage modifiers, load limit, Endurance, and every skill
	// governed by Strength -- rather than each of those needing its own effect.
	prepareBaseData() {
		super.prepareBaseData(); // required: skipping this silently breaks two-phase effects

		// Race and class are embedded items. Cache them here so every later step can reach
		// them without searching the collection again.
		//
		// A character may be of two races -- his Half Race (see module/race-rules.mjs). With two
		// race items, raceItem is NOT either of them: it is a stand-in carrying the combined race
		// his applyHalfRaceToAttribs would produce, in the same shape as a race item, so every
		// step below that reads raceItem.system reads the half race without knowing it is one.
		// raceItems is always the real items, in the order they were added; the first is the one
		// whose body and special movement a half race keeps.
		this.raceItems = this._findItems("race");
		// _getEffectiveRace reports two things: the race the rest of the model reads, and (a
		// Formless only) what is wrong with its host pairing. The second used to be written
		// straight to identity.formlessIssue from inside that function -- the only base-data step
		// that touched identity, which _prepareIdentity otherwise owns alone. Stashed here instead
		// and assigned there; see docs/sonnet/2026-09-21-formless-and-resistances.md item 6.
		var tmpeffectiverace = this._getEffectiveRace(this.raceItems);
		this.raceItem = tmpeffectiverace.race;
		this._formlessIssue = tmpeffectiverace.formlessIssue;

		// A character may hold more than one class. The Player's Guide allows a dual-classed
		// character who meets both classes' requirements, and his Roll20 sheet has no provision
		// for it at all -- one classname field and nothing else -- so this half is built from the
		// book rather than ported. classItem stays as the first one, which is what a single-classed
		// character has and what everything reading one class still wants; classItems is the whole
		// list, and the rules that combine two classes read that.
		this.classItems = this._findItems("class");
		this.classItem = this.classItems[0] ?? null;

		// Racial attribute modifiers are folded into the base, BEFORE effects, so that a
		// temporary magical bonus stacks on top of the racial baseline rather than competing
		// with it.
		var tmpracemods = this.raceItem ? this.raceItem.system.attributeMods : null;

		for (const tmpkey of Object.keys(this.attributes)) {
			var tmpattrib = this.attributes[tmpkey];
			var tmpracemod = (tmpracemods && tmpracemods[tmpkey]) ? tmpracemods[tmpkey] : 0;
			tmpattrib.raceMod = tmpracemod;
			tmpattrib.value = tmpattrib.rating + tmpracemod + tmpattrib.permMod + tmpattrib.tempMod;
		}

		// @MARKER CHANGELING FORM
		// A Changeling's form moves STR, AGL, VIT and APP as his updateChangelingAttributes did
		// (sheet-worker.js:127358), but worked out here every time rather than written into the
		// ratings, so switching back and forth cannot drift. Before effects, as a race's modifiers are.
		if (isChangelingRace(this.raceItems.map(tmprace => tmprace.name)) && this.identity.changeling?.form) {
			var tmpformmods = getChangelingFormMods(this.identity.changeling.form, this.identity.changeling.originalForm);
			var tmpbefore = {};
			for (const tmpkey of Object.keys(tmpformmods)) { tmpbefore[tmpkey] = this.attributes[tmpkey].value; }
			var tmpafter = applyChangelingForm(tmpbefore, tmpformmods, this.raceItem?.system?.attributeLimits);
			for (const tmpkey of Object.keys(tmpformmods)) {
				this.attributes[tmpkey].formMod = tmpafter[tmpkey] - tmpbefore[tmpkey];
				this.attributes[tmpkey].value = tmpafter[tmpkey];
			}
		}
	}

	// This is the function which works out the race a character actually has.
	//
	//     no race item        null
	//     one                 that item, as it is -- his One Race
	//     two                 a stand-in { name, system } holding the two combined as his Half
	//                         Race combines them (combineHalfRace), named "first|second" as his
	//                         full_race_name is
	//     three or more       the first two, as a Half Race. His Multi Race(3) and (4) are on his
	//                         race-type list but not implemented ("not yet implemented. Nothing
	//                         done."), so there is no rule of his to follow for a third race; the
	//                         extras are reported on identity.raceWarning rather than dropped silently.
	// Returns { race, formlessIssue } rather than the race alone -- the caller (prepareBaseData)
	// stashes formlessIssue on the instance, and _prepareIdentity is the one that writes it into
	// identity, the way every other identity.* field is set. See the note at the call site.
	_getEffectiveRace(tmpraceitems) {
		if (tmpraceitems.length == 0) { return { race: null, formlessIssue: "" }; }

		// @MARKER FORMLESS
		// A Formless is not half of anything: it is a psyche, and its second race is the body it
		// wears. His own code refuses the half-race path for it outright ("formless can't be half
		// races", 34003), so it is answered before that path is reached. With no host yet, the
		// psyche stands alone and _getRaceIssues says what is missing.
		var tmpformless = readFormlessPair(tmpraceitems.map(tmprace => tmprace.system),
			tmpraceitems.map(tmprace => tmprace.name));
		if (tmpformless.isFormless) {
			var tmpformlessissue = tmpformless.issue ?? "";
			if (!tmpformless.host) {
				return { race: tmpraceitems.find(tmprace => tmprace.system.formless), formlessIssue: tmpformlessissue };
			}
			return {
				race: {
					name:   `${tmpformless.psyche === tmpraceitems[0].system ? tmpraceitems[0].name : tmpraceitems[1].name}[${tmpformless.hostName}]`,
					system: combineFormless(tmpformless.psyche, tmpformless.host)
				},
				formlessIssue: tmpformlessissue
			};
		}

		// @MARKER FAMORIAN
		// A Famorian's body is built out of the evokes it has taken, so the race the rest of the
		// model reads is the base race with those applied. The 1d3 attribute bonuses are read off
		// the character rather than rolled here: this runs on every prepare.
		var tmpfamorianat = tmpraceitems.findIndex(tmprace => tmprace.system.famorian?.isFamorian);
		if (tmpfamorianat >= 0) {
			var tmpchosen = this.physical.famorian?.evokes ?? [];
			var tmpbonuses = {
				str: this.physical.famorian?.strBonus ?? 0,
				agl: this.physical.famorian?.aglBonus ?? 0,
				vit: this.physical.famorian?.vitBonus ?? 0
			};
			var tmpbuilt = applyFamorianEvokes(tmpraceitems[tmpfamorianat].system, tmpchosen, tmpbonuses);
			if (tmpraceitems.length == 1) {
				return { race: { name: tmpraceitems[0].name, system: tmpbuilt }, formlessIssue: "" };
			}
			// A Famorian half race combines the BUILT Famorian, so its evokes reach the blend.
			var tmpother = tmpraceitems.find((tmprace, tmpindex) => tmpindex != tmpfamorianat);
			return {
				race: {
					name:   getHalfRaceName(tmpraceitems[0].name, tmpraceitems[1].name),
					system: (tmpfamorianat == 0) ? combineHalfRace(tmpbuilt, tmpother.system)
					                             : combineHalfRace(tmpother.system, tmpbuilt)
				},
				formlessIssue: ""
			};
		}

		if (tmpraceitems.length == 1) { return { race: tmpraceitems[0], formlessIssue: "" }; }
		return {
			race: {
				name:   getHalfRaceName(tmpraceitems[0].name, tmpraceitems[1].name),
				system: combineHalfRace(tmpraceitems[0].system, tmpraceitems[1].system)
			},
			formlessIssue: ""
		};
	}

	// This is the function which finds every embedded item of a given type, in the order the
	// actor holds them. Used for classes, where a second one means a dual-classed character, and
	// for races, where a second one means a half race.
	_findItems(tmptype) {
		var tmpactor = this.parent;
		if (!tmpactor || !tmpactor.items) { return []; }
		var tmpfound = [];
		for (const tmpitem of tmpactor.items) {
			if (tmpitem.type == tmptype) { tmpfound.push(tmpitem); }
		}
		return tmpfound;
	}

	// This is the function which asks every class the character holds whether it grants something
	// at a title, and reports the best answer.
	//
	// Each class carries its own "when" for a lore or a chart, and each is tested against its own
	// title, because a dual-classed character advances the two separately. A character HAS the
	// thing if any class has reached its own threshold -- they learn the skills of both classes
	// (Dual Class, Class Determination rule 5), and where two versions compete the better applies
	// (Experience and Advancement rule 4).
	//
	// The `when` reported back is the threshold of whichever class actually granted it, or the
	// lowest non-zero one where none has been reached yet, so the sheet can say what is still to
	// come rather than showing a zero that reads as "never".
	_getBestClassTitle(tmpfield) {
		var tmpout = { when: 0, reached: false, title: 0 };
		for (const tmpclass of this.classItems) {
			var tmpwhen = parseInt(tmpclass.system[tmpfield]) || 0;
			if (tmpwhen <= 0) { continue; }

			var tmptitle = this._getClassTitle(tmpclass);
			if (hasLore(tmptitle, tmpwhen)) {
				if (!tmpout.reached || tmpwhen < tmpout.when) {
					tmpout = { when: tmpwhen, reached: true, title: tmptitle };
				}
			} else if (!tmpout.reached && (tmpout.when == 0 || tmpwhen < tmpout.when)) {
				tmpout = { when: tmpwhen, reached: false, title: tmptitle };
			}
		}
		return tmpout;
	}

	// This is the function which reads a title's name off a class. The lookup lives on the class's
	// data model (item-class.mjs, getTitleName), and older code reached it through the item, so
	// both are tried -- and a class carrying neither answers with no name rather than throwing.
	static getClassTitleName(tmpclassitem, tmptitle) {
		if (!tmpclassitem) { return ""; }
		if (tmpclassitem.system?.getTitleName) { return tmpclassitem.system.getTitleName(tmptitle) || ""; }
		if (tmpclassitem.getTitleName) { return tmpclassitem.getTitleName(tmptitle) || ""; }
		return "";
	}

	// This is the function which gives one class's own title on this character.
	//
	// A dual-classed character advances each class separately, so the title belongs with the
	// class. Zero on the class means "follow the character's own title", which is every
	// single-classed character and why nothing had to change for one.
	_getClassTitle(tmpclassitem) {
		if (!tmpclassitem) { return 0; }
		return (parseInt(tmpclassitem.system.title) || 0) || (parseInt(this.identity.title) || 0);
	}

	//==========================================================================================
	// @MARKER DERIVED DATA
	//==========================================================================================
	// Runs after Active Effects have been applied. Order matters here and follows the chain
	// documented in docs/DATA-MODEL.md section 9 -- attributes feed the characteristics, which
	// feed Shock. Nothing in this method may read a value computed later in it.
	prepareDerivedData() {
		super.prepareDerivedData();

		// @MARKER TEMPORARY AMBIDEXTERITY
		// His Temporary Ambidexterity tick (tmp_ambidextrous, checkTemporaryHandedness). Handedness is read in
		// a dozen places, so it is overridden here, first of all, and the stored value is kept beside it for the
		// one dropdown that writes it back (storedHandedness).
		this.physical.storedHandedness = this.physical.handedness;
		if (this.tempMods?.ambidextrous) { this.physical.handedness = "Ambidextrous"; }

		// Attributes first: the dual-class requirement check in _prepareIdentity compares against
		// them, and _prepareAttributes is where a rating above its racial cap gets clamped down.
		// Nothing in _prepareAttributes reads anything _prepareIdentity derives -- the title it
		// uses for the cap rule is stored, not derived -- so the two swap safely.
		this._prepareAttributes();
		this._prepareIdentity();
		this._prepareCharacteristics();
		this._prepareResistances();
		this._prepareLanguages();
		this._prepareEncumbrance();
		this._prepareCombat();
		this._prepareBody();
		this._prepareMovement();
		// The book's encumbrance penalty, beside the unencumbered rates rather than over them.
		this.movement.loaded = resolveLoadedMovement(this.movement, this.encumbrance);
		this._prepareSkillSlots();
		this._prepareSkills();
		this._prepareSkillSlotStatus();
		// A learned armour configuration eases what the armour costs; after the skills, whose chance
		// (Armor Knowledge's) it reads, and before everything that reads the figures it changes.
		this._prepareArmorSkills();
		// Martial arts after the skills, whose chances it reads, and before both the off-hand
		// skills and the Situation Mods: a held stance adds to skills (the Drunken stance's
		// "+10% to combat skills" reaches Second Weapon Knowledge, which is typed Combat), and the
		// Situation Mods read the blind fighting it sets in combat.martialBlind.
		this._prepareMartialArts();
		// Late, so that anything martial arts derives before it (blind fighting, a stance held) is
		// already in place when the situational figures are totalled. It changes defensiveAdjust,
		// which nothing between _prepareCombat and here reads.
		//
		// And BEFORE the off-hand skills: fighting blind lays Martial Lore's bonus on every skill typed
		// Combat, Second Weapon Knowledge among them, and _prepareOffhandSkills reads those chances.
		// The other way round, the Skills tab showed 68% while the off-hand penalty, its tooltip and
		// the off-hand seconds were worked from 58% (bug sweep 2026-09-23). _prepareSituation reads
		// nothing the off-hand step sets.
		this._prepareSituation();
		this._prepareOffhandSkills();
		// Casting and invoking read the skills (Spell Lore, the casting skills, Divine Knowledge) and
		// the attributes, and nothing after this step reads what they set.
		this._prepareMagic();
		// After the skills: the Arch Mortal screen reads five class skills' chances, and those
		// are not worked out until _prepareSkills has run.
		this._prepareAdvancement();
		this._prepareAvailability();

		// NOT YET IMPLEMENTED, and deliberately so rather than guessed at:
		//   evoke mutations      -- buildCharacterBody in the original sheet adds extra torsos,
		//                           limbs, wings and tails on top of the body chart. Only the
		//                           stock charts are used here.
		//   encumbrance extras   -- quality tags, floating items, and the Lighten Load / Spirit
		//                           of the Donkey magic his calcEncumbrance reads; see the
		//                           encumbrance block in combat-rules.mjs.
	}

	// This is the function which flags every item on the character that the campaign's
	// content switches currently disallow.
	//
	// Items are flagged, never removed. If a Game Master switches a sourcebook or a kind of
	// magic off mid-campaign, a player's existing skills and gear stay on their sheet, marked
	// unavailable with the reason, rather than disappearing behind their back.
	_prepareAvailability() {
		var tmpactor = this.parent;
		if (!tmpactor || !tmpactor.items) { return; }

		var tmprules = game.imagine.getAvailabilityRules();
		for (const tmpitem of tmpactor.items) {
			var tmpresult = explainAvailability(tmpitem, tmprules);
			tmpitem.system.available = tmpresult.available;
			tmpitem.system.unavailableReason = tmpresult.reason;
		}
	}

	// This is the function which returns the armour the character is actually wearing.
	_getWornArmor() {
		var tmpactor = this.parent;
		if (!tmpactor || !tmpactor.items) { return []; }
		var tmpworn = [];
		for (const tmpitem of tmpactor.items) {
			if (tmpitem.type == "armor" && tmpitem.system.location == "equipped") { tmpworn.push(tmpitem); }
		}
		return tmpworn;
	}

	// This is the function which separates what is worn into the four armour layers and the
	// shields over them. A shield covers a run of areas down one side rather than a single slot,
	// and his sheet keeps it in a fifth layer of its own, so the two are totalled separately and
	// a shield must not also be counted as ordinary armour -- its armour value sits in the
	// left-hand column whichever hand holds it, so counting it twice would armour the wrong hand.
	_getWornShields() {
		return this._getWornArmor().filter(tmpitem => tmpitem.system.isShield);
	}

	// This is the function which works out the character's standing combat values.
	//
	// Attack skill comes from the class's progression and the character's title. Armour worn
	// counts against initiative, defence and weapon speed, and all three work the same way
	// round: a positive penalty is worse. A heavy scale suit is +1 to initiative (acting a second
	// later), +3 to anyone attacking the wearer, and +2 seconds on every swing.
	_prepareCombat() {
		var tmpaglmods = this.attributes.agl.mods;
		var tmpintmods = this.attributes.int.mods;
		var tmpstrmods = this.attributes.str.mods;

		var tmparmorinit = 0;
		var tmparmordef = 0;
		var tmparmorspeed = 0;
		var tmparmorskills = 0;
		for (const tmpitem of this._getWornArmor()) {
			var tmppen = tmpitem.system.penalties ?? {};
			tmparmorinit   = tmparmorinit   + (parseInt(tmppen.initiative) || 0);
			tmparmordef    = tmparmordef    + (parseInt(tmppen.defense) || 0);
			tmparmorspeed  = tmparmorspeed  + (parseInt(tmppen.speed) || 0);
			tmparmorskills = tmparmorskills + (parseInt(tmppen.skills) || 0);
		}

		// The attack chart. A dual-classed character fights at the better of their two classes'
		// charts -- Player's Guide, Dual Class, Experience and Advancement rule 5, "Attack skill is
		// determined by the greater of the two values" -- and each class is read at ITS OWN title,
		// since the two advance separately.
		//
		// A GME's chart is not earned: his sheet sets it straight from the player's pick
		// (setFinalClass, sheet-worker.js:51283), so a non-classed class reads the stored choice.
		this.combat.attackSkill = "None";
		for (const tmpclass of this.classItems) {
			var tmpclassskill = tmpclass.system.nonClassed
				? (this.combat.chosenAttackSkill || "Beginner")
				: getAttackSkillForTitle(tmpclass.system.attackSkillList, this._getClassTitle(tmpclass));
			this.combat.attackSkill = getBetterAttackSkill(this.combat.attackSkill, tmpclassskill);
		}

		// The Lore chart: the standard chart one level up, for a weapon the character has Weapon
		// or Missile Lore in. A class reaches it at its own title and about half never do.
		// His code keeps this as a second stored chart (special_attack_skill); it is derived here
		// because everything it depends on already is.
		//
		// Reached if EITHER class reaches it, each at its own title. The book does not rule on
		// this one directly, so it follows rule 4's principle -- where two versions of something
		// compete, the better applies -- which is also what rule 5 does for the chart it is built
		// from. Recorded in DECISIONS.md as a reading rather than a citation.
		this.combat.loreAttackTitle = this._getBestClassTitle("loreAttackTitle").when;
		this.combat.loreAttackSkill = this._getBestClassTitle("loreAttackTitle").reached
			? getNextAttackSkill(this.combat.attackSkill)
			: "";

		// Weapon and Missile Lore themselves, which are a different thing from the chart above:
		// a class can hold the lore without ever reading the Lore attack chart, and the two
		// titles rarely match. Zero means the class never acquires it at all.
		var tmpweaponlore = this._getBestClassTitle("weaponLoreTitle");
		var tmpmissilelore = this._getBestClassTitle("missileLoreTitle");
		this.combat.weaponLoreTitle = tmpweaponlore.when;
		this.combat.missileLoreTitle = tmpmissilelore.when;
		this.combat.hasWeaponLore = tmpweaponlore.reached;
		this.combat.hasMissileLore = tmpmissilelore.reached;

		// The lists themselves are stored as he stores them, one comma-separated string each.
		// Parsed here once so nothing downstream has to split a string.
		this.combat.weaponLoreNames = parseLoreList(this.combat.weaponLoreList);
		this.combat.missileLoreNames = parseLoreList(this.combat.missileLoreList);

		// Projectile Lore, worth damage per die rather than a flat figure.
		var tmpprojlore = this._getBestClassTitle("projectileLoreTitle");
		this.combat.projectileLoreTitle = tmpprojlore.when;
		this.combat.hasProjectileLore = tmpprojlore.reached;
		this.combat.projectileLoreNames = parseLoreList(this.combat.projectileLoreList);

		// The title each lore class was reached at, kept for the slots the Weapon Choices window shows: one
		// per title held in the skill, less those already named (getChoiceSlots, weapon-choices-rules.mjs).
		this.combat.weaponLoreSlots = getChoiceSlots(tmpweaponlore.title, tmpweaponlore.when, this.combat.weaponLoreList);
		this.combat.missileLoreSlots = getChoiceSlots(tmpmissilelore.title, tmpmissilelore.when, this.combat.missileLoreList);
		this.combat.projectileLoreSlots = getChoiceSlots(tmpprojlore.title, tmpprojlore.when, this.combat.projectileLoreList);
		this.combat.weaponLoreReachedTitle = tmpweaponlore.title;
		this.combat.missileLoreReachedTitle = tmpmissilelore.title;
		this.combat.projectileLoreReachedTitle = tmpprojlore.title;
		this.combat.secondWeaponKnowReachedTitle = this._getBestClassTitle("secondWeaponKnowTitle").title;
		this.combat.secondWeaponLoreReachedTitle = this._getBestClassTitle("secondWeaponLoreTitle").title;
		this.combat.weaponProfNames = parseLoreList(this.combat.weaponProfList);
		this.combat.projectileKnowNames = parseLoreList(this.combat.projectileKnowList);

		// Eligibility for the two off-hand fighting disciplines. This is title eligibility only
		// -- whether the class has reached the title that makes the skill available at all -- not
		// whether the character actually has the skill. The skill's own chance is read once
		// skills have resolved, in _prepareOffhandSkills below, since embedded skill items are not
		// finished computing here yet (see the ordering note on _prepareSkills).
		var tmpknow2nd = this._getBestClassTitle("secondWeaponKnowTitle");
		var tmplore2nd = this._getBestClassTitle("secondWeaponLoreTitle");
		this.combat.secondWeaponKnowTitle = tmpknow2nd.when;
		this.combat.secondWeaponLoreTitle = tmplore2nd.when;
		this.combat.hasSecondWeaponKnowledge = tmpknow2nd.reached;
		this.combat.hasSecondWeaponLore = tmplore2nd.reached;

		// Which weapons each discipline is held in, and how many more may be named. One weapon
		// per title held in the discipline -- see getSecondWeaponSlots.
		this.combat.secondWeaponKnowNames = parseLoreList(this.combat.secondWeaponKnowList);
		this.combat.secondWeaponLoreNames = parseLoreList(this.combat.secondWeaponLoreList);
		this.combat.secondWeaponKnowSlots = getSecondWeaponSlots(tmpknow2nd.title, tmpknow2nd.when,
			this.combat.secondWeaponKnowNames);
		this.combat.secondWeaponLoreSlots = getSecondWeaponSlots(tmplore2nd.title, tmplore2nd.when,
			this.combat.secondWeaponLoreNames);

		// Multiple Missile Lore, the last of the family. Title eligibility only, as above; the
		// combos themselves are named launcher/missile pairs and the mechanics that read them are
		// not built yet. Its Knowledge half has no title gate in his sheet at all.
		var tmpmmlore = this._getBestClassTitle("multiMissileLoreTitle");
		this.combat.multiMissileLoreTitle = tmpmmlore.when;
		this.combat.hasMultiMissileLore = tmpmmlore.reached;

		// @MARKER RACIAL COMBAT MODIFIERS
		// The race's eyes, sense tendrils and metabolism -- his "Other" column (setCombatModifierValues,
		// sheet-worker.js:82205-82262). Melee and missile are folded in below with fatigue; initiative and
		// defence here; the damage is added by the attack (module/combat/attack.mjs), as fatigue's is.
		var tmpracial = getRacialCombatMods(this.identity.race?.abilities, this.identity.race?.disabilities,
			this.physical?.famorian?.evokes);
		this.combat.racialCombat = tmpracial;

		// The signed body-weight damage term (his getWeightDamageAdj, sheet-worker.js:83270; combat_mod_dam_weight
		// at 82287). Signed for a character, as his is; melee only, which the attack decides (64621-64626).
		this.combat.weightDamage = getWeightDamageAdjust(this.physical?.weight, false);

		this.combat.initiativeMod = getInitiativeModifier(
			tmpaglmods.initiativeAdjust, tmpintmods.initiativeAdjust,
			tmparmorinit + (parseInt(this.combat.initiativeMisc) || 0) + tmpracial.initiative);

		// Added to anyone's attack roll against this character. Lower is better for them.
		this.combat.defensiveAdjust = (parseInt(tmpaglmods.defensiveAdjust) || 0)
		                            + tmparmordef + (parseInt(this.combat.defenseMisc) || 0) + tmpracial.defense;

		// Added to every weapon's speed: Strength, Agility, then armour.
		this.combat.weaponSpeedMod = (parseInt(tmpstrmods.weaponSpeed) || 0)
		                           + (parseInt(tmpaglmods.weaponSpeed) || 0) + tmparmorspeed;

		this.combat.meleeAttack   = parseInt(tmpstrmods.meleeAttack) || 0;
		this.combat.meleeDamage   = parseInt(tmpstrmods.meleeDamage) || 0;
		this.combat.missileAttack = parseInt(tmpaglmods.missileAttack) || 0;
		this.combat.armorSkillPenalty = tmparmorskills;
		// The armour's share of each standing figure on its own, for the Combat tab's modifiers table
		// (module/combat-panel-view.mjs), which shows his STR / AGL / INT / Armor columns apart. Already
		// inside initiativeMod, defensiveAdjust and weaponSpeedMod above; nothing reads these but the panel.
		this.combat.armorInitiative = tmparmorinit;
		this.combat.armorDefense = tmparmordef;
		this.combat.armorSpeed = tmparmorspeed;

		// @MARKER TEMPORARY MODIFIERS: FATIGUE AND SPEED
		// What fatigue takes off, and the Weapon Speed box, folded into the figures above so every attack and
		// the Combat tab's table already read them. Kept apart as combat.fatigue as well, because meleeAttack
		// is no longer Strength alone: a table that wants Strength's own share reads attributes.str.mods instead
		// (the Combat panel does). The race's eyes, tendrils and metabolism are folded in the same way below.
		// Damage is NOT folded into meleeDamage (the Strength bonus doubles two-handed; fatigue does not): the
		// attacks add combat.fatigue.damage themselves. The skills figure goes on every skill, in _prepareSkills.
		var tmpeffects = getTempEffects(this.tempMods);
		this.combat.fatigue = tmpeffects;
		this.combat.meleeAttack   = this.combat.meleeAttack + tmpeffects.melee + tmpracial.melee;
		this.combat.missileAttack = this.combat.missileAttack + tmpeffects.missile + tmpracial.missile;
		this.combat.weaponSpeedMod = this.combat.weaponSpeedMod + tmpeffects.weaponSpeed;
		this.combat.tempSkillMod = tmpeffects.skills + (parseInt(this.combat.skillMisc) || 0);
		// Fumble range and called-shot range, in points on the d20 (his tmp_fumble_mod, tmp_calledshot_mod).
		this.combat.fumbleRangeMod = parseInt(this.tempMods?.fumble) || 0;
		this.combat.calledShotRangeMod = parseInt(this.tempMods?.calledShot) || 0;
		this.combat.extraDice = parseInt(this.tempMods?.extraDice) || 0;
		this.combat.extraPerDie = parseInt(this.tempMods?.extraPerDie) || 0;
	}

	// @MARKER ARMOR KNOWLEDGE AND LORE
	// This is the function which eases the armour's penalties when the set worn is one the character has
	// learned -- his setArmorKnowModifiers and setArmorLoreModifiers (sheet-worker.js:118539, 118608), run
	// after _prepareCombat has totalled the penalties raw. Armor Knowledge lowers each by levels of its
	// chance; Armor Lore, which wins, removes them (module/armor-know-rules.mjs). Everything it changes is
	// additive, so the figures _prepareCombat made are corrected in place rather than made again.
	//
	// Sets armorKnowOn / armorLoreOn -- his armor_know_check / armor_lore_check boxes -- for the sheet.
	_prepareArmorSkills() {
		var tmpworn = this._getWornArmor();
		var tmpraw = { skills: 0, defense: 0, initiative: 0, speed: 0 };
		for (const tmpitem of tmpworn) {
			var tmppen = tmpitem.system.penalties ?? {};
			tmpraw.skills     += parseInt(tmppen.skills) || 0;
			tmpraw.defense    += parseInt(tmppen.defense) || 0;
			tmpraw.initiative += parseInt(tmppen.initiative) || 0;
			tmpraw.speed      += parseInt(tmppen.speed) || 0;
		}
		var tmpset = getEquippedArmorSet(tmpworn);
		var tmpknowon = isConfigLearned(tmpset, this.combat.armorKnowList);
		var tmploreon = isConfigLearned(tmpset, this.combat.armorLoreList);
		this.combat.armorKnowOn = tmpknowon;
		this.combat.armorLoreOn = tmploreon;
		this.combat.armorSkillsLine = "";
		if (tmpknowon || tmploreon) {
			// Armor Knowledge's chance: the skill as held, or the common footing it may be tried on.
			var tmptitle = parseInt(this.identity.title) || 0;
			var tmpstanding = getSkillStanding((this.parent?.items ?? []).filter(tmpitem => tmpitem.type == "skill"),
				"Armor Knowledge", tmptitle);
			var tmpchance = tmpstanding.held ? tmpstanding.chance
				: this.getCommonSkillChance(ARMOR_KNOWLEDGE_BASE.attr1, ARMOR_KNOWLEDGE_BASE.attr2, ARMOR_KNOWLEDGE_BASE.rating);
			var tmpeased = applyArmorSkills(tmpraw, { know: tmpknowon, knowChance: tmpchance, lore: tmploreon });

			this.combat.initiativeMod   += tmpeased.initiative - tmpraw.initiative;
			this.combat.defensiveAdjust += tmpeased.defense - tmpraw.defense;
			this.combat.weaponSpeedMod  += tmpeased.speed - tmpraw.speed;
			this.combat.armorSkillPenalty = tmpeased.skills;
			// The Combat tab's modifiers table shows the armour's share apart (combat-panel-view.mjs); it is
			// the eased share once a set is learned, as his combat table reads armor_*_penalty after the setters.
			this.combat.armorInitiative = tmpeased.initiative;
			this.combat.armorDefense = tmpeased.defense;
			this.combat.armorSpeed = tmpeased.speed;
			this.combat.armorSkillsLine = describeArmorSkillsLine(tmpknowon, tmploreon, tmpeased.levels);
		}

		// @MARKER ARMOR SKILL PENALTY ON SKILLS
		// The armour's skills penalty -- eased or not -- on the two skills his rolls charge it to, Shield Parry
		// and Body Parry (ARMOR_PENALTY_SKILLS, sheet-worker.js:70736, 70979: "Armor: N%"). Added to their
		// totals here rather than at the roll so the Skills tab shows the chance actually rolled.
		var tmpskillpen = parseInt(this.combat.armorSkillPenalty) || 0;
		this.combat.armorSkillApplied = [];
		if (tmpskillpen != 0) {
			for (const tmpitem of (this.parent?.items ?? [])) {
				if (tmpitem.type != "skill" || !ARMOR_PENALTY_SKILLS.includes(tmpitem.name)) { continue; }
				tmpitem.system.armorPenalty = tmpskillpen;
				tmpitem.system.totalChance = (parseInt(tmpitem.system.totalChance) || 0) + tmpskillpen;
				this.combat.armorSkillApplied.push(tmpitem.name);
			}
		}
	}

	// This is the function which lays out the character's body: every area of their body chart,
	// with its Endurance, the wounds it has taken, the armour protecting it, and what state it
	// is in.
	//
	// An area's Endurance is the character's Endurance times the area's multiplier, rounded up.
	// Its armour is the sum of every worn layer covering it, less any damage that armour has
	// taken. Beyond its Endurance a Vitality save is needed; beyond Endurance plus Vitality the
	// area's effect is triggered. Total wounds over Shock put the character into shock.
	_prepareBody() {
		var tmpbodytype = this.body.bodyType || (this.raceItem ? this.raceItem.system.bodyType : "") || "Humanoid";
		var tmpendurance = this.characteristics.endurance.value;
		var tmpvitality = this.attributes.vit.value;
		var tmpworn = this._getWornArmor().filter(tmpitem => !tmpitem.system.isShield);
		var tmpshields = this._getWornShields();
		var tmphandedness = this.physical.handedness;
		var tmpwounds = this.body.wounds ?? {};
		var tmparmordamage = this.body.armorDamage ?? {};

		var tmpareas = [];
		var tmptotal = 0;
		for (const tmparea of getBodyChart(tmpbodytype)) {
			var tmpend = getAreaEndurance(tmpendurance, tmparea.multiplier);
			var tmphurt = parseInt(tmpwounds[tmparea.name]) || 0;
			tmptotal = tmptotal + tmphurt;

			// Armour here: every worn layer that covers this area, less its accumulated damage.
			// Which slot covers an area depends on the body: a centaur's forequarters take
			// barding, a snake's length takes a torso piece. See getAreaArmorSlot.
			var tmpcover = getAreaArmor(tmpbodytype, tmparea.name, tmpworn);
			var tmparmor = tmpcover.armor;
			var tmpmaterials = tmpcover.materials;
			var tmplayers = tmpcover.layers;
			var tmpslot = tmpcover.slot;
			var tmpdamaged = parseInt(tmparmordamage[tmparea.name]) || 0;
			tmparmor = Math.max(0, tmparmor - tmpdamaged);

			// A shield is the fifth layer, added on top of the worn armour and untouched by the
			// damage that armour has taken -- his sheet tracks it in its own layer and clears it
			// wholesale when the shield comes off, rather than degrading it area by area.
			var tmpshielded = getAreaShield(tmpbodytype, tmparea.name, tmpshields, tmphandedness);
			tmparmor = tmparmor + tmpshielded.armor;

			var tmpstate = "sound";
			if (tmphurt > tmpend + tmpvitality) { tmpstate = "effect"; }
			else if (tmphurt > tmpend)          { tmpstate = "vitalitySave"; }
			else if (tmphurt > 0)               { tmpstate = "wounded"; }

			tmpareas.push({
				name: tmparea.name,
				type: tmparea.type,
				multiplier: tmparea.multiplier,
				endurance: tmpend,
				wounds: tmphurt,
				armor: tmparmor,
				armorDamage: tmpdamaged,
				material: getStrongestMaterial(tmpmaterials),
				layers: tmplayers.concat(tmpshielded.layers),
				shield: tmpshielded.armor,
				shieldLayers: tmpshielded.layers,
				protectedByArmor: !!tmpslot || tmpshielded.armor > 0,
				state: tmpstate
			});
		}

		this.body.type = tmpbodytype;
		this.body.areas = tmpareas;
		// The areas' wounds, and whatever has been done to overall Endurance besides (a poison's).
		this.body.totalWounds = tmptotal + (parseInt(this.body.overallWounds) || 0);
		this.body.inShock = (this.body.shock != 0) && (this.body.totalWounds > this.body.shock)
		                 && !this.tempMods?.shockImmune;   // Shock Immunity, from the Temporary Modifiers panel
		// What a token's resource bar draws, Shock less the total wounds -- the same "body.shockBar" a
		// creature carries (getShockBar in combat-rules.mjs; CONFIG.Actor.trackableAttributes in
		// imagine-rpg.mjs). Added 2026-09-23 with the creature's, so both actor types have a bar.
		this.body.shockBar = getShockBar(this.body.shock, this.body.totalWounds);
		// The same figure the other way up, for a second token bar: wounds taken, filling towards Shock.
		this.body.woundBar = { value: this.body.shockBar.wounds, max: this.body.shockBar.max };
	}

	// This is the function which totals carried weight and works out how encumbered the
	// character is. The arithmetic is his calcEncumbrance, shared with the creature model --
	// see resolveEncumbrance in combat-rules.mjs for the bands, the size scaling of armour and
	// gear, and the magical-plus weight reduction.
	_prepareEncumbrance() {
		var tmpphys = this.physical ?? {};
		var tmpinches = ((parseInt(tmpphys.heightFeet) || 0) * 12) + (parseInt(tmpphys.heightInches) || 0);
		this.encumbrance = resolveEncumbrance(this.parent?.items,
			this.attributes.str.mods.loadLimit, tmpphys.weight, tmpinches);

		// @MARKER TEMPORARY WEIGHT AND CAPACITY
		// His Equipment modifiers (tmp_equip_weight_mod, tmp_equip_capacity_mod): a multiplier on what is
		// carried and one on what may be. 2 is x2, .5 is x1/2. The bands move with capacity and the status is
		// read again against them, so the label and the speed factor follow.
		var tmpweighmulti = parseFloat(this.tempMods?.weightMulti) || 1;
		var tmpcapmulti = parseFloat(this.tempMods?.capacityMulti) || 1;
		if (tmpweighmulti != 1 || tmpcapmulti != 1) {
			var tmpenc = this.encumbrance;
			tmpenc.carried = parseFloat((tmpenc.carried * tmpweighmulti).toFixed(1));
			for (const tmpband of ["maxLoad", "none", "slight", "moderate", "heavy"]) {
				tmpenc[tmpband] = parseFloat((tmpenc[tmpband] * tmpcapmulti).toFixed(1));
			}
			var tmpread = getEncumbranceBand(tmpenc.carried, tmpenc);
			tmpenc.status = tmpread.status;
			tmpenc.speedFactor = tmpread.speedFactor;
			tmpenc.canRun = tmpread.canRun;
			tmpenc.penalty = tmpread.penalty;
		}
	}

	// This is the function which fills in the identity values that come from the class items.
	//
	// A dual-classed character is named for both -- "Mage/Warrior", which is how the Player's Guide
	// writes them -- and carries a row per class, since each has its own title and its own title
	// name. The single-class strings stay exactly what they were, so nothing that reads className
	// has to know about any of this.
	_prepareIdentity() {
		// Set in _getEffectiveRace, during prepareBaseData -- see the note at that call site. Only
		// ever populated on a Formless (checkEvokeBudget-style "" everywhere else), so this is safe
		// to write unconditionally: a non-Formless character's issues array never reads it.
		this.identity.formlessIssue = this._formlessIssue ?? "";

		this.identity.raceName  = this.raceItem ? this.raceItem.name : "";
		// A Changeling is named for the form it wears, as his race field is ("Changeling[Kenku]").
		this.identity.isChangeling = isChangelingRace(this.raceItems.map(tmprace => tmprace.name));
		if (this.identity.isChangeling && this.identity.changeling?.form && this.identity.changeling.form != CHANGELING_NATURAL) {
			this.identity.raceName = `Changeling[${this.identity.changeling.form}]`;
		}
		// His race_type values; only these two are implemented in his sheet.
		// A Formless and its host are two race items and are NOT a Half Race: his race_type for
		// one is still One Race, the second item being a body rather than a parent.
		this.identity.isFormless = this.raceItems.some(tmprace => tmprace.system.formless);
		this.identity.isHalfRace = this.raceItems.length > 1 && !this.identity.isFormless;
		this.identity.raceType  = this.identity.isHalfRace ? "Half Race" : "One Race";
		this.identity.raceWarning = (this.raceItems.length > 2 && !this.identity.isFormless)
			? "Only two races combine: his sheet's Multi Race is not implemented. "
			  + this.raceItems.slice(2).map(tmprace => tmprace.name).join(", ") + " ignored."
			: "";
		// What the race (or the half race, already combined) gives, for the sheet to show. Listed,
		// not applied: the ability mechanics and the racial-skill picker are not ported yet.
		var tmpracesys = this.raceItem ? this.raceItem.system : null;
		// The physique lock -- winged/wingless faerie forms only -- read off the RAW race items,
		// before a Half Race averages them, because that is the only place a conflict between two
		// locks can still be seen. Reported beside the panel's other race lines when one side is
		// locked; the conflict itself (one winged, one wingless) is reported in _getRaceIssues
		// instead, beside the barred-class and infertile-pair issues -- see race-forms.md item 3.
		var tmpphysiquelock = resolvePhysiqueLock(this.raceItems.map(tmprace => tmprace.system));
		this.identity.race = tmpracesys ? {
			skills:       tmpracesys.racialSkills ?? [],
			skillNote:    tmpracesys.racialSkillNote ?? "",
			abilities:    tmpracesys.abilities ?? [],
			disabilities: tmpracesys.disabilities ?? [],
			immunities:   tmpracesys.immunities ?? [],
			ages:         tmpracesys.ages ?? { startLow: 0, startHigh: 0, maxAge: "" },
			physiqueLock: tmpphysiquelock.locked ? tmpphysiquelock.reason : "",
			// The evokes a Famorian has taken, for the Description tab's Race panel. Null for
			// every other race -- describeEvokes and checkEvokeBudget are the exported functions
			// famorian.md item 6 says nothing calls yet; this is what calls them.
			famorian: this._prepareFamorianDisplay(tmpracesys)
		} : null;
		this.identity.className = this.classItem ? this.classItem.name : "";
		this.identity.classType = this.classItem ? this.classItem.system.classType : "";
		// Through the guarded helper: getTitleName lives on the class's DATA MODEL, so reaching
		// for it on the item throws in Foundry. Found by tools/levelup-preview.html, whose class
		// is a real document rather than a fixture carrying the method in both places.
		this.identity.titleName = ImagineCharacterData.getClassTitleName(this.classItem, this.identity.title);

		// Final attributes, race included, for checkClassQualification -- the same shape
		// checkFinalAttributes returns in character generation ({ key: { final } }), built here off
		// the character's own already-derived attributes rather than re-run through the generator's
		// rating math, since _prepareAttributes has already settled them by this point.
		var tmpqualifyfinals = {};
		for (const tmpkey of Object.keys(this.attributes)) {
			tmpqualifyfinals[tmpkey] = { final: this.attributes[tmpkey].value };
		}
		var tmpracenames = this.raceItems.map(tmprace => tmprace.name);

		this.identity.classes = this.classItems.map(tmpclass => {
			var tmptitle = this._getClassTitle(tmpclass);
			// The same "what stops this class" check the generator's dropdown makes
			// (checkClassQualification, chargen-rules.mjs), read against this character's own
			// final attributes rather than the rolled-but-not-applied figures the generator has.
			// A character taken with the override still shows its shortfall here, on the finished
			// sheet, rather than looking like any other. See first-install-bugs.md item 8.
			var tmpblocked = isClassBlockedForRaces(tmpclass.system.blockedRaces, tmpracenames);
			var tmpqualifyissues = checkClassQualification(tmpclass.system, tmpqualifyfinals, tmpracenames, tmpblocked);
			var tmpqualifysummary = this._summarizeClassQualification(tmpqualifyissues);
			return {
				id: tmpclass.id,
				name: tmpclass.name,
				classType: tmpclass.system.classType,
				title: tmptitle,
				titleName: ImagineCharacterData.getClassTitleName(tmpclass, tmptitle),
				// The whole career less what was given up at creation (countClassSlotsNeeded) -- counted
				// off this character's own class item, so a removal or swap made in the generator shows.
				// A class with no skill list (hand-made, or authored without one) keeps his figure.
				skillSlotsNeeded: (tmpclass.system.advancement?.classSkillList ?? []).length
					? countClassSlotsNeeded(tmpclass.system,
						(this.identity.race?.disabilities ?? []).includes("Cannot Cast Spells"))
					: (parseInt(tmpclass.system.skillSlotsNeeded) || 0),
				qualified: !tmpqualifyissues.length,
				qualificationShort: tmpqualifysummary.short,
				qualificationFull: tmpqualifysummary.full
			};
		});
		this.identity.isDualClass = this.identity.classes.length > 1;
		// A GME: his "0-title non-classed" character (see nonClassed on the class item).
		this.identity.isNonClassed = this.classItems.some(tmpclass => tmpclass.system.nonClassed);
		this.identity.classNames = this.identity.classes.map(c => c.name).join("/");

		// Both classes' progressions have to be paid for out of one Knowledge allowance, which is
		// the Player's Guide's own reason for the slot tricks existing ("a dual classed character
		// will need to have many class skill slots"). Summed rather than maxed for that reason.
		this.identity.classSlotsNeeded = this.identity.classes
			.reduce((tmptotal, tmpclass) => tmptotal + tmpclass.skillSlotsNeeded, 0);

		this.identity.dualClassIssues = this._getDualClassIssues();
		this.identity.raceIssues = this._getRaceIssues();
		this._prepareClassProgression();
	}

	// This is the function which builds the Famorian evoke display for the Description tab's Race
	// panel: the breed, the budget spent against allowed ("3 of 4"), and every evoke taken --
	// numeric or not -- through describeEvokes. Null for every race that is not a Famorian.
	//
	// tmpraceitems (the RAW race documents) rather than raceItem/tmpracesys carry the evoke
	// catalogue too, since applyFamorianEvokes only touches attributeMods/endurance/resistanceMods/
	// movement -- but tmpracesys is what identity.race is already built from, so it is read here
	// rather than re-finding the race item.
	_prepareFamorianDisplay(tmpracesys) {
		if (!tmpracesys?.famorian?.isFamorian) { return null; }
		var tmpfamorian = this.physical.famorian ?? {};
		var tmpchosen = tmpfamorian.evokes ?? [];
		var tmpbonuses = { str: tmpfamorian.strBonus ?? 0, agl: tmpfamorian.aglBonus ?? 0, vit: tmpfamorian.vitBonus ?? 0 };
		// null-equivalent: -1 means "All", his breed with no ceiling -- the same reading
		// checkEvokeBudget already uses in _getRaceIssues below.
		var tmpallowed = (tmpfamorian.evokesAllowed ?? 0) < 0 ? null : tmpfamorian.evokesAllowed;
		var tmpbudget = checkEvokeBudget(tmpchosen, tmpallowed);
		return {
			breed: tmpfamorian.breed ?? "",
			animalType: tmpfamorian.animalType ?? "",
			evokes: describeEvokes(tmpracesys, tmpchosen, tmpbonuses),
			budgetLabel: `${tmpbudget.used} of ${tmpbudget.allowed === null ? "All" : tmpbudget.allowed}`
		};
	}

	// This is the function which turns a class's qualification issues into the short form the
	// generator's own class dropdown uses ("needs STR 13, INT 15") and the full sentence for a
	// tooltip -- the same split chargen-view.mjs makes for the same reason: a tight space (the
	// header's identity line) gets the short one, and the reason stays readable on hover.
	_summarizeClassQualification(tmpIssues) {
		if (!tmpIssues.length) { return { short: "", full: "" }; }
		var tmpShort = tmpIssues
			.map(tmpIssue => (tmpIssue.match(/Needs (\w+ \d+)/) ?? [])[1])
			.filter(tmpPart => tmpPart);
		return {
			short: tmpShort.length ? "needs " + tmpShort.join(", ") : tmpIssues[0],
			full: tmpIssues.join(" ")
		};
	}

	// @MARKER ADVANCEMENT
	// This is the function which works out where the character stands on his experience ladder,
	// and whether they may pass 10th title.
	//
	// Nothing here changes anything. Levelling up is a decision at every step -- an attribute
	// rolled for, skill points placed -- so it is driven by the Level Up window and applied by
	// module/advancement.mjs. This only reports.
	_prepareAdvancement() {
		var tmpexp = parseInt(this.identity.exp) || 0;
		this.identity.nextGoalExp = getNextGoalExp(tmpexp);
		this.identity.expCap = getExpCap(this.identity.title);
		// Whether a level-up is outstanding. While one is, his sheet refuses more experience.
		this.identity.levelUpPending = (parseInt(this.identity.titlesToRaise) || 0) > 0
		                            || (parseInt(this.identity.goalsToRaise) || 0) > 0;

		// The two attributes this class raises on a goal advance, from his goalupdict. A
		// dual-classed character is offered the FIRST class's pair, because his sheet has one
		// class and one pair, and nothing in his code says how two would combine. Reported on the
		// window rather than decided here, so a Game Master can see which class is being advanced.
		var tmpclass = this.classItem;
		this.identity.goalAttributes = tmpclass
			? [tmpclass.system.advancement?.goalAttr1 ?? "", tmpclass.system.advancement?.goalAttr2 ?? ""]
				.map(tmpkey => ("" + tmpkey).trim().toLowerCase()).filter(tmpkey => tmpkey)
			: [];

		// @MARKER ARCH MORTAL
		// The qualification screen, derived rather than stored: his sheet keeps a Yes/No flag a
		// player presses a button to refresh, which can go stale the moment an attribute changes.
		// The one part that cannot be derived is the class's special requirement, a sentence only
		// a Game Master can judge, and that IS stored (identity.archSpecialMet).
		var tmpattributes = {};
		var tmpmaximums = {};
		for (const tmpkey of Object.keys(this.attributes)) {
			tmpattributes[tmpkey] = this.attributes[tmpkey].value;
			tmpmaximums[tmpkey] = this.attributes[tmpkey].max;
		}
		var tmpchances = {};
		if (this.parent?.items) {
			for (const tmpitem of this.parent.items) {
				if (tmpitem.type != "skill") { continue; }
				// A skill held twice counts at its best, the same rule the skill roll uses. A martial
				// stance's bonus is taken back out: qualifying reads the skill as trained, not as
				// boosted by whichever stance happens to be held (see _prepareMartialArts).
				var tmptrained = (parseInt(tmpitem.system.totalChance) || 0) - (parseInt(tmpitem.system.stanceBonus) || 0)
				               - (parseInt(tmpitem.system.blindBonus) || 0);
				tmpchances[tmpitem.name] = Math.max(tmptrained, parseInt(tmpchances[tmpitem.name]) || 0);
			}
		}

		this.identity.archMortal = tmpclass
			? checkArchMortalQualification(tmpclass.system, {
				attributes: tmpattributes, attributeMax: tmpmaximums, skillChances: tmpchances,
				powerCount: this.parent?.items?.filter(tmpitem => tmpitem.type == "power").length ?? 0,
				specialMet: !!this.identity.archSpecialMet
			})
			: { qualified: false, rows: [], reason: "No class, so no Arch Mortal qualifications." };
		this.identity.archQualified = this.identity.archMortal.qualified;
	}

	// @MARKER CLASS PROGRESSION
	// This is the function which works out what each class has given this character so far and
	// what it still owes -- his whole skill progression laid out against the title reached.
	//
	// "Owed" is what the title entitles the character to and the character does not hold. Ordinarily
	// it is empty, because the grant runs whenever the title changes (grantClassSkills on the actor).
	// It is derived all the same, so a character imported from elsewhere, or one whose grant was
	// refused because the content was switched off, shows the gap on the sheet rather than hiding it.
	//
	// A race that cannot cast takes the no-casting skill wherever a class offers the pair, so the
	// disability is read once here and handed to every call below.
	_prepareClassProgression() {
		this.identity.cannotCast = (this.identity.race?.disabilities ?? []).includes("Cannot Cast Spells");

		var tmpheld = [];
		if (this.parent?.items) {
			tmpheld = this.parent.items.filter(tmpitem => tmpitem.type == "skill").map(tmpitem => tmpitem.name);
		}

		this.identity.classProgression = this.classItems.map(tmpclass => {
			var tmptitle = this._getClassTitle(tmpclass);
			return {
				id:    tmpclass.id,
				name:  tmpclass.name,
				title: tmptitle,
				// The title NAME is added here rather than in the rules module, which knows nothing
				// of items: it is the class item's own classtitledict lookup.
				rows:  buildClassProgression(tmpclass.system, tmptitle, this.identity.cannotCast)
				           .map(tmprow => ({ ...tmprow,
				                             titleName: ImagineCharacterData.getClassTitleName(tmpclass, tmprow.title) })),
				owed:  getClassSkillsToGrant(tmpclass.system, tmptitle, this.identity.cannotCast, tmpheld)
			};
		});
		this.identity.classSkillsOwed = this.identity.classProgression
			.reduce((tmptotal, tmpclass) => tmptotal + tmpclass.owed.length, 0);

		// Shown, never enforced -- see getClassUsageRestrictions on why his sheet does the same.
		this.identity.classUsage = getClassUsageRestrictions(this.classItems);
	}

	// This is the function which lists what is wrong with the character's race against the rest
	// of the character. Reported, never refused -- his sheet lets the player override a barred
	// class ("is usually not this class. This was overriden!"), and the Player's Guide makes a
	// mixed race the Game Master's call.
	//
	//   a class the race cannot take      his classRaceAndDetails, via isClassBlockedForRaces:
	//                                     for a half race, only if BOTH races are barred
	//   two races that cannot breed       his racefertiledict, the list his Half Race picker
	//                                     offers -- so on his sheet this pair could not be chosen
	_getRaceIssues() {
		var tmpissues = [];
		var tmpnames = this.raceItems.map(tmprace => tmprace.name);
		if (tmpnames.length == 0) { return tmpissues; }

		for (const tmpclass of this.classItems) {
			if (isClassBlockedForRaces(tmpclass.system.blockedRaces, tmpnames)) {
				tmpissues.push(`${this.identity.raceName} is usually not a ${tmpclass.name}.`);
			}
		}

		// A Formless and its host are not a breeding pair, so the fertility question does not
		// arise; what CAN be wrong is the host itself, and readFormlessPair has already said so.
		// A Famorian that has spent more evokes than its breed allows, and one with no animal
		// type -- his sheet refuses to apply the race without one ("No Famorian animal type
		// found/selected. Nothing done.", 4546). Reported here, as every other race problem is.
		var tmpfamrace = this.raceItems.find(tmprace => tmprace.system.famorian?.isFamorian);
		if (tmpfamrace) {
			var tmpbudget = checkEvokeBudget(this.physical.famorian?.evokes,
				(this.physical.famorian?.evokesAllowed ?? 0) < 0 ? null : this.physical.famorian?.evokesAllowed);
			if (tmpbudget.issue) { tmpissues.push(tmpbudget.issue); }
			if (!this.physical.famorian?.animalType) {
				tmpissues.push("This Famorian has no animal type. His sheet will not apply the race without one.");
			}
		}

		if (this.identity.isFormless) {
			if (this.identity.formlessIssue) { tmpissues.push(this.identity.formlessIssue); }
		} else if (this.raceItems.length > 1) {
			var tmpfirst = this.raceItems[0];
			if (!canRacesBreed(tmpfirst.name, tmpfirst.system.fertileWith, this.raceItems[1].name)) {
				tmpissues.push(`${tmpfirst.name} and ${this.raceItems[1].name} cannot have children together.`);
			}
		}

		// A Half Race holding one winged and one wingless faerie form: neither physique lock is
		// right for both halves, so this is reported beside the barred-class and infertile-pair
		// issues above rather than decided here. Same call, same text -- resolvePhysiqueLock's own
		// reason. See docs/sonnet/2026-09-21-race-forms.md item 3.
		var tmpphysiqueconflict = resolvePhysiqueLock(this.raceItems.map(tmprace => tmprace.system));
		if (tmpphysiqueconflict.conflict) { tmpissues.push(tmpphysiqueconflict.reason); }

		return tmpissues;
	}

	// This is the function which lists what stops this character being dual-classed.
	//
	// Player's Guide, "Dual Class Characters", Requirements: the character "must meet attribute
	// requirements of both classes and must have a minimum Knowledge of 15", and must meet the
	// racial requirements for both. It is also a decision the Game Master has to support, so
	// nothing here refuses anything -- it reports, and the sheet shows it.
	//
	// The racial half is checked separately, for every character and not only a dual-classed
	// one, by _getRaceIssues -- his classRaceAndDetails does carry which races each class is
	// closed to, which an earlier pass here missed.
	_getDualClassIssues() {
		if (!this.identity.isDualClass) { return []; }

		var tmpissues = [];
		if ((parseInt(this.attributes.knw.value) || 0) < 15) {
			tmpissues.push(`Dual class needs Knowledge 15; this character has ${this.attributes.knw.value}.`);
		}

		var tmporder = ["str", "agl", "vit", "int", "wis", "knw", "app", "chm", "soc", "aur", "pty", "wil"];
		for (const tmpclass of this.classItems) {
			var tmpqualify = tmpclass.system.requirements?.attribQualify ?? [];
			for (var i = 0; i < tmporder.length; i++) {
				var tmpneeded = parseInt(tmpqualify[i]) || 0;
				if (!tmpneeded) { continue; }
				var tmphas = parseInt(this.attributes[tmporder[i]].value) || 0;
				if (tmphas < tmpneeded) {
					tmpissues.push(`${tmpclass.name} needs ${tmporder[i].toUpperCase()} ${tmpneeded}; this character has ${tmphas}.`);
				}
			}
		}
		return tmpissues;
	}

	// This is the function which sets each attribute's two maximums, its save percentage and its
	// table-driven modifiers.
	//
	// THERE ARE TWO CEILINGS, not one. The ordinary maximum is the race's own limit until title
	// 11, when racial limits are discarded and 25 applies; the magical maximum is higher and
	// tiered by title (23 / 25 / 27). He confirmed the pair on 2026-09-16 -- "25 for normal
	// statistic upgrades, 27 for magical upgrades" -- which resolved what had looked like a
	// contradiction in his code. See getMagicalAttributeMax and UPSTREAM-ISSUES.md item 16.
	//
	// Only the ordinary maximum clamps the value today. Applying the magical one needs modifiers
	// split into mundane and magical channels the way his sheet splits them (tmp_mod_str_mundane
	// against tmp_mod_str_magic), which the port does not do yet -- so the figure is derived and
	// shown, and nothing is clamped by it until there is a magical modifier to clamp.
	//
	// It is applied here rather than in prepareBaseData so it also constrains anything an Active
	// Effect added.
	_prepareAttributes() {
		var tmpracelimits = this.raceItem ? this.raceItem.system.attributeLimits : null;
		var tmpmagicalcap = ImagineCharacterData.getMagicalAttributeMax(this.identity.title);

		for (const tmpkey of Object.keys(this.attributes)) {
			var tmpattrib = this.attributes[tmpkey];

			var tmpracelimit = (tmpracelimits && tmpracelimits[tmpkey]) ? tmpracelimits[tmpkey] : 0;
			var tmpcap = ImagineCharacterData.getAttributeMax(this.identity.title, tmpracelimit);

			tmpattrib.max = tmpcap;
			tmpattrib.magicalMax = tmpmagicalcap;
			if (tmpattrib.value > tmpcap) { tmpattrib.value = tmpcap; }
			if (tmpattrib.value < 0) { tmpattrib.value = 0; }

			// @MARKER TEMPORARY MAGIC MODIFIER
			// The magic half of a temporary modifier goes on AFTER the natural cap, and is held to the magical
			// one instead -- his setSTRAttributeModifiers: mundane to _max, then magic to _magic_max.
			var tmpmagicmod = parseInt(this.tempMods?.magicAttr?.[tmpkey]) || 0;
			tmpattrib.magicMod = tmpmagicmod;
			if (tmpmagicmod) { tmpattrib.value = Math.min(tmpmagicalcap, Math.max(0, tmpattrib.value + tmpmagicmod)); }

			tmpattrib.save = ImagineCharacterData.getAttribSave(tmpattrib.value);

			// The table modifiers are irregular lookup values, not formulas -- see
			// module/config-tables.mjs. Missing ratings fall back to an empty set rather
			// than throwing, so a malformed actor still opens.
			var tmptable = ATTRIBUTE_TABLES[tmpkey];
			tmpattrib.mods = (tmptable && tmptable[tmpattrib.value]) ? tmptable[tmpattrib.value] : {};
		}
	}

	// This is the function which calculates the four characteristics. Each is the average of
	// one of the four attribute categories, rounded up, then adjusted.
	//     Endurance  = physical  (STR AGL VIT)
	//     Perception = mental    (INT WIS KNW)
	//     Affinity   = personal  (APP CHM SOC)
	//     Fortune    = mystical  (AUR PTY WIL)
	// Shock is Endurance x 3, per the Player's Guide character creation steps.
	_prepareCharacteristics() {
		var tmpattribs = this.attributes;

		// Pull the racial modifiers across before the totals are worked out. Endurance takes
		// its racial modifier from the race's starting-endurance figure, which is where the
		// original sheet kept it (race_start_end_mod).
		if (this.raceItem) {
			var tmpracesys = this.raceItem.system;
			// The starting-Endurance figure is a first-title bonus. A GME never takes a first title, so
			// his sheet gives it none: "GMEs (0 title) get no 1st title endurance modifier"
			// (sheet-worker.js:8142).
			var tmpnonclassed = this.classItems.some(tmpclass => tmpclass.system.nonClassed);
			// The race's flat Start mod and its rolled Start roll together (a Gaunt's -1d4, rolled into
			// its own field on this character's copy of the race): getStartingEnduranceMod, race-rules.mjs.
			this.characteristics.endurance.raceMod  = tmpnonclassed ? 0 : getStartingEnduranceMod(tmpracesys.endurance);
			this.characteristics.perception.raceMod = tmpracesys.characteristicMods.perception;
			this.characteristics.affinity.raceMod   = tmpracesys.characteristicMods.affinity;
			this.characteristics.fortune.raceMod    = tmpracesys.characteristicMods.fortune;
		}

		this._setCharacteristic("endurance",  tmpattribs.str.value, tmpattribs.agl.value, tmpattribs.vit.value);
		this._setCharacteristic("perception", tmpattribs.int.value, tmpattribs.wis.value, tmpattribs.knw.value);
		this._setCharacteristic("affinity",   tmpattribs.app.value, tmpattribs.chm.value, tmpattribs.soc.value);
		this._setCharacteristic("fortune",    tmpattribs.aur.value, tmpattribs.pty.value, tmpattribs.wil.value);

		// @MARKER TITLE AND CLASS CHARACTERISTIC BONUSES
		// The two terms of his changeCharacteristics (sheet-worker.js:30279-30348) that were never
		// written here, so a title-1 Mage's Fortune read 6 short of his.
		//
		//     characteristic  per title   class modifier     his lines
		//     Endurance       (stored)    "+5 Endurance"     30288
		//     Perception      +1          "+5% Perception"   30306, 8156
		//     Affinity        +2          "+5% Affinity"     30324, 8157
		//     Fortune         +1          "+5% Fortune"      30342, 8158
		//
		// WORKED OUT from the title every time rather than stored and raised, as his class_title_*
		// fields are: nothing on this port ever wrote them, so every character already made would
		// need a migration, and a derived figure cannot drift from the title it comes from. Endurance
		// keeps its stored titleBonus, because that one is ROLLED each title and cannot be derived.
		// A GME has title 0 and so no title bonus, as his 8145 has it. The class modifiers are read
		// off the class text his way, since the Active Effects item-class.mjs promised were never made.
		var tmptitle = parseInt(this.identity?.title) || 0;
		var tmpclassmods = this.classItems.flatMap(tmpclass => tmpclass.system.classMods ?? []);
		var tmpextras = {
			// characteristic   per title   class modifier text
			endurance:  [0, "+5 Endurance"],
			perception: [1, "+5% Perception"],
			affinity:   [2, "+5% Affinity"],
			fortune:    [1, "+5% Fortune"]
		};
		for (const [tmpname, [tmppertitle, tmpmodtext]] of Object.entries(tmpextras)) {
			var tmpchar = this.characteristics[tmpname];
			tmpchar.titleAdd = tmppertitle * tmptitle;
			tmpchar.classMod = tmpclassmods.includes(tmpmodtext) ? 5 : 0;
			tmpchar.value = tmpchar.value + tmpchar.titleAdd + tmpchar.classMod;
		}

		this.body.shock = this.characteristics.endurance.value * 3;
	}

	// This is the function which averages three attributes and applies the stored adjustments.
	// The +.99 truncation is his rounding idiom from changeCharacteristics, kept as-is so the
	// arithmetic matches his sheet exactly rather than merely closely.
	_setCharacteristic(tmpname, tmpvalue1, tmpvalue2, tmpvalue3) {
		var tmpchar = this.characteristics[tmpname];
		var tmpbase = parseInt(((tmpvalue1 + tmpvalue2 + tmpvalue3) / 3) + 0.99) || 0;

		tmpchar.base = tmpbase;
		tmpchar.value = tmpbase + tmpchar.titleBonus + tmpchar.raceMod + tmpchar.permMod + tmpchar.tempMod;
	}

	// This is the function which resolves the five resistance tracks. Each has a base drawn
	// from an attribute's table, plus manual adjustment. Class and racial bonuses arrive as
	// Active Effects rather than the string matching the original sheet used
	// ("+10% Magic Resist", "+5% all Resists").
	// An immunity replaces the percentage outright, so it is checked first.
	_prepareResistances() {
		var tmpmods = {
			str: this.attributes.str.mods, agl: this.attributes.agl.mods,
			vit: this.attributes.vit.mods, int: this.attributes.int.mods,
			wis: this.attributes.wis.mods, aur: this.attributes.aur.mods,
			wil: this.attributes.wil.mods
		};

		this._setResistance("magic",    tmpmods.aur.magicResist);
		this._setResistance("illusion", tmpmods.wis.illusionResist);
		this._setResistance("poison",   tmpmods.vit.poisonResist);
		this._setResistance("disease",  tmpmods.vit.diseaseResist);

		// Control Resistance is the one that combines sources: a base from Will Force, then
		// adjustments from both Intelligence and Wisdom.
		var tmpcontrol = (tmpmods.wil.controlResist || 0)
		               + (tmpmods.int.controlResistAdjust || 0)
		               + (tmpmods.wis.controlResistAdjust || 0);
		this._setResistance("control", tmpcontrol);

		// @MARKER FORMLESS CONTROL
		// A Formless is immune to control, yet rolls a "special Control Resistance" to take, keep or do
		// without a host: the resistance it would have were it not immune (setFormlessSpecialControl-
		// Resistance, sheet-worker.js:128175). Read by the shape-change window.
		this.identity.formlessControl = getFormlessControl(this.resistances.control);
	}

	// This is the function which finalises one resistance track.
	_setResistance(tmpname, tmpbase) {
		var tmpresist = this.resistances[tmpname];
		var tmpracemod = 0;
		if (this.raceItem) { tmpracemod = this.raceItem.system.resistanceMods[tmpname] || 0; }

		tmpresist.base = parseInt(tmpbase) || 0;
		tmpresist.raceMod = tmpracemod;
		tmpresist.value = tmpresist.immune ? null : tmpresist.base + tmpracemod + tmpresist.misc;
	}

	// @MARKER LANGUAGE ALLOWANCE
	// This is the function which works out how many languages the character's Intelligence
	// allows, and whether the languages recorded on the sheet fit inside it.
	//
	// Ported from his setLangSheet (sheet-worker.js:49228, run at character creation) and its
	// twin setUpdateLanguageSheet (50561, run from the Update Languages step). The two switches
	// agree case for case across all 31 ratings -- checked 2026-09-18. The update copy reads the
	// character's CURRENT intelligence, not the creation-time int_final, so the allowance
	// follows the attribute as it stands, which is what a derived value does anyway. The Player's
	// Guide agrees: the figures come from "Intelligence score after all modifications".
	//
	// A row on the sheet is a slot, named or not. The Player's Guide lets a character "leave any
	// number of language slots open for future learning", and an empty row is exactly that, so
	// it counts against the allowance like a named one.
	//
	// Nothing is refused or removed. A character whose Intelligence falls keeps every language
	// they had, and the rows past the allowance are flagged -- the same call already made for
	// skill slots and for content the campaign has switched off.
	_prepareLanguages() {
		var tmpintmods  = this.attributes.int.mods;
		var tmpspoken   = parseFloat(tmpintmods.spokenLanguages)  || 0;
		var tmpwritten  = parseFloat(tmpintmods.writtenLanguages) || 0;
		var tmplabels   = ImagineCharacterData.getLanguageSlotLabels(tmpspoken, tmpwritten);

		// A slot writes if his label says it does, whole or partly ("Speaks/third writes:").
		var tmpwriteslots = tmplabels.filter(tmplabel => tmplabel.includes("writes")).length;

		var tmplanguages = this.languages ?? [];
		var tmpwrittenused = tmplanguages.filter(tmplang => tmplang.write).length;

		this.languageAllowance = {
			spoken:       tmpspoken,          // straight off his Intelligence table
			written:      tmpwritten,
			labels:       tmplabels,          // his own slot labels, one per slot
			slots:        tmplabels.length,
			writtenSlots: tmpwriteslots,
			used:         tmplanguages.length,
			writtenUsed:  tmpwrittenused,
			overSpoken:   tmplanguages.length > tmplabels.length,
			overWritten:  tmpwrittenused > tmpwriteslots,
			rows:         ImagineCharacterData.assignLanguageSlots(tmplanguages, tmplabels)
		};
	}

	// This is the function which sets the character's movement rates from their race.
	// Every mode is tracked at three scales at once -- per hour, per 10 second combat round,
	// and per second.
	//
	// The rates here are UNENCUMBERED, as his sheet shows them. His sheet never slows a loaded
	// character down; the Player's Guide does, so the rates at the current load are worked out
	// alongside as movement.loaded (resolveLoadedMovement) rather than replacing these.
	_prepareMovement() {
		if (!this.raceItem) { return; }
		var tmpracemove = this.raceItem.system.movement;
		var tmpbase     = getMovementBase(this.attributes.agl.value);
		var tmpmulti    = tmpracemove.speedMultiplier;

		// @MARKER TEMPORARY MOVEMENT
		// His Movement modifiers (calcMovement, sheet-worker.js:30856): a temporary multiplier REPLACES the
		// racial one when it is not 1 ("temporarily overrides racial multiplier"), and fatigue slows the rates by
		// its table's fraction. His code lets fatigue overwrite the multiplier as well; here it multiplies it, so
		// a fast race that tires is slowed rather than made average -- the book's table is a fraction OF the rate.
		var tmptemp = this.tempMods ?? {};
		var tmptempmulti = parseFloat(tmptemp.moveMulti) || 1;
		var tmpracial = (parseFloat(tmpmulti) || 0) > 0 ? parseFloat(tmpmulti) : 1;
		var tmpfatigue = getTempEffects(tmptemp).movement;
		tmpmulti = ((tmptempmulti != 1) ? tmptempmulti : tmpracial) * tmpfatigue;

		// The race's figures are MODIFIERS on the Agility base, not finished rates -- see the
		// movement block in combat-rules.mjs. A race carrying 0/0/0 has no modifier and moves at
		// the full base; it is not a race that cannot move.
		//
		// Each scale carries its own floor for a negative result: 1 mile, 10 feet, 1 foot.
		var tmpfloors = { hourly: 1, tenSec: 10, oneSec: 1 };
		for (const tmpmode of ["walk", "jog", "run"]) {
			for (const [tmpscale, tmpcolumn] of [["hourly", 0], ["tenSec", 1], ["oneSec", 2]]) {
				this.movement[tmpmode][tmpscale] = resolveMovementRate(
					tmpbase[tmpmode][tmpcolumn], tmpracemove[tmpmode][tmpscale],
					tmpmulti, tmpfloors[tmpscale]);
			}
		}

		// Jumping is the same shape -- an Agility base plus the race's modifier -- but has no
		// speed multiplier and no published floor, so a penalty is allowed to take it to zero.
		this.movement.jumpStand = Math.max(0, tmpbase.jumpStand + (parseFloat(tmpracemove.jumpStand) || 0)
		                                      + (parseFloat(tmptemp.standJump) || 0));
		this.movement.jumpUp    = Math.max(0, tmpbase.jumpUp    + (parseFloat(tmpracemove.jumpUp)    || 0)
		                                      + (parseFloat(tmptemp.upJump) || 0));

		// The temporary walk, jog and run modifiers: one figure, hourly as given, x10 for ten seconds, x1 for
		// one second (his tmp_walk_mod * 10). Added after the multiplier, as he adds them to the finished rate.
		for (const tmpmode of ["walk", "jog", "run"]) {
			var tmpflat = parseFloat(tmptemp[tmpmode]) || 0;
			if (!tmpflat) { continue; }
			this.movement[tmpmode].hourly = Math.max(0, this.movement[tmpmode].hourly + tmpflat);
			this.movement[tmpmode].tenSec = Math.max(0, this.movement[tmpmode].tenSec + (tmpflat * 10));
			this.movement[tmpmode].oneSec = Math.max(0, this.movement[tmpmode].oneSec + tmpflat);
		}
		// Daily travel and rest hours have no figure in the port to add to; the modifiers are kept for display.
		this.movement.dailyMoveMod = parseFloat(tmptemp.dailyMove) || 0;
		this.movement.dailyRestMod = parseFloat(tmptemp.dailyRest) || 0;

		// "None:" is his sentinel for a race with no special rate, not the name of one -- it is
		// carried by exactly the 79 races whose special base rate is empty. It is dropped here so
		// that absence reads as absence, and the sheet does not print a row labelled "None:".
		this.movement.specialName =
			(("" + (tmpracemove.specialName ?? "")).trim() == "None:") ? "" : tmpracemove.specialName;

		// The special rate builds on the rates just resolved, so it has to come after them.
		var tmpspecial = resolveSpecialMovement(tmpracemove.specialName, tmpracemove.special,
			this.movement, tmpmulti, this.attributes.int.value);
		this.movement.special.hourly = tmpspecial.hourly;
		this.movement.special.tenSec = tmpspecial.tenSec;
		this.movement.special.oneSec = tmpspecial.oneSec;

		// The temporary special modifier on the race's own special rate, and a temporary special TYPE which
		// replaces it altogether (his "Replace Special Movement Type", worked out from the finished walk and run).
		var tmpspecialmod = parseFloat(tmptemp.special) || 0;
		if (tmptemp.specialType) {
			var tmpreplaced = resolveTempSpecialMovement(tmptemp.specialType, this.movement,
				tmptemp.specialSpeed, tmpracial, this.attributes.int.value, tmpspecialmod);
			this.movement.specialName = tmptemp.specialType;
			this.movement.special.hourly = tmpreplaced.hourly;
			this.movement.special.tenSec = tmpreplaced.tenSec;
			this.movement.special.oneSec = tmpreplaced.oneSec;
		} else if (tmpspecialmod && this.movement.specialName) {
			this.movement.special.hourly = Math.max(0, this.movement.special.hourly + tmpspecialmod);
			this.movement.special.tenSec = Math.max(0, this.movement.special.tenSec + (tmpspecialmod * 10));
			this.movement.special.oneSec = Math.max(0, this.movement.special.oneSec + tmpspecialmod);
		}

		// A second special rate, for the one race the books give two of: a Nixie swims AND flies
		// (Legends p.33), and his row has room for only the flight -- the swim is his Formless copy
		// of the same row. Read exactly as the first is. DERIVED ONLY, never stored: it has no field
		// on the character, so an actor made before it existed needs nothing to load, and a race
		// document made before it existed reads as blank (the schema's initial values).
		var tmpsecondname = ("" + (tmpracemove.secondSpecialName ?? "")).trim();
		if (tmpsecondname == "None:") { tmpsecondname = ""; }
		this.movement.secondSpecialName = tmpsecondname;
		this.movement.secondSpecial = tmpsecondname
			? resolveSpecialMovement(tmpsecondname, tmpracemove.secondSpecial ?? {},
				this.movement, tmpmulti, this.attributes.int.value)
			: { hourly: 0, tenSec: 0, oneSec: 0 };

		// For a slithering race the special rate is not an extra on top of walking, it is the whole
		// of their movement -- "Slither is the only movement sssssnake people have", and they do
		// not jump either. His sheet zeroes these after the fact too, so this runs last.
		if (specialMovementReplacesOther(tmpracemove.specialName)) {
			for (const tmpmode of ["walk", "jog", "run"]) {
				this.movement[tmpmode].hourly = 0;
				this.movement[tmpmode].tenSec = 0;
				this.movement[tmpmode].oneSec = 0;
			}
			this.movement.jumpStand = 0;
			this.movement.jumpUp    = 0;
		}
	}

	// This is the function which reads the skill slot allowances off the Knowledge table, and
	// then applies whatever trades the character has made to them.
	//
	// A character may not hold more skills in a category than they have slots for it -- but the
	// allowance itself is not fixed, since the Player's Guide's "slot tricks" let racial and
	// social slots be traded between categories or given up for a bonus. The base figures are
	// Knowledge's; getSlotAllowance does the trading arithmetic, ported from his four conversion
	// functions. Both are kept, so the sheet can show what the trades cost.
	_prepareSkillSlots() {
		var tmpknw = this.attributes.knw.mods;

		var tmpbase = {
			class:  parseInt(tmpknw.classSkills) || 0,
			racial: parseInt(tmpknw.raceSkills) || 0,
			social: parseInt(tmpknw.socialSkills) || 0
		};
		var tmpallowance = getSlotAllowance(tmpbase, this.skillSlotMoves);

		this.skillSlots = {
			class:         tmpallowance.class,
			racial:        tmpallowance.racial,
			social:        tmpallowance.social,
			classBase:     tmpbase.class,
			racialBase:    tmpbase.racial,
			socialBase:    tmpbase.social,
			memorization:  parseInt(tmpknw.memorizationPoints) || 0,
			classUsed:  0,
			// Of classUsed, the class skills still to come -- the rest of the career, reserved.
			classReserved: 0,
			racialUsed: 0,
			socialUsed: 0,
			classOver:  false,
			racialOver: false,
			socialOver: false
		};
	}

	// This is the function which notices a category holding more skills than it has slots for.
	//
	// Split out as its own step, run straight after _prepareSkills, because the used counts are
	// made there and the allowance is made in _prepareSkillSlots before it -- the comparison
	// cannot live in either without one of them reading a value the other has not written yet.
	//
	// It flags rather than prevents. His sheet refuses the selection outright ("More selected than
	// total slots. Nothing done.", sheet-worker.js:7049), but it refuses at a character-generation
	// step this port has not built, and a skill here is an Item that can be dropped on an actor
	// from anywhere. Flagging matches how availability already marks an item that should not be
	// there without deleting it, and leaves the Game Master the last word.
	_prepareSkillSlotStatus() {
		this.skillSlots.classOver  = this.skillSlots.classUsed  > this.skillSlots.class;
		this.skillSlots.racialOver = this.skillSlots.racialUsed > this.skillSlots.racial;
		this.skillSlots.socialOver = this.skillSlots.socialUsed > this.skillSlots.social;
	}

	// This is the function which calculates every skill chance on the character, and counts
	// how many slots each category has consumed.
	//
	// Player's Guide p.94:
	//     base chance  = (combined attributes - skill rating) x 5%
	//     total chance = base chance + starting bonus + ability bonus + modifiers
	// A skill being attempted untrained uses the base chance alone, with no starting bonus.
	//
	// This runs from the actor rather than from the skill item because embedded items are
	// prepared BEFORE the actor's derived data, so a skill computing for itself would read
	// attribute values that are not final yet.
	_prepareSkills() {
		var tmpactor = this.parent;
		if (!tmpactor || !tmpactor.items) { return; }

		// The title a class skill's gate is measured against. A dual-classed character is measured
		// against whichever class has climbed highest: the skill was granted by one of the two, and
		// the port does not record which, so the generous reading is the safe one -- it can only
		// fail to gate a skill, never refuse one the character has genuinely earned.
		// A character with no class at all falls back to their own title, so a skill held from a
		// class since removed -- or a GME given one by hand -- is not refused for ever by a gate
		// measured against a class that is not there.
		var tmpgatetitle = this.classItems.length ? 0 : (parseInt(this.identity.title) || 0);
		var tmpgatename = "";
		for (const tmpclass of this.classItems) {
			var tmpclasstitle = this._getClassTitle(tmpclass);
			if (tmpclasstitle <= tmpgatetitle) { continue; }
			tmpgatetitle = tmpclasstitle;
			tmpgatename = tmpclass.name;
		}

		for (const tmpitem of tmpactor.items) {
			if (tmpitem.type != "skill") { continue; }
			var tmpskill = tmpitem.system;

			var tmpcombined = this._getCombinedAttributes(tmpskill.attr1, tmpskill.attr2);
			tmpskill.combinedAttributes = tmpcombined;
			tmpskill.baseChance = (tmpcombined - tmpskill.skillRating) * 5;

			// @MARKER TITLE GATE
			// A class skill held but not yet reached -- his "this skill cannot be used before
			// <name> title". It stays on the sheet, with its chance shown, and the roll refuses.
			var tmpgateclass = this.classItems.find(tmpclass => tmpclass.name == tmpgatename);
			var tmptitlename = ImagineCharacterData.getClassTitleName(tmpgateclass,
				parseInt(tmpskill.acquiredAtTitle) || 0);
			var tmpgate = checkClassSkillTitle(tmpskill.acquiredAtTitle, tmpgatetitle, tmptitlename);
			tmpskill.usableByTitle = tmpgate.usable;
			tmpskill.titleGateReason = tmpgate.reason;

			// @MARKER TEMPORARY SKILLS MODIFIER
			// The Skills box of the Temporary Modifiers panel, fatigue and mental fatigue: a percentage on every
			// skill (combat.tempSkillMod, worked out in _prepareCombat).
			var tmptempskill = parseInt(this.combat.tempSkillMod) || 0;
			if (tmpskill.isCommon) {
				tmpskill.totalChance = tmpskill.baseChance + tmpskill.misc + tmptempskill;
			} else {
				tmpskill.totalChance = tmpskill.baseChance
				                     + tmpskill.startingBonus
				                     + tmpskill.abilityBonus
				                     + tmpskill.misc + tmptempskill;
				if (tmpskill.category == "class")  { this.skillSlots.classUsed++; }
				if (tmpskill.category == "racial") { this.skillSlots.racialUsed++; }
				if (tmpskill.category == "social") { this.skillSlots.socialUsed++; }
			}
		}

		// @MARKER WHOLE CAREER
		// His model reserves the whole career's class slots at creation: Step 6 compares Knowledge's
		// class slots with every title's skills (getSlotsNeededForClass, sheet-worker.js:62881) and will
		// not go on while they are short, and setFinalClassSkills writes titles 2-15 onto the sheet then
		// (63288 onward). So a class skill not reached yet is already using its slot (user's ruling
		// 2026-09-26). Each row of this character's classes that it does not hold yet counts too; a row
		// given up at creation (removed) does not. A skill held is counted once, above, whoever put it
		// there.
		var tmpheldnames = [...tmpactor.items].filter(tmpitem => tmpitem.type == "skill").map(tmpitem => tmpitem.name);
		// A skill on both of a dual-classed character's lists is one skill when granted, so the second
		// class does not reserve it again: a name an EARLIER class reserved is skipped. Within one class
		// every row counts, as his getSlotsNeededForClass counts them, so reserved and needed agree.
		var tmpcannotcast = !!this.identity.cannotCast;
		var tmpotherclassnames = [];
		for (const tmpclass of this.classItems) {
			if (tmpclass.system?.nonClassed) { continue; }
			var tmpthisclassnames = [];
			for (const tmprow of getWholeCareerRows(tmpclass.system, tmpcannotcast)) {
				if (tmprow.removed || tmpheldnames.includes(tmprow.name)) { continue; }
				if (tmpotherclassnames.includes(tmprow.name)) { continue; }
				tmpthisclassnames.push(tmprow.name);
				this.skillSlots.classUsed++;
				this.skillSlots.classReserved++;
			}
			tmpotherclassnames.push(...tmpthisclassnames);
		}
	}

	// This is the function which resolves the two off-hand fighting skills' chances, once
	// _prepareSkills above has finished computing every skill's totalChance. Split out as its
	// own step, run straight after _prepareSkills in prepareDerivedData, because _prepareCombat
	// -- where the title-eligibility flags above are set -- runs BEFORE skills are prepared, and
	// changing that order would risk other combat fields silently depending on it.
	//
	// A character not yet eligible by title reads as 0, exactly as having no skill at all would --
	// see the gating note on resolveOffhandPenalties in combat-rules.mjs.
	_prepareOffhandSkills() {
		this.combat.secondWeaponKnowChance = this.combat.hasSecondWeaponKnowledge
			? this._getSkillChance("Second Weapon Knowledge") : 0;
		this.combat.secondWeaponLoreChance = this.combat.hasSecondWeaponLore
			? this._getSkillChance("Second Weapon Lore") : 0;

		// Multiple Missile Knowledge's own percentage, which is what buys the multi-missile
		// penalty down 1 and 2 at a time. Unlike its Lore half there is no class title gating it
		// in his sheet at all -- holding the skill is the whole of it -- so this is read straight
		// off the actor with no eligibility test in front of it.
		this.combat.multiMissileKnowChance = this._getSkillChance("Multiple Missile Knowledge");

		// Weapon proficiencies (his setWeaponProfValues, 83126): total, used and available, and the penalty
		// to hit with a weapon not proficient in, all from Weapon Knowledge's own chance. And the three
		// chances the Weapon Choices window rolls against that are not read above.
		this.combat.weaponKnowChance = this._getSkillChance("Weapon Knowledge");
		var tmpprofs = getWeaponProfTotals(this.combat.weaponKnowChance, this.combat.weaponProfList);
		this.combat.weaponProfTotal = tmpprofs.total;
		this.combat.weaponProfUsed = tmpprofs.used;
		this.combat.weaponProfAvailable = tmpprofs.available;
		this.combat.nonProfPenalty = tmpprofs.penalty;
		this.combat.nonProfSkillsPenalty = tmpprofs.skillsPenalty;
		this.combat.weaponLoreChance = this._getSkillChance("Weapon Lore");
		this.combat.missileLoreChance = this._getSkillChance("Missile Lore");
		this.combat.projectileKnowChance = this._getSkillChance("Projectile Knowledge");
		this.combat.projectileLoreChance = this._getSkillChance("Projectile Lore");
		this.combat.hasProjectileKnowledge = !!this.parent?.items?.some(tmpitem => tmpitem.type == "skill" && tmpitem.name == "Projectile Knowledge");

		// Soldiering, a social skill: held when the character has the skill item. It names one weapon
		// (combat.soldieringWeapon) that is +1 to hit and damage; see module/soldiering-rules.mjs.
		this.combat.hasSoldiering = !!this.parent?.items?.some(tmpitem => tmpitem.type == "skill" && tmpitem.name == "Soldiering");

		// How many of the round's ten seconds may go to off-hand actions. This is the allowance; what
		// a round has spent of it is on the combatant's round clock (module/combat/round-rules.mjs),
		// which also takes off what a late initiative costs. See getOffhandSecondsCap.
		this.combat.offhandSecondsCap = getOffhandSecondsCap(
			this.physical.handedness, this.combat.secondWeaponLoreChance);
	}

	// @MARKER MAGIC
	// This is the function which works out how far the character has come as a caster and as an
	// invoker -- his setMagicDivineLore (sheet-worker.js:96635). The rules are casting-rules.mjs; this
	// gathers the class, the title, the attributes and the skills they read, and lays the results out
	// on magic.aura and magic.piety for the tab and for a cast.
	//
	// After the skills, whose chances it reads (Spell Lore, the casting skills, Divine Knowledge).
	// A dual-classed character takes the better of the two classes' figures, as the Player's Guide
	// has the better of two versions of anything apply (Dual Class, Experience and Advancement rule 4).
	_prepareMagic() {
		// The schema always supplies magic; a character built outside Foundry (the test pages) may not.
		if (!this.magic) { this.magic = {}; }
		var tmpmagic = this.magic;
		var tmpskills = (this.parent?.items ?? []).filter(tmpitem => tmpitem.type == "skill");
		var tmptitle = parseInt(this.identity.title) || 0;
		var tmpstanding = (tmpname) => getSkillStanding(tmpskills, tmpname, tmptitle);
		var tmpheld = (tmpname) => { var tmps = tmpstanding(tmpname); return tmps.held && tmps.chance > 0; };
		var tmpintmods = this.attributes.int?.mods ?? {};
		var tmpwismods = this.attributes.wis?.mods ?? {};
		var tmpaura = parseInt(this.attributes.aur?.value) || 0;

		// @MARKER AURA
		var tmpbestaura = { value: 0, max: 0, isCaster: false, parts: [] };
		var tmpcasterclass = null;
		for (const tmpclass of this.classItems ?? []) {
			var tmpclassname = tmpclass.system.baseClass || tmpclass.name;
			var tmpac = getAuraControl({
				className: tmpclassname,
				title: this._getClassTitle(tmpclass),
				casterStartTitle: tmpclass.system.casting?.isCaster ? tmpclass.system.casting.casterStartTitle : 0,
				intAdjust: tmpintmods.auraControlAdjust,
				metaphysics: tmpheld("Metaphysics"),
				boost: tmpmagic.auraControlBoost,
				spellLore: tmpheld("Spell Lore"),
				windsOfWildMagic: tmpclassname == "Wilder" && tmpheld("Winds of Wild Magic"),
				suppressed: tmpmagic.magicSuppressed
			});
			if (tmpac.isCaster && (!tmpbestaura.isCaster || tmpac.value > tmpbestaura.value)) {
				tmpbestaura = tmpac;
				tmpcasterclass = { name: tmpclassname, title: this._getClassTitle(tmpclass),
					start: tmpclass.system.casting?.casterStartTitle || 0 };
			}
		}
		// The skill a spell is cast with: the best of his five held (storeBestCastingSkill), and its
		// practitioner title, which a few of his cases read.
		var tmpcasting = CASTING_SKILLS.map(tmpname => tmpstanding(tmpname)).filter(tmps => tmps.held)
			.sort((a, b) => b.chance - a.chance)[0] ?? null;
		var tmppool = getAuraPool({ title: tmptitle, aura: tmpaura, additional: tmpmagic.additionalAura,
			drained: tmpmagic.drainedAura });
		tmpmagic.aura = {
			isCaster: tmpbestaura.isCaster,
			className: tmpcasterclass?.name ?? "",
			control: tmpbestaura.value,
			controlMax: tmpbestaura.max,
			controlParts: tmpbestaura.parts,
			controlCapped: !!tmpbestaura.capped,
			controlDoubled: !!tmpbestaura.doubled,
			pool: tmppool,
			regen: getAuraRegen({ className: tmpcasterclass?.name ?? (this.classItem?.system?.baseClass || this.classItem?.name || ""),
				title: tmpcasterclass?.title ?? tmptitle, casterStartTitle: tmpcasterclass?.start ?? 0,
				double: tmpmagic.auraRegenDouble }),
			casting: tmpcasting ? { name: tmpcasting.name, chance: tmpcasting.chance, practitionerTitle: tmpcasting.practitionerTitle } : null,
			absorbAura: tmpstanding("Absorb Aura").chance,
			// His aura_fatigue_note: a mortal who can put 22 or more into a spell risks Aura Fatigue.
			fatigueWarning: tmptitle < 11 && tmpbestaura.value > 20
		};

		// @MARKER PIETY
		var tmpbestpiety = { value: 0, level: 0, isInvoker: false, parts: [] };
		for (const tmpclass of this.classItems ?? []) {
			var tmppc = getPietyControl({
				className: tmpclass.system.baseClass || tmpclass.name,
				title: this._getClassTitle(tmpclass),
				invokerStartTitle: tmpclass.system.casting?.isInvoker ? tmpclass.system.casting.invokerStartTitle : 0,
				wisAdjust: tmpwismods.pietyControl,
				theology: tmpheld("Theology"),
				levelBoost: tmpmagic.pietyLevelBoost,
				denial: tmpmagic.divineDenial
			});
			if (tmppc.isInvoker && (!tmpbestpiety.isInvoker || tmppc.value > tmpbestpiety.value)) { tmpbestpiety = tmppc; }
		}
		tmpmagic.piety = {
			isInvoker: tmpbestpiety.isInvoker,
			control: tmpbestpiety.value,
			level: tmpbestpiety.level,
			controlParts: tmpbestpiety.parts,
			divineKnowledge: Math.max(tmpstanding("Divine Knowledge").chance, tmpstanding("Divine Knowledge(w)").chance),
			bless: tmpstanding("Bless").chance,
			blasphemy: tmpstanding("Blasphemy").chance
		};
	}

	// This is the function which totals the Situation Mods the character has set, and lays their
	// defence onto the character's own.
	//
	// The defence is the character's and stands whatever they attack with -- Furious Attack leaves
	// them easier to hit (+4) for as long as it is set. "No Defense" (blind, cannot see the target,
	// a critically failed Critical) takes the adjustment away from anyone attacking them; that is
	// read where the attack is made, as the target's noDefense.
	//
	// Martial arts feeds blind fighting in through combat.martialBlind, { blindFighting,
	// fullDefense, inStance }, when it has set one; until then nothing is passed.
	_prepareSituation() {
		var tmpsituation = this.combat.situation ?? {};
		this.combat.situational = resolveSituationalMods(tmpsituation.kind, tmpsituation.selected,
			this.combat.martialBlind ?? null);
		this.combat.defensiveAdjust = (parseInt(this.combat.defensiveAdjust) || 0) + this.combat.situational.defense;
		// His defensive_total is "No Defense" if the situational, martial or stance specials say so
		// (sheet-worker.js:102805) -- Immoveable Stance does -- so martial arts' own is folded in.
		this.combat.noDefense = this.combat.situational.noDefense || !!this.combat.martialDefense?.noDefense;

		// Martial Lore's "+5% to combat skills" per level while fighting blind (the book's figure, by
		// the user's ruling of 2026-09-22), laid on every skill typed Combat for as long as the blind
		// Situation Mods are set. Kept as blindBonus and reset every time, as stanceBonus is.
		var tmpblindskills = parseInt(this.combat.situational.blindSkills) || 0;
		for (const tmpitem of this.parent?.items ?? []) {
			if (tmpitem.type != "skill") { continue; }
			var tmpadd = (tmpblindskills && (tmpitem.system.types ?? []).includes("Combat")) ? tmpblindskills : 0;
			tmpitem.system.blindBonus = tmpadd;
			if (tmpadd) { tmpitem.system.totalChance = (parseInt(tmpitem.system.totalChance) || 0) + tmpadd; }
		}
	}

	// This is the function which reads one named skill's resolved chance off the actor, for the
	// handful of places (currently only off-hand fighting) that need a skill's own percentage
	// rather than its presence. Zero if the character has no skill of that name -- untrained
	// reads the same as absent, which is his behaviour too (storeTempSkillChanceAndMessage finds
	// nothing and temp_skill_chance stays 0).
	_getSkillChance(tmpname) {
		var tmpactor = this.parent;
		if (!tmpactor || !tmpactor.items) { return 0; }
		var tmpskill = tmpactor.items.find(i => i.type == "skill" && i.name == tmpname);
		return tmpskill ? (parseInt(tmpskill.system.totalChance) || 0) : 0;
	}

	// @MARKER MARTIAL ARTS
	// This is the function which works out the character's martial arts: which subskills they know
	// and at what chance, the stance they hold, the moves and Martial Lore values they have made, and
	// what all of that does to the rest of their combat figures. The rules are in
	// module/combat/martial-arts.mjs; this only gathers the inputs and lays the results out.
	//
	// Its own step, run straight after the skills, whose chances it reads, and BEFORE both
	// _prepareOffhandSkills (a held stance adds to skills, and the Drunken stance's combat-skill
	// bonus reaches Second Weapon Knowledge) and _prepareSituation, which reads combat.martialBlind
	// -- his handleMeleeSet takes the better of the stance's and Martial Lore's blind fighting when
	// it totals the situational modifiers.
	//
	// Three figures are CHARACTER-WIDE and are folded straight into the combat block, so that
	// everything already reading them follows without being told: a stance's defensive change and a
	// made Flip into defensiveAdjust (read by every attack against the character), a stance's
	// initiative into initiativeMod, and a stance's change to "offensive actions starting speed"
	// into weaponSpeedMod (every weapon's time, never under its minimum). Immoveable Stance's "No
	// Defense" is combat.martialDefense.noDefense; the attack against this character reads it.
	//
	// Nothing applies without Martial Knowledge. A stance or move written on a character who does
	// not hold the skill -- dragged off, or never acquired -- is shown and does nothing.
	_prepareMartialArts() {
		var tmpmartial = this.martial ?? {};
		this.martial = tmpmartial;

		var tmpknow = this._getMartialSkill("Martial Knowledge");
		var tmplore = this._getMartialSkill("Martial Lore");
		tmpmartial.hasKnowledge = tmpknow.held;
		tmpmartial.hasLore = tmplore.held;
		tmpmartial.knowChance = tmpknow.chance;
		tmpmartial.loreChance = tmplore.chance;

		// Everything the panel and the attacks read -- known, in play, the state and the rows -- worked
		// out by deriveMartialArts, which the creature model calls too. The weapon speed modifier goes in
		// BEFORE the stance's seconds, which the rows add themselves.
		Object.assign(tmpmartial, deriveMartialArts(tmpmartial, {
			know: tmpknow, lore: tmplore, weaponSpeedMod: this.combat.weaponSpeedMod }));

		// Character-wide, folded into what everything else already reads. See the note above.
		var tmpstate = tmpmartial.state;
		this.combat.defensiveAdjust = (parseInt(this.combat.defensiveAdjust) || 0) + tmpstate.defense.adjust;
		this.combat.initiativeMod = (parseInt(this.combat.initiativeMod) || 0) + tmpstate.initiative;
		this.combat.weaponSpeedMod = (parseInt(this.combat.weaponSpeedMod) || 0) + tmpstate.seconds;
		this.combat.martialDefense = tmpstate.defense;
		this.combat.martialBlind = tmpstate.blind;

		// The stance's bonuses to other figures, applied while it is held (the user's ruling of
		// 2026-09-22; his sheet only prints them). A skill's total takes it and records it as
		// stanceBonus, so what it came from can be shown and the Arch Mortal screen can take it back
		// out; saves and resistances take it straight. See getStanceBonuses.
		this._applyStanceBonuses(tmpstate.bonuses);
	}

	// This is the function which lays a held stance's bonuses onto the character's skills, saves and
	// resistances. Every skill item is visited, including a second copy of the same skill, since a
	// skill roll uses the best copy. The bonus a skill took is kept as stanceBonus.
	//
	// The skills are visited EVERY time, stance or none, because stanceBonus lives on the item
	// between derivations -- left alone, a stance dropped would leave its old figure behind for the
	// Arch Mortal screen to take out of a total that no longer has it in.
	_applyStanceBonuses(tmpbonuses) {
		var tmpactor = this.parent;
		for (const tmpitem of tmpactor?.items ?? []) {
			if (tmpitem.type != "skill") { continue; }
			var tmpadd = getStanceSkillBonus(tmpbonuses, tmpitem.name, tmpitem.system.types);
			tmpitem.system.stanceBonus = tmpadd;
			if (tmpadd) { tmpitem.system.totalChance = (parseInt(tmpitem.system.totalChance) || 0) + tmpadd; }
		}
		if (!tmpbonuses || !tmpbonuses.active) { return; }
		for (const [tmpkey, tmpvalue] of Object.entries(tmpbonuses.saves ?? {})) {
			if (this.attributes[tmpkey]) { this.attributes[tmpkey].save = (parseInt(this.attributes[tmpkey].save) || 0) + tmpvalue; }
		}
		// An immune resistance has no figure (value null) and stays immune.
		for (const [tmpname, tmpresist] of Object.entries(this.resistances ?? {})) {
			if (tmpresist?.value === null || tmpresist?.value === undefined) { continue; }
			var tmpresistadd = (parseInt(tmpbonuses.resistances?.[tmpname]) || 0) + (parseInt(tmpbonuses.allResistances) || 0);
			if (tmpresistadd) { tmpresist.value = tmpresist.value + tmpresistadd; }
		}
	}

	// This is the function which reads Martial Knowledge or Martial Lore off the character: whether
	// it is held and usable, and its chance. A class skill held before its title is reached is
	// refused on the roll (his handleHighTitleClassSkillRoll), and his checkForClassSkill finds no
	// such skill then either, so it reads as not held.
	_getMartialSkill(tmpname) {
		var tmpactor = this.parent;
		var tmpskill = tmpactor?.items?.find(i => i.type == "skill" && i.name == tmpname);
		if (!tmpskill || tmpskill.system.usableByTitle === false) { return { held: false, chance: 0 }; }
		return { held: true, chance: parseInt(tmpskill.system.totalChance) || 0 };
	}

	// This is the function which gives the chance for a skill the character does NOT hold,
	// attempted as a common skill.
	//
	// Player's Guide, "Who Can Use a Skill": "a character may attempt almost any skill in the game,
	// whether or not he has actually learned or acquired the skill... The common skill chance is
	// simply the base chance without the starting bonus." So this is the same first half of the
	// formula _prepareSkills uses, and deliberately none of the second: no starting bonus, no
	// ability bonus, no modifiers of the skill's own, because the character has no skill of their
	// own here to carry them.
	//
	// Two limits the book puts on it are the caller's, not this function's: a restricted skill
	// cannot be attempted at all, and "any skill for which the character has rolled a starting
	// bonus can no longer be attempted as a common skill" -- once held, it is rolled as itself.
	getCommonSkillChance(tmpattr1, tmpattr2, tmprating) {
		var tmpcombined = this._getCombinedAttributes(tmpattr1, tmpattr2);
		return (tmpcombined - (parseInt(tmprating) || 0)) * 5;
	}

	// This is the function which produces the combined attribute value for a skill.
	// One governing attribute is used as it stands; two are averaged and rounded up.
	_getCombinedAttributes(tmpattr1, tmpattr2) {
		var tmpfirst = this.attributes[String(tmpattr1 || "").toLowerCase()];
		if (!tmpfirst) { return 0; }
		if (!tmpattr2) { return tmpfirst.value; }

		var tmpsecond = this.attributes[String(tmpattr2).toLowerCase()];
		if (!tmpsecond) { return tmpfirst.value; }

		return Math.ceil((tmpfirst.value + tmpsecond.value) / 2);
	}

	//==========================================================================================
	// @MARKER GENERAL PURPOSE FUNCTIONS
	//==========================================================================================

	// This is the function which converts an attribute rating into its save percentage.
	// Ported from getAttribSave in the original sheet-worker with the branch order intact.
	// Ratings 18 through 20 all save at 90%; only a rating above 20 exceeds it.
	//
	// Note this is the BASE save only. The separate cap that applies when a save is modified
	// at roll time -- bonuses cannot lift a save past 90%, and cannot raise it at all once the
	// attribute is 21 or better -- belongs with the roll logic, not here.
	static getAttribSave(tmpAttribRating) {
		var tmpSaveValue = 0;
		if (tmpAttribRating < 18) {
			tmpSaveValue = parseInt(tmpAttribRating * 5);
		} else if (tmpAttribRating > 20) {
			tmpSaveValue = parseInt(90 + (tmpAttribRating - 20));
		} else {
			tmpSaveValue = 90;
		}
		return tmpSaveValue;
	}

	// This is the function which turns the Intelligence table's language figures into his slot
	// labels, exactly as setLangSheet writes them into tmp_lang1_sw through tmp_lang10_sw.
	//
	// His switch is written out case by case, one per rating, but every case follows the same
	// rule, and the rule is stated here rather than the 31 cases copied, since the figures it
	// reads are already in ATTRIBUTE_TABLES.int. The derivation suite holds his labels for every
	// rating 0-30 and checks this function against all of them.
	//
	//     spoken  written   slots
	//     0       0         none at all -- his "None"
	//     below 1 0         one language, only partly spoken: "Speaks(quarter):"
	//     1+      any       spoken rounded up; the first floor(written) of them also write,
	//                       and a fractional written figure lands on the next slot
	//
	// A fraction below 1 is a degree of command of ONE language, not a share of a second one.
	// The Player's Guide: "1/3 indicates the character has only the most basic vocabulary, 2/3
	// indicates ... limited comprehension", and a full language adds grammar.
	static getLanguageSlotLabels(tmpSpoken, tmpWritten) {
		// his fractions, rounded to the two places the table carries them at
		var tmpFractionWords = { 0.25: "quarter", 0.33: "third", 0.66: "two-thirds" };
		var tmpFractionWord = function (tmpValue) {
			return tmpFractionWords[Math.round(tmpValue * 100) / 100] || "";
		};

		var tmpLabels = [];
		if (tmpSpoken <= 0) { return tmpLabels; }
		if (tmpSpoken < 1) {
			tmpLabels.push("Speaks(" + tmpFractionWord(tmpSpoken) + "):");
			return tmpLabels;
		}

		var tmpSlots        = Math.ceil(tmpSpoken);
		var tmpFullWritten  = Math.floor(tmpWritten);
		var tmpPartWritten  = tmpWritten - tmpFullWritten;
		for (let tmpSlot = 0; tmpSlot < tmpSlots; tmpSlot++) {
			if (tmpSlot < tmpFullWritten) {
				tmpLabels.push("Speaks/writes:");
			} else if (tmpSlot == tmpFullWritten && tmpPartWritten > 0) {
				tmpLabels.push("Speaks/" + tmpFractionWord(tmpPartWritten) + " writes:");
			} else {
				tmpLabels.push("Speaks:");
			}
		}
		return tmpLabels;
	}

	// This is the function which decides which of his slots each recorded language sits in, so
	// every row can show the slot it is actually using and whether it is past the allowance.
	//
	// His sheet had no need of this: its slots were fixed rows with the label printed beside
	// each, and the player typed a name into one. Here a language is a row with its own speak
	// and write boxes, in whatever order they were added, so the slots are handed out by USE
	// rather than by position. Otherwise a written language added second would sit beside a
	// "Speaks:" label while an unwritten one sat on "Speaks/writes:".
	//
	// The Player's Guide sets the order: "A character can use a written slot for a spoken slot,
	// but not vice versa." So written languages take the writing slots first, the rest take the
	// speaking slots, and a speaking language may overflow into a writing slot nobody wrote in.
	// A written language with no writing slot left still speaks, in a speaking slot if one is
	// free -- it is over on writing only.
	//
	// Returns one entry per language, in the order given: { slotLabel, overSpoken, overWritten }.
	static assignLanguageSlots(tmpLanguages, tmpLabels) {
		var tmpWriteSlots = tmpLabels.filter(tmpLabel => tmpLabel.includes("writes"));
		var tmpSpeakSlots = tmpLabels.filter(tmpLabel => !tmpLabel.includes("writes"));
		var tmpRows = tmpLanguages.map(() => ({ slotLabel: "", overSpoken: false, overWritten: false }));

		// pass 1 -- written languages into the writing slots
		tmpLanguages.forEach((tmpLang, tmpIndex) => {
			if (tmpLang.write && tmpWriteSlots.length > 0) { tmpRows[tmpIndex].slotLabel = tmpWriteSlots.shift(); }
		});
		// pass 2 -- everything still unplaced into a speaking slot, then any writing slot left
		tmpLanguages.forEach((tmpLang, tmpIndex) => {
			if (tmpRows[tmpIndex].slotLabel != "") { return; }
			if (tmpLang.write) { tmpRows[tmpIndex].overWritten = true; }
			if (tmpSpeakSlots.length > 0)      { tmpRows[tmpIndex].slotLabel = tmpSpeakSlots.shift(); }
			else if (!tmpLang.write && tmpWriteSlots.length > 0) { tmpRows[tmpIndex].slotLabel = tmpWriteSlots.shift(); }
			else                               { tmpRows[tmpIndex].overSpoken = true; }
		});
		return tmpRows;
	}

	// This is the function which returns the highest rating an attribute may reach.
	//
	// This is the ORDINARY maximum -- how far stat-up rolls can take an attribute. The magical
	// maximum is a separate, higher ceiling; see getMagicalAttributeMax below.
	//
	// Ported from his sheet, which does this in two places: the race's limits become the
	// maximums when a race is chosen (sheet-worker.js:8099), and setArchMortalAttributesMax
	// (line 27549) replaces all twelve on titling to 11 -- discarding the racial limits, upwards
	// or downwards. Twenty is the standing default before a race is picked
	// (clearAttributeModifiersFinals, line 32502).
	//
	// That function writes 27, but his comment at its call site says 25, and he settled it on
	// 2026-09-16: 25 is the ordinary cap and 27 the magical one (UPSTREAM-ISSUES.md item 16).
	// So this returns 25, and the 27 lives in getMagicalAttributeMax.
	//
	// His code fires the arch-mortal replacement once, at exactly title 11, and the value then
	// persists; a derived model recomputes every time, so the test is "title 11 or more", which
	// reproduces the same resulting state.
	static getAttributeMax(tmpTitle, tmpRaceLimit) {
		var tmpTitleValue = parseInt(tmpTitle) || 0;
		if (tmpTitleValue >= 11) { return 25; }   // arch-mortal: racial limits are discarded
		var tmpLimit = parseInt(tmpRaceLimit) || 0;
		if (tmpLimit <= 0) { tmpLimit = 20; }     // no race chosen yet
		return tmpLimit;
	}

	// This is the function which gives how high an attribute may be raised BY MAGIC, which is a
	// different and higher ceiling from the one above.
	//
	// He settled this on 2026-09-16, answering what looked like a contradiction between a comment
	// saying 25 and a function setting 27 (docs/UPSTREAM-ISSUES.md item 16): *"25 for normal
	// statistic upgrades, 27 for magical upgrades. So you can raise it to 25 with stat up rolls,
	// and 27 is the cap when using magical boosts."* Both numbers were right; they are two caps.
	//
	// The tiers are his own, from setMagicalAttributeMaximums (sheet-worker.js:123007), and they
	// are the Master's Manual's four ranges exactly:
	//
	//     title 0        mundane      23
	//     titles 1-10    mortal       25
	//     titles 11-15   arch-mortal  27
	//
	// His function stops there and writes nothing above title 15, so nothing is invented for a
	// deity range: title 16 and up hold the arch-mortal 27 until he says otherwise.
	static getMagicalAttributeMax(tmpTitle) {
		var tmpTitleValue = parseInt(tmpTitle) || 0;
		if (tmpTitleValue < 1) { return 23; }
		if (tmpTitleValue < 11) { return 25; }
		return 27;
	}

	// @MARKER ADD NEW character data model functions HERE
}
// @END (CODE)
