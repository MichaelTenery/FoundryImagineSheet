// @START (CODE)
// @MARKER ARMOUR ITEM DATA MODEL
//==================================================================================================================
// Schema for armour, clothing and shields.
//
// Fields map onto the 22 columns of armorvalueslist in the original sheet-worker: material,
// flexibility class, an armour value for each of nineteen body locations, and weight.
//
// All three kinds share one item type because the layering engine has to walk them together.
// Flexibility is what separates them mechanically, and the source data treats Clothing as a
// flexibility class of its own alongside Flexible, Semi-Flexible and Rigid.
//
// The layering rules (Player's Guide, Layering Armor):
//   - up to three layers of armour; the first worn must be flexible
//   - each layer may only sit over material at least as flexible as itself
//   - rigid may never stack on rigid
//   - shields are a fourth layer, and some other objects also qualify
//   - clothing of 3 armour value or less does not consume a layer at all, and grants one
//     free layer above or below armour
//==================================================================================================================

const fields = foundry.data.fields;

	// This is the function which builds the armour value for one body location.
	function coverageField() {
		return new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 });
	}


export default class ImagineArmorData extends foundry.abstract.TypeDataModel {

	static defineSchema() {
		return {

			// @MARKER CONSTRUCTION
			// flexibility drives the whole layering engine -- see the rules quoted above.
			material:    new fields.StringField({ required: true, initial: "" }),

			// Some pieces are composite, built from two materials of different flexibility --
			// a helm with a rigid shell over a flexible lining, for instance. The source
			// records these as "Rigid/Flexible", "Rigid/Semi-Flexible", "Rigid/Rigid" or
			// "Mixed".
			//
			// This is the data encoding of a real rule: "Some pieces of armor come with their
			// own padding or flexible layer built in, such as skull caps and some gauntlets.
			// In these cases, it is acceptable to use one layer of rigid armor against the
			// body." A composite piece with a flexible inner face may therefore sit in the
			// first layer, which a plain rigid piece may not.
			//
			// "Rigid/Rigid" looks contradictory against the no-rigid-on-rigid rule, but the
			// rules allow it: "A few suits allow two sections of rigid armor because they do
			// not touch."
			flexibility: new fields.StringField({ required: true, initial: "Flexible",
			                 choices: ["Clothing", "Flexible", "Semi-Flexible", "Rigid",
			                           "Rigid/Flexible", "Rigid/Semi-Flexible", "Rigid/Rigid",
			                           "Mixed"] }),

			// Shields are worn over armour and are used actively with the Shield Parry skill, so
			// they are flagged rather than being their own item type. Which areas a shield covers
			// depends on its size, the body it is strapped to and which hand holds it -- see
			// SHIELD_COVERAGE and getAreaShield in the combat rules.
			isShield: new fields.BooleanField({ required: true, initial: false }),

			// A Buckler is the one shield worn two ways: strapped to the forearm, or held in the
			// hand. His sheet asks once, as equip_buckler_on_wrist; here it sits on the buckler
			// itself, because a Foundry actor can own more than one and the choice belongs to the
			// shield rather than to the character. Ignored on every other size.
			bucklerOnWrist: new fields.BooleanField({ required: true, initial: false }),

			// @MARKER MAGIC
			// A magical piece is written "+N" in its name in his data, and getItemPlusInt reads
			// the number back out. It is stored as a field here instead, so nothing has to parse
			// a name to find it. On a shield his rule is to add the plus and then double the
			// whole value -- a +2 shield of 10 is worth 24.
			magicBonus: new fields.NumberField({ required: true, integer: true, initial: 0 }),

			// @MARKER COVERAGE
			// Armour value at each body location. Zero means this piece does not cover it.
			// These nineteen locations (and the tail) are the humanoid mapping; a non-humanoid body has its
			// own chart and its own armour.
			coverage: new fields.SchemaField({
				head:          coverageField(),
				neck:          coverageField(),
				shoulderLeft:  coverageField(),
				shoulderRight: coverageField(),
				torsoUpper:    coverageField(),
				torsoMid:      coverageField(),
				torsoLower:    coverageField(),
				armLeft:       coverageField(),
				armRight:      coverageField(),
				forearmLeft:   coverageField(),
				forearmRight:  coverageField(),
				handLeft:      coverageField(),
				handRight:     coverageField(),
				thighLeft:     coverageField(),
				thighRight:    coverageField(),
				shinLeft:      coverageField(),
				shinRight:     coverageField(),
				footLeft:      coverageField(),
				footRight:     coverageField(),
				// A Saurian type's tail (bug report 0.22:3, 2026-10-04): the "Tail Covering" pieces. Not
				// one of his nineteen columns -- it was "a planned addition to the Roll20 sheet" -- so
				// it is the port's twentieth, worn only by a body whose chart has a Tail the Saurian
				// family maps (combat-tables.mjs), and by no other (equip-rules canBodyWearArmor).
				tail:          coverageField()
			}),

			// Locations whose armour value is not fixed on the piece but derived from the
			// material it is made of -- the source writes "S" there rather than a number.
			// Giant-material armour (chitin, scales, hide) works this way, resolved in the
			// original sheet by getArmorGiantArmorValue.
			//
			// The location names are kept rather than being flattened to zero, because a zero
			// would assert the piece offers no protection there, which is false. Resolving
			// these needs the giant-material rules, which are not implemented yet.
			coverageFromMaterial: new fields.ArrayField(new fields.StringField(), { initial: [] }),

			// @MARKER PENALTIES
			// Worn armour costs the wearer skill, defence, initiative and speed. Values come
			// from armorpenaltydict in the original sheet and are negative.
			penalties: new fields.SchemaField({
				skills:     new fields.NumberField({ required: true, integer: true, initial: 0 }),
				defense:    new fields.NumberField({ required: true, integer: true, initial: 0 }),
				initiative: new fields.NumberField({ required: true, integer: true, initial: 0 }),
				speed:      new fields.NumberField({ required: true, integer: true, initial: 0 })
			}),

			// @MARKER WEAR AND CONDITION
			// Layers rub against each other and wear out; the rules suggest a point of armour
			// damage per layer per week when worn layered.
			armorDamage: new fields.NumberField({ required: true, integer: true, initial: 0, min: 0 }),

			// @MARKER WORN STATE
			// layer is which of the three armour layers this piece occupies, innermost first.
			// Shields and other fourth-layer objects use 4. Clothing of 3 armour value or less
			// does not consume a layer, so it sits at 0.
			layer:    new fields.NumberField({ required: true, integer: true, initial: 1, min: 0, max: 4 }),
			location: new fields.StringField({ required: true, initial: "carried",
			              choices: ["equipped", "carried", "mount", "stash"] }),
			quantity: new fields.NumberField({ required: true, integer: true, initial: 1, min: 0 }),

			// His getItemWeight (sheet-worker.js:81979-81990) reads a bracketed quality tag out
			// of the item's NAME and scales its WEIGHT by it: [Shoddy] x1.75, [Poor] x1.1,
			// [Good] x.9, [High] x.8, [Master] x.75. Blank means average, which is x1. Stored
			// here as a field rather than parsed from the name, the same tidying the [Float]
			// marker got. A magical plus replaces this multiplier rather than stacking with it --
			// see resolveEncumbrance in combat-rules.mjs.
			quality: new fields.StringField({ required: true, blank: true, initial: "",
			             choices: ["", "Shoddy", "Poor", "Good", "High", "Master"] }),
			weight:   new fields.NumberField({ required: true, initial: 0 }),
			// Weighs nothing to carry: his "[Float]" marker, which his own sheet reads out of the
			// item's NAME (sheet-worker.js:81815). The name is still honoured -- see itemFloats in
			// combat-rules.mjs -- and this is the tidier way to say it on a sheet with real fields.
			floats: new fields.BooleanField({ required: true, initial: false, label: "Floats (no carried weight)" }),

			// @MARKER PROVENANCE
			cost:        new fields.StringField({ required: true, initial: "" }),
			sourcebook:  new fields.StringField({ required: true, initial: "" }),
			page:        new fields.StringField({ required: true, initial: "" }),
			description: new fields.HTMLField({ required: true, initial: "" })
		};
	}

	// @MARKER ADD NEW armour data model functions HERE

	// This is the function which reports whether this piece consumes one of the three armour
	// layers. Light clothing does not: anything of 3 armour value or less is worn without
	// interfering, and allows one free layer above or below the armour proper.
	consumesLayer() {
		if (this.isShield) { return true; }        // a shield is a layer of its own
		if (this.flexibility != "Clothing") { return true; }
		return this.getHighestCoverage() > 3;
	}

	// This is the function which returns the highest armour value this piece offers at any
	// single location, which is what the clothing exemption is measured against.
	getHighestCoverage() {
		var tmphighest = 0;
		for (const tmpkey of Object.keys(this.coverage)) {
			if (this.coverage[tmpkey] > tmphighest) { tmphighest = this.coverage[tmpkey]; }
		}
		return tmphighest;
	}
}
// @END (CODE)
