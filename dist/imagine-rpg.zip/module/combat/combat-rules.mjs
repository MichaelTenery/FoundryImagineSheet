// @START (CODE)
// @MARKER COMBAT RULES
//==================================================================================================================
// The combat arithmetic, as plain functions.
//
// Nothing in this file touches Foundry. Every function takes values and returns values -- dice
// results included, which are rolled by the caller and passed in. That keeps the rules
// testable on their own, and it keeps them readable against the original sheet-worker, which
// is where each one is ported from (line numbers given with each function).
//
// Where his code and the Player's Guide disagree, his code wins, per the standing rule. Where
// his code has a plain bug that defeats its own evident intent, the intent is implemented and
// the bug is recorded in docs/UPSTREAM-ISSUES.md for him to confirm.
//==================================================================================================================

import { getGravityRune } from "../weapon-custom-rules.mjs";
import {
	ATTACK_CHARTS, ATTACK_SKILL_ORDER, BODY_CHARTS, BLOCKING_TYPE_OF,
	ARMOR_BLOCKING, ARMOR_DAMAGE_DIVIDERS, ARMOR_MATERIAL_RANK,
	ARMOR_COVERAGE_BY_BODY_TYPE, ARMOR_REQUIRES_ITEM,
	SHIELD_COVERAGE, SHIELD_SIZES,
	ENDURED_BY, REBOUNDED_TYPES,
	PROJECTILE_MATCHES, LAUNCHER_MATCHES, LAUNCHER_PROJECTILE,
	OFFHAND_PENALTIES, MOVEMENT_BASE
} from "../combat-tables.mjs";

// The zones an attack can land in, in the order his code tests them.
export const HIT_ZONES = ["Hit(Center)", "Hit(Right)", "Hit(High)", "Hit(Left)", "Hit(Low)"];
export const MISS_ZONES = ["Miss(Right)", "Miss(High)", "Miss(Left)", "Miss(Low)", "Miss(Short)"];

// Which attack modes are melee. Missile is the only other.
export const MELEE_MODES = ["thrust", "cut", "smash"];

// Which armour coverage slot protects each body chart area, for a humanoid shape. Armour data
// gives a value for each of nineteen locations (armorvalueslist); these are the chart names they
// line up with.
//
// This is the Humanoid case only. The per-body-type mapping now lives in
// ARMOR_COVERAGE_BY_BODY_TYPE (module/combat-tables.mjs, generated from his own branches) and is
// reached through getAreaArmorSlot below, which is what the actor models use. This table is kept
// because it is the shape most content is authored against and it reads clearly.
export const ARMOR_COVERAGE_BY_AREA = {
	"Head":           "head",
	"Neck":           "neck",
	"Left Shoulder":  "shoulderLeft",
	"Right Shoulder": "shoulderRight",
	"Upper Torso":    "torsoUpper",
	"Mid Torso":      "torsoMid",
	"Lower Torso":    "torsoLower",
	"Left Arm":       "armLeft",
	"Right Arm":      "armRight",
	"Left Forearm":   "forearmLeft",
	"Right Forearm":  "forearmRight",
	"Left Hand":      "handLeft",
	"Right Hand":     "handRight",
	"Left Thigh":     "thighLeft",
	"Right Thigh":    "thighRight",
	"Left Shin":      "shinLeft",
	"Right Shin":     "shinRight",
	"Left Foot":      "footLeft",
	"Right Foot":     "footRight"
};

// The damage type each attack mode deals by default. The attacker can change it when damage is
// applied -- a club thrust is still Smashing, for instance.
export const MODE_DAMAGE_TYPES = {
	thrust:  "Thrusting",
	cut:     "Cutting",
	smash:   "Smashing",
	missile: "Piercing"
};


//==================================================================================================================
// @MARKER ATTACK SKILL
//==================================================================================================================

	// This is the function which reads an attack chart into named thresholds.
	//
	// Each chart value is the LOWEST roll that reaches that result. "19+" and "9-11" are read by
	// their first number, exactly as his code does it with parseInt. "-" means the result cannot
	// happen at that skill, and becomes NaN -- which fails every comparison, again as in his code.
	export function getAttackChart(tmpskill) {
		var tmprow = ATTACK_CHARTS[tmpskill] ?? ATTACK_CHARTS["None"];
		return {
			skill:      ATTACK_CHARTS[tmpskill] ? tmpskill : "None",
			missHigh:   parseInt(tmprow[0]),
			hitHigh:    parseInt(tmprow[1]),
			missLeft:   parseInt(tmprow[2]),
			hitLeft:    parseInt(tmprow[3]),
			hitCenter:  parseInt(tmprow[4]),
			hitRight:   parseInt(tmprow[5]),
			missRight:  parseInt(tmprow[6]),
			hitLow:     parseInt(tmprow[7]),
			missLow:    parseInt(tmprow[8]),
			missShort:  parseInt(tmprow[9]),
			calledShot: parseInt(tmprow[10])
		};
	}

	// This is the function which works out a character's attack skill from their class's
	// progression and their current title.
	//
	// A class lists its progression as text, e.g.
	//     "Beginner at 1, Novice at 3, Intermediate at 5, Advanced at 7, Expert at 9, Master at 12"
	// and occasionally with a note in brackets: "Grandmaster(mastered weapons at 9)".
	// His code splits on " at " (setAttackChartsChanges, sheet-worker.js:94835). The level held is
	// the last one whose title has been reached. Before the first listed title, the first level
	// is used: a character can always swing, however badly.
	export function getAttackSkillForTitle(tmplist, tmptitle) {
		var tmptext = String(tmplist ?? "").trim();
		if (tmptext == "" || tmptext == "None") { return "None"; }

		var tmpparts = tmptext.replaceAll(" at ", ",").split(",");
		var tmplevels = [];
		for (var i = 0; i < tmpparts.length - 1; i = i + 2) {
			var tmpname = tmpparts[i].trim().split("(")[0].trim();   // "Grandmaster(mastered weapons" -> "Grandmaster"
			var tmpat = parseInt(tmpparts[i + 1]) || 0;
			if (ATTACK_CHARTS[tmpname]) { tmplevels.push({ name: tmpname, at: tmpat }); }
		}
		if (!tmplevels.length) { return "None"; }

		var tmpheld = tmplevels[0].name;
		for (const tmplevel of tmplevels) {
			if ((parseInt(tmptitle) || 0) >= tmplevel.at) { tmpheld = tmplevel.name; }
		}

		// The standard chart stops at Master. A class listing "Grandmaster(mastered weapons at 9)"
		// means Grandmaster only with weapons the character has mastered -- that is the Weapon Lore
		// chart, one step up -- so for everything else it is Master. His code says exactly this:
		// "cannot set Grandmaster for standard Attack Chart so just use Master"
		// (setAttackChartsChanges, sheet-worker.js:94848).
		if (tmpheld == "Grandmaster") { tmpheld = "Master"; }
		return tmpheld;
	}

	// This is the function which returns the attack skill one step above the one given. Weapon
	// Lore and Missile Lore read the chart one level up (getNextAttackSkill in his code).
	export function getNextAttackSkill(tmpskill) {
		var tmpindex = ATTACK_SKILL_ORDER.indexOf(tmpskill);
		if (tmpindex < 0) { return tmpskill; }
		return ATTACK_SKILL_ORDER[Math.min(tmpindex + 1, ATTACK_SKILL_ORDER.length - 1)];
	}

	// This is the function which picks the better of two attack charts.
	//
	// Player's Guide, "Dual Class Characters", Experience and Advancement rule 5: "Attack skill is
	// determined by the greater of the two values" -- a Mage/Warrior fights at the Warrior's chart.
	// Better means further along ATTACK_SKILL_ORDER, not a larger number, since these are names.
	//
	// Anything not on the chart order (including "None") loses to anything that is, and two
	// unknowns come back as the first argument, so a classless character reads as "None" rather
	// than as an error.
	export function getBetterAttackSkill(tmpfirst, tmpsecond) {
		var tmpfirstat = ATTACK_SKILL_ORDER.indexOf(tmpfirst);
		var tmpsecondat = ATTACK_SKILL_ORDER.indexOf(tmpsecond);
		if (tmpsecondat < 0) { return tmpfirst; }
		if (tmpfirstat < 0) { return tmpsecond; }
		return (tmpsecondat > tmpfirstat) ? tmpsecond : tmpfirst;
	}


//==================================================================================================================
// @MARKER ATTACK RESOLUTION
//==================================================================================================================

	// This is the function which resolves an attack roll: whether it hits, and where.
	// Ported from handlePhysicalAttacks (sheet-worker.js:64802-64893), both branches: the ordinary
	// chart, and the Weapon Lore chart his code reads whenever the weapon is lored (modWL/modML != 0,
	// 64872-64895). The caller picks the chart -- the character's loreAttackSkill, one step better,
	// when the lore applies -- and says so with isLore, because the Lore branch has one rule of its
	// own: a Grandmaster's natural 1 is a MISS, not a fumble ("A one is always a miss (but not a
	// fumble if Grandmaster)", 64890). Until the quality pass of 2026-10-07 no caller ever passed
	// the Lore chart, so a lored weapon fought one chart too low.
	//
	//   tmproll = {
	//       natural:       the d20 as rolled
	//       mods:          the total of every modifier
	//       skill:         attack skill, e.g. "Novice" -- the Lore chart's name when isLore
	//       isLore:        true when the weapon is lored and this is the Lore chart
	//       calledShot:    true if the attacker declared a called shot
	//       calledShotMod: anything that makes a called shot easier (default 0)
	//       fumbleMod:     anything that widens the fumble range (default 0)
	//   }
	//
	// Three details that are easy to get wrong, all as his code does them:
	//   - The zone is read from the MODIFIED result, floored at 1.
	//   - A called shot is judged on the NATURAL roll, never the modified one.
	//   - A natural 1 (or up to 1 + fumbleMod) is a fumble whatever the modifiers -- except a
	//     Grandmaster on the Lore chart, for whom a natural 1 is a plain miss.
	export function resolveAttack(tmproll) {
		var tmpchart = getAttackChart(tmproll.skill);
		var tmpnatural = parseInt(tmproll.natural) || 0;
		var tmpfinal = tmpnatural + (parseInt(tmproll.mods) || 0);
		if (tmpfinal < 1) { tmpfinal = 1; }

		var tmpzone = "Miss";
		if      (tmpfinal >= tmpchart.hitCenter) { tmpzone = "Hit(Center)"; }
		else if (tmpfinal >= tmpchart.hitRight)  { tmpzone = "Hit(Right)"; }
		else if (tmpfinal >= tmpchart.hitHigh)   { tmpzone = "Hit(High)"; }
		else if (tmpfinal >= tmpchart.hitLeft)   { tmpzone = "Hit(Left)"; }
		else if (tmpfinal >= tmpchart.hitLow)    { tmpzone = "Hit(Low)"; }
		else if (tmpfinal >= tmpchart.missRight) { tmpzone = "Miss(Right)"; }
		else if (tmpfinal >= tmpchart.missHigh)  { tmpzone = "Miss(High)"; }
		else if (tmpfinal >= tmpchart.missLeft)  { tmpzone = "Miss(Left)"; }
		else if (tmpfinal >= tmpchart.missLow)   { tmpzone = "Miss(Low)"; }
		else if (tmpfinal >= tmpchart.missShort && tmpchart.skill == "Beginner") { tmpzone = "Miss(Short)"; }

		var tmpcalled = false;
		if (tmproll.calledShot) {
			tmpcalled = tmpnatural >= (tmpchart.calledShot - (parseInt(tmproll.calledShotMod) || 0));
		}

		var tmpfumble = false;
		if (tmproll.isLore && tmpchart.skill == "Grandmaster") {
			// His Lore branch for a Grandmaster: a natural 1 misses and nothing more.
			if (tmpnatural == 1) {
				tmpfinal = 1;
				tmpzone = "Miss(Natural 1)";
				tmpcalled = false;
			}
		} else if (tmpnatural <= (1 + (parseInt(tmproll.fumbleMod) || 0))) {
			tmpfumble = true;
			tmpfinal = 1;
			tmpzone = "Fumble";
			tmpcalled = false;
		}

		return {
			natural: tmpnatural,
			final: tmpfinal,
			skill: tmpchart.skill,
			isLore: !!tmproll.isLore,
			zone: tmpzone,
			isHit: tmpzone.startsWith("Hit"),
			isFumble: tmpfumble,
			calledShotDeclared: !!tmproll.calledShot,
			isCalledShot: tmpcalled
		};
	}

	// The eight compass points a dropped weapon flies off in. From getRandomDirection
	// (sheet-worker.js:26444), a d8.
	export const FUMBLE_DIRECTIONS = ["North", "Northeast", "East", "Southeast",
	                                  "South", "Southwest", "West", "Northwest"];

	// This is the function which reads his critical fumble table. Ported from getCriticalFumble
	// (sheet-worker.js:26460).
	//
	// A melee critical is a d100 down nine ten-point bands -- hitting a solid object, hitting
	// another target in range, or hitting yourself, each at half, full and double damage -- then
	// tripping, tripping with damage, and at 99 and 100 losing the weapon as well. Those last two
	// bands roll again: under 20 the damage lands normally, otherwise it bypasses armour. A
	// missile critical is always the same, the weapon breaking.
	//
	// The dice arrive as arguments, as everywhere else in this file:
	//   tmpdice = {
	//       criticalRoll:  d100, which band of the table
	//       variantRoll:   d100, the armour-bypassing split on the 99 and 100 bands
	//       standRoll:     d6, seconds to get up (1d6+1)
	//       throwRoll:     d20, feet the weapon is thrown
	//       directionRoll: d8, which way it goes
	//       stunRoll:      d3, seconds stunned on the 100 band
	//   }
	//
	// Returns the consequence as data as well as prose, so the damage a fumble causes can be
	// applied rather than only read: target is what gets hit ("object", "other", "self" or ""),
	// damageMultiplier is his half/full/double, and bypassesArmor marks the worst two results.
	export function resolveCriticalFumble(tmpismissile, tmpdice) {
		if (tmpismissile) {
			return { target: "", damageMultiplier: 0, bypassesArmor: false, secondsLost: 0,
			         weaponLost: false, weaponBroken: true,
			         text: "the weapon breaks and is unusable until repaired" };
		}

		var tmproll = parseInt(tmpdice.criticalRoll) || 0;
		var tmpstand = (parseInt(tmpdice.standRoll) || 0) + 1;
		var tmpthrown = parseInt(tmpdice.throwRoll) || 0;
		var tmpdirection = FUMBLE_DIRECTIONS[((parseInt(tmpdice.directionRoll) || 1) - 1) % 8];

		// The nine damage bands, in his order: three targets at half, full and double.
		const tmpbands = [
			{ upTo: 10, target: "object", multiplier: 0.5, what: "Hits a solid object" },
			{ upTo: 20, target: "object", multiplier: 1.0, what: "Hits a solid object" },
			{ upTo: 30, target: "object", multiplier: 2.0, what: "Hits a solid object" },
			{ upTo: 40, target: "other",  multiplier: 0.5, what: "Hits another target in range" },
			{ upTo: 50, target: "other",  multiplier: 1.0, what: "Hits another target in range" },
			{ upTo: 60, target: "other",  multiplier: 2.0, what: "Hits another target in range" },
			{ upTo: 70, target: "self",   multiplier: 0.5, what: "Hits self" },
			{ upTo: 80, target: "self",   multiplier: 1.0, what: "Hits self" },
			{ upTo: 90, target: "self",   multiplier: 2.0, what: "Hits self" }
		];
		for (const tmpband of tmpbands) {
			if (tmproll <= tmpband.upTo) {
				var tmpwhere = (tmpband.target == "object") ? "the weapon and the object"
				             : (tmpband.target == "other") ? "a random area on that target"
				             : "a random area";
				return { target: tmpband.target, damageMultiplier: tmpband.multiplier,
				         bypassesArmor: false, secondsLost: 0, weaponLost: false, weaponBroken: false,
				         text: `${tmpband.what}: ${describeMultiplier(tmpband.multiplier)} damage to ${tmpwhere}` };
			}
		}

		if (tmproll <= 94) {
			return { target: "", damageMultiplier: 0, bypassesArmor: false, secondsLost: tmpstand,
			         weaponLost: false, weaponBroken: false,
			         text: `Trips on the weapon: falls, losing ${tmpstand} seconds to stand` };
		}
		if (tmproll <= 98) {
			return { target: "self", damageMultiplier: 1.0, bypassesArmor: false, secondsLost: tmpstand,
			         weaponLost: false, weaponBroken: false,
			         text: `Trips on the weapon, damaging self: full damage to a random area, and falls, `
			             + `losing ${tmpstand} seconds to stand` };
		}

		// The last two bands roll again: under 20 the damage lands normally, otherwise it goes
		// straight through armour.
		var tmpbypass = !((parseInt(tmpdice.variantRoll) || 0) < 20);
		var tmpthrough = tmpbypass ? " bypassing armour" : "";
		if (tmproll <= 99) {
			return { target: "self", damageMultiplier: 1.0, bypassesArmor: tmpbypass,
			         secondsLost: tmpstand, weaponLost: true, weaponBroken: false,
			         direction: tmpdirection, thrownFeet: tmpthrown,
			         text: `Trips on the weapon, damaging self and losing it: full damage${tmpthrough} to a `
			             + `random area, falls losing ${tmpstand} seconds to stand, and the weapon is thrown `
			             + `${tmpthrown} feet ${tmpdirection}` };
		}

		var tmpstun = parseInt(tmpdice.stunRoll) || 0;
		return { target: "self", damageMultiplier: 2.0, bypassesArmor: tmpbypass,
		         secondsLost: tmpstun + tmpstand, weaponLost: true, weaponBroken: false,
		         direction: tmpdirection, thrownFeet: tmpthrown,
		         text: `Trips on the weapon, damaging self and losing it: double damage${tmpthrough} to a `
		             + `random area, falls stunned for ${tmpstun} seconds then loses ${tmpstand} more to `
		             + `stand, and the weapon is thrown ${tmpthrown} feet ${tmpdirection}` };
	}

	// This is the function which names a damage multiplier the way his table reads.
	function describeMultiplier(tmpmultiplier) {
		if (tmpmultiplier == 0.5) { return "half"; }
		if (tmpmultiplier == 2.0) { return "double"; }
		return "full";
	}

	// This is the function which works out what a fumble costs. Ported from
	// handlePhysicalAttacks (sheet-worker.js:64894-64912), with the critical branch reading his
	// table through resolveCriticalFumble.
	//
	// The dice arrive as arguments rather than being rolled here:
	//   tmpdice = {
	//       saveRoll:     d100 against the attacker's Agility save
	//       recoveryRoll: d4, for the seconds lost on a successful save (1d4+1)
	//       severityRoll: d100; 80 or under is an ordinary fumble, above is critical
	//       effectRoll:   d6 for a missile jam (1d6+1 seconds), d20 for melee (feet thrown)
	//   }
	// plus, for a critical, the dice resolveCriticalFumble documents. A caller that does not
	// supply them still gets a sound result -- the table simply reads as its first band.
	export function resolveFumble(tmpaglsave, tmpismissile, tmpdice) {
		if (tmpdice.saveRoll <= tmpaglsave) {
			return { saved: true, critical: false,
			         secondsLost: tmpdice.recoveryRoll + 1,
			         text: `Agility save made: recovers, losing ${tmpdice.recoveryRoll + 1} seconds.` };
		}
		if (tmpdice.severityRoll <= 80) {
			if (tmpismissile) {
				return { saved: false, critical: false, secondsLost: tmpdice.effectRoll + 1,
				         text: `Agility save failed: the weapon jams for ${tmpdice.effectRoll + 1} seconds.` };
			}
			return { saved: false, critical: false, secondsLost: 0,
			         text: `Agility save failed: the weapon is thrown ${tmpdice.effectRoll} feet in a random direction.` };
		}

		var tmpcritical = resolveCriticalFumble(tmpismissile, tmpdice);
		return {
			saved: false, critical: true,
			secondsLost: tmpcritical.secondsLost,
			target: tmpcritical.target,
			damageMultiplier: tmpcritical.damageMultiplier,
			bypassesArmor: tmpcritical.bypassesArmor,
			weaponLost: tmpcritical.weaponLost,
			weaponBroken: tmpcritical.weaponBroken,
			// Where a lost weapon went, as fields, so a marker can be dropped on the map
			// (dropWeaponMarker, attack.mjs) -- the words above already said it.
			direction: tmpcritical.direction ?? "",
			thrownFeet: tmpcritical.thrownFeet ?? 0,
			text: `Agility save failed: CRITICAL fumble -- ${tmpcritical.text}.`
		};
	}


//==================================================================================================================
// @MARKER TO HIT
//==================================================================================================================

	// This is the function which gathers every modifier to an attack roll, each with the label
	// his sheet would print beside it.
	//
	//   tmpinput = {
	//       mode:        "thrust" | "cut" | "smash" | "missile"
	//       weapon:      the weapon's system data
	//       attacker:    { meleeAttack, missileAttack, meleeMisc, missileMisc }
	//       target:      { defensiveAdjust } or null when there is no target
	//       situational: a free modifier from the attack dialog
	//   }
	//
	// The target's defensive adjustment is not in his code -- his sheet only ever knew about one
	// character. It is in the Player's Guide ("a negative number applied to the attacker's
	// roll"), and in Foundry the target is known, so it is applied when a target is selected.
	export function getToHitModifiers(tmpinput) {
		var tmpweapon = tmpinput.weapon;
		var tmpmode = tmpinput.mode;
		var tmpattacker = tmpinput.attacker;
		var tmplist = [];

		var tmpmodeMod = parseInt(tmpweapon[tmpmode]?.mod) || 0;
		if (tmpmodeMod) { tmplist.push({ label: "Attack Type", value: tmpmodeMod }); }

		var tmpmagic = parseInt(tmpweapon.magicBonus) || 0;
		if (tmpmagic) { tmplist.push({ label: "Magic", value: tmpmagic }); }

		if (tmpmode == "missile") {
			var tmpagl = parseInt(tmpattacker.missileAttack) || 0;
			if (tmpagl) { tmplist.push({ label: "AGL", value: tmpagl }); }
			var tmpmissileMisc = parseInt(tmpattacker.missileMisc) || 0;
			if (tmpmissileMisc) { tmplist.push({ label: "Missile Other", value: tmpmissileMisc }); }
		} else {
			var tmpstr = parseInt(tmpattacker.meleeAttack) || 0;
			if (tmpstr) { tmplist.push({ label: "STR", value: tmpstr }); }
			var tmpmeleeMisc = parseInt(tmpattacker.meleeMisc) || 0;
			if (tmpmeleeMisc) { tmplist.push({ label: "Melee Other", value: tmpmeleeMisc }); }
		}

		if (tmpinput.target) {
			var tmpdef = parseInt(tmpinput.target.defensiveAdjust) || 0;
			if (tmpdef) { tmplist.push({ label: "Target Defence", value: tmpdef }); }
		}

		// Weapon or Missile Lore, worked out by getLoreModifiers and passed in, so this function
		// stays a plain sum. Melee reads Weapon Lore and missile reads Missile Lore.
		var tmplore = parseInt(tmpinput.lore) || 0;
		if (tmplore) { tmplist.push({ label: "Lore", value: tmplore }); }

		// The off-hand penalty, worked out by resolveOffhandPenalties and passed in for the same
		// reason lore is, so this function stays a plain sum.
		//
		// IT IS NOT MELEE-ONLY, despite his function being named getOffhandMeleeAdj. His
		// offHandPenalty appears in BOTH totalmods branches -- the missile one at
		// sheet-worker.js:64804 and the melee one at 64806 -- so a bow drawn in the wrong hand is
		// penalised exactly as a sword swung in it is. The name is the only thing that says melee.
		var tmpoffhand = parseInt(tmpinput.offhand) || 0;
		if (tmpoffhand) { tmplist.push({ label: "Off Hand", value: tmpoffhand }); }

		// Two hands give NO to-hit bonus. 0.22.1 listed "Two Hands +2" here on his bug report 0.22.5:2;
		// he retracted it on 2026-10-07 ("there is not in fact a bonus to hit when using 2 hands, only
		// damage"), which is what his sheet and the book's Rule of 2 said all along. The +2 is damage:
		// getTwoHandedDamageBonus.

		// Firing more than one missile at a time, already bought down by whichever of the two
		// multi-missile skills applies. Passed in for the same reason lore and the off hand are.
		var tmpmulti = parseInt(tmpinput.multiMissile) || 0;
		if (tmpmulti) { tmplist.push({ label: "Multiple Missiles", value: tmpmulti }); }

		// The situational modifiers set from the Situation Mods window, already worked out by
		// resolveSituationalMods and cut to this kind of attack by getSituationalForAttack. His
		// card prints these as "Situational(+N)", so they keep that label.
		var tmpsituation = parseInt(tmpinput.situation) || 0;
		if (tmpsituation) { tmplist.push({ label: "Situational", value: tmpsituation }); }

		// A number typed into the attack dialog for anything the window does not list -- his roll
		// prompt's ?{Modifier}.
		var tmpsit = parseInt(tmpinput.situational) || 0;
		if (tmpsit) { tmplist.push({ label: "Modifier", value: tmpsit }); }

		var tmptotal = tmplist.reduce((sum, m) => sum + m.value, 0);
		return { list: tmplist, total: tmptotal };
	}


//==================================================================================================================
// @MARKER SITUATIONAL MODIFIERS
//==================================================================================================================
// His "SITUATION MODS" bar on the combat page, and the two panels it opens: "Set melee modifiers"
// and "Set missile modifiers". A player ticks what applies -- flanking, a prone target, darkness,
// the target's size -- and SET totals them into five figures that every attack of that kind then
// reads until they are cleared: to hit, damage, a damage multiplier, the character's OWN defence,
// and a list of special effects (maximum damage, half damage, "Random Location" and the like).
//
// Every figure below is from his handleMeleeSet / handleMissileSet (sheet-worker.js:72874, 72990),
// NOT from the labels printed beside the checkboxes, which he wrote separately and which are only
// right where the two agree. Where they disagree it is recorded against the entry.
//
// A MULTIPLIER IS ADDED, NOT MULTIPLIED. Each "x2 Dam" adds one to a running multiplier that
// starts at 1, so a charge into a target against a wall is x3, not x4; diving adds two. His SET
// then caps it at x3 -- "x3 is the max damage" -- which is also the Player's Guide's limit.
//
// The multiple-missile checkboxes are in his missile panel, but their penalties are NOT counted
// here. The port already works those out, with the Knowledge and Lore that buy them back, in
// resolveMultiMissile -- which is where his own attack refunds them too (sheet-worker.js:64743).
// An option carries which mode it picks instead, and the attack hands that to resolveMultiMissile.
//
// Six options cannot simply be ticked. Critical, Focused Attack, Surprise Attack, Brace, Perfect
// Shot and Quick Load are each "set by a successful skill roll" -- his change handlers untick them
// if a player tries -- and a roll that succeeds critically or fails critically sets the matching
// Crit or Crit Fail option alongside. See getSituationalRollResult.

	// One row per option, keyed the way his checkbox names are (sit_position_rear -> positionRear).
	//
	//   group     options sharing an exclusive group are one-of: ticking one clears the rest
	//             (his change handlers, sheet-worker.js:17107-17850). Blank means it stands alone.
	//   attack    to hit, for this kind of attack
	//   damage    flat damage
	//   multi     added to the damage multiplier (x2 Dam is +1)
	//   defense   the character's own defensive adjustment -- added to anyone attacking THEM, so
	//             a positive figure is worse for them
	//   special   his special-effect words, read by the attack
	//   noDef     the character loses their defensive adjustment altogether ("No Defense")
	//   skill     set only by a roll of this skill; blank means the player ticks it
	//   roll      for a Crit / Crit Fail option: which skill's roll sets it, and on what result
	//
	// @MARKER SITUATIONAL MELEE
	//                   key                      label                         group         attack damage multi defense special                         noDef  skill / roll
	export const SITUATIONAL_MELEE = {
		calledShot:        { heading: "Called Shot",      label: "Called Shot",                 group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Called Shot"] },
		critical:          { heading: "Critical Skill",   label: "Critical (x2 Dam)",           group: "",            attack: 0,   damage: 0,  multi: 1, defense: 0,  special: [],                      skill: "Critical" },
		criticalCrit:      { heading: "Critical Skill",   label: "Crit (+1 Dam)",               group: "",            attack: 0,   damage: 1,  multi: 0, defense: 0,  special: [],                      roll: { skill: "Critical", on: "crit" } },
		criticalFail:      { heading: "Critical Skill",   label: "Crit Fail (No Defense)",      group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: [],             noDef: true, roll: { skill: "Critical", on: "fail" } },
		focusAttack:       { heading: "Focused Attack",   label: "Focused Attack (Max Dam)",    group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Max"],                 skill: "Focused Attack" },
		focusAttackCrit:   { heading: "Focused Attack",   label: "Crit (+1 Dam)",               group: "",            attack: 0,   damage: 1,  multi: 0, defense: 0,  special: [],                      roll: { skill: "Focused Attack", on: "crit" } },
		focusAttackFail:   { heading: "Focused Attack",   label: "Crit Fail (No Defense)",      group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: [],             noDef: true, roll: { skill: "Focused Attack", on: "fail" } },
		surpriseNormal:    { heading: "Surprise",         label: "Surprise",                    group: "",            attack: 4,   damage: 6,  multi: 0, defense: 0,  special: [] },
		surpriseAttack:    { heading: "Surprise",         label: "Surprise Attack (x2 Dam)",    group: "",            attack: 0,   damage: 0,  multi: 1, defense: 0,  special: [],                      skill: "Surprise Attack" },
		positionSide:      { heading: "Position",         label: "Side",                        group: "flank",       attack: 2,   damage: 1,  multi: 0, defense: 0,  special: [] },
		positionRear:      { heading: "Position",         label: "Rear",                        group: "flank",       attack: 4,   damage: 2,  multi: 0, defense: 0,  special: [] },
		positionAbove:     { heading: "Position",         label: "Above",                       group: "height",      attack: 2,   damage: 2,  multi: 0, defense: 0,  special: [] },
		positionBelow:     { heading: "Position",         label: "Below",                       group: "height",      attack: -2,  damage: -2, multi: 0, defense: 0,  special: [] },
		targetWall:        { heading: "Target",           label: "Against Wall",                group: "",            attack: 2,   damage: 0,  multi: 1, defense: 0,  special: [] },
		targetProne:       { heading: "Target",           label: "Prone/Dazed",                 group: "",            attack: 6,   damage: 0,  multi: 1, defense: 0,  special: [] },
		targetImmobile:    { heading: "Target",           label: "Immobile",                    group: "",            attack: 10,  damage: 0,  multi: 1, defense: 0,  special: ["Max"] },
		speedBrace:        { heading: "Speed",            label: "Brace",                       group: "speed",       attack: 2,   damage: 2,  multi: 0, defense: 0,  special: [],                      skill: "Brace" },
		speedCharge:       { heading: "Speed",            label: "Charging",                    group: "speed",       attack: 2,   damage: 0,  multi: 1, defense: 0,  special: [] },
		speedDiving:       { heading: "Speed",            label: "Diving",                      group: "speed",       attack: 3,   damage: 0,  multi: 2, defense: 0,  special: [] },
		engageStandard:    { heading: "Engagement",       label: "Standard",                    group: "engage",      attack: 0,   damage: 0,  multi: 0, defense: 0,  special: [] },
		engageFurious:     { heading: "Engagement",       label: "Furious Attack",              group: "engage",      attack: 2,   damage: 2,  multi: 0, defense: 4,  special: [],                      engagement: true },
		engageDefense:     { heading: "Engagement",       label: "Desperate Defense",           group: "engage",      attack: 0,   damage: 0,  multi: 0, defense: -4, special: ["No Attack", "+20% Skills"], engagement: true },
		selfInvisible:     { heading: "Visibility (Self)",   label: "Invisible",                group: "selfvis",     attack: 4,   damage: 0,  multi: 0, defense: -8, special: [] },
		selfFadeDark:      { heading: "Visibility (Self)",   label: "Fade (Darkness)",          group: "selfvis",     attack: 4,   damage: 0,  multi: 0, defense: -8, special: [] },
		targetInvisible:   { heading: "Visibility (Target)", label: "Invisible",                group: "targetvis",   attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Can`t See Target"], noDef: true },
		fadeDark:          { heading: "Visibility (Target)", label: "Fade (Darkness)",          group: "targetvis",   attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Can`t See Target"], noDef: true },
		fadeDiffuse:       { heading: "Visibility (Target)", label: "Fade (Diffuse Light)",     group: "targetvis",   attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Can`t See Target"], noDef: true },
		fadeDim:           { heading: "Visibility (Target)", label: "Fade (Dim Light)",         group: "targetvis",   attack: -6,  damage: 0,  multi: 0, defense: 0,  special: [] },
		fadeNormal:        { heading: "Visibility (Target)", label: "Fade (Normal Light)",      group: "targetvis",   attack: -4,  damage: 0,  multi: 0, defense: 0,  special: [] },
		fadeSunlight:      { heading: "Visibility (Target)", label: "Fade (Sunlight)",          group: "targetvis",   attack: -2,  damage: 0,  multi: 0, defense: 0,  special: [] },
		environmentDim:    { heading: "Visibility (Environment)", label: "Partial Darkness (Dim)", group: "environment", attack: -4, damage: 0, multi: 0, defense: 2,  special: [] },
		environmentDark:   { heading: "Visibility (Environment)", label: "Darkness",            group: "environment", attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Blind"],   noDef: true },
		coverTarget:       { heading: "Cover (Target)",   label: "Against Cover",               group: "",            attack: -4,  damage: 0,  multi: 0, defense: 0,  special: [] },
		// "In Cover" is +4 to his defence, which by his own sign reads as WORSE for the one in
		// cover. His label and code agree on +4, so it is kept -- and put to him as a question.
		coverSelf:         { heading: "Cover (Self)",     label: "In Cover",                    group: "cover",       attack: 0,   damage: 0,  multi: 0, defense: 4,  special: [] },
		coverWater:        { heading: "Cover (Self)",     label: "In Water",                    group: "cover",       attack: -4,  damage: 0,  multi: 0, defense: 2,  special: [] },
		coverUnderwater:   { heading: "Cover (Self)",     label: "Underwater",                  group: "cover",       attack: -2,  damage: -6, multi: 0, defense: 4,  special: [] },
		selfDeaf:          { heading: "Attacker Disability", label: "Deaf",                     group: "",            attack: -1,  damage: -1, multi: 0, defense: 1,  special: [] },
		selfBlind:         { heading: "Attacker Disability", label: "Blind",                    group: "",            attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Blind"],   noDef: true }
	};

	// @MARKER SITUATIONAL MISSILE
	//                   key                      label                         group         attack damage multi defense special                         noDef  skill / roll
	export const SITUATIONAL_MISSILE = {
		calledShot:        { heading: "Called Shot",      label: "Called Shot",                 group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Called Shot"] },
		perfectShot:       { heading: "Perfect Shot",     label: "Perfect Shot (Max Dam)",      group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Max"],                 skill: "Perfect Shot" },
		perfectShotCrit:   { heading: "Perfect Shot",     label: "Crit (+1 Dam)",               group: "",            attack: 0,   damage: 1,  multi: 0, defense: 0,  special: [],                      roll: { skill: "Perfect Shot", on: "crit" } },
		perfectShotFail:   { heading: "Perfect Shot",     label: "Crit Fail (Half Damage)",     group: "",            attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Half Dam"],            roll: { skill: "Perfect Shot", on: "fail" } },
		quickLoad:         { heading: "Quick Load",       label: "Quick Load (Half Reload Speed)", group: "",         attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Half Reload Speed"],   skill: "Quick Load" },
		// His SET never reads sit_quick_load_fail, so it has no figure. The consequence is his
		// label's -- an Agility save or the projectiles are dropped -- and is printed as a note.
		quickLoadFail:     { heading: "Quick Load",       label: "Crit Fail (AGL Save or drop Projectiles)", group: "", attack: 0, damage: 0, multi: 0, defense: 0, special: ["AGL Save or Drop Projectiles"], roll: { skill: "Quick Load", on: "fail" } },
		speedBrace:        { heading: "Brace Skill",      label: "Brace",                       group: "",            attack: 2,   damage: 2,  multi: 0, defense: 0,  special: [],                      skill: "Brace" },
		surpriseNormal:    { heading: "Surprise",         label: "Surprise",                    group: "",            attack: 4,   damage: 6,  multi: 0, defense: 0,  special: [] },
		surpriseAttack:    { heading: "Surprise",         label: "Surprise Attack (x2 Dam)",    group: "",            attack: 0,   damage: 0,  multi: 1, defense: 0,  special: [],                      skill: "Surprise Attack" },
		aimSec1:           { heading: "Aiming",           label: "Aim 1 Second",                group: "aim",         attack: 1,   damage: 0,  multi: 0, defense: 0,  special: [] },
		aimSec2:           { heading: "Aiming",           label: "Aim 2 Seconds",               group: "aim",         attack: 2,   damage: 0,  multi: 0, defense: 0,  special: [] },
		aimSec3:           { heading: "Aiming",           label: "Aim 3 Seconds",               group: "aim",         attack: 3,   damage: 0,  multi: 0, defense: 0,  special: [] },
		aimSec4:           { heading: "Aiming",           label: "Aim 4 Seconds",               group: "aim",         attack: 4,   damage: 0,  multi: 0, defense: 0,  special: [] },
		rangePointBlank:   { heading: "Range",            label: "Point Blank",                 group: "range",       attack: 2,   damage: 0,  multi: 0, defense: 0,  special: ["+1 per Die"] },
		rangeShort:        { heading: "Range",            label: "Short",                       group: "range",       attack: 0,   damage: 0,  multi: 0, defense: 0,  special: [] },
		rangeMedium:       { heading: "Range",            label: "Medium",                      group: "range",       attack: -2,  damage: 0,  multi: 0, defense: 0,  special: [],                      clears: ["twoProjectiles", "threeProjectiles"] },
		rangeLong:         { heading: "Range",            label: "Long",                        group: "range",       attack: -4,  damage: 0,  multi: 0, defense: 0,  special: [],                      clears: ["twoProjectiles", "threeProjectiles"] },
		rangeExtreme:      { heading: "Range",            label: "Extreme",                     group: "range",       attack: -6,  damage: 0,  multi: 0, defense: 0,  special: ["-1 per Die", "Random Location"], clears: ["twoProjectiles", "threeProjectiles"] },
		wrongProjectile:   { heading: "Wrong Type/Size Projectile", label: "Wrong Type/Size",   group: "",            attack: -2,  damage: 0,  multi: 0, defense: 0,  special: ["Wrong Projectile"],    sets: ["ignoreType"] },
		ignoreType:        { heading: "Wrong Type/Size Projectile", label: "Override Type Check", group: "",          attack: 0,   damage: 0,  multi: 0, defense: 0,  special: ["Ignore Projectile Type"] },
		// Penalties counted by resolveMultiMissile, not here -- see the note above.
		twoWeapons:        { heading: "Multiple Weapons/Projectiles", label: "2 Missile Weapons", group: "multimissile", attack: 0, damage: 0,  multi: 0, defense: 0,  special: [],                      multiMissile: "twoWeapons" },
		twoProjectiles:    { heading: "Multiple Weapons/Projectiles", label: "2 Projectiles",   group: "multimissile", attack: 0,  damage: 0,  multi: 0, defense: 0,  special: [],                      multiMissile: "twoProjectiles", closeOnly: true },
		threeProjectiles:  { heading: "Multiple Weapons/Projectiles", label: "3 Projectiles",   group: "multimissile", attack: 0,  damage: 0,  multi: 0, defense: 0,  special: [],                      multiMissile: "threeProjectiles", closeOnly: true },
		// Missile visibility never takes the defence away, unlike melee: his missile SET has no
		// "Can`t See Target" override at all. The words are carried all the same, since Martial
		// Lore's blind fighting reads them, and the book gives it to missile weapons (user's ruling,
		// 2026-09-22); they print on the card as a note, as melee's do.
		targetInvisible:   { heading: "Visibility (Target)", label: "Invisible",                group: "targetvis",   attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Can`t See Target"] },
		fadeDark:          { heading: "Visibility (Target)", label: "Fade (Darkness)",          group: "targetvis",   attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Can`t See Target"] },
		fadeDiffuse:       { heading: "Visibility (Target)", label: "Fade (Diffuse Light)",     group: "targetvis",   attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Can`t See Target"] },
		fadeDim:           { heading: "Visibility (Target)", label: "Fade (Dim Light)",         group: "targetvis",   attack: -6,  damage: 0,  multi: 0, defense: 0,  special: [] },
		fadeNormal:        { heading: "Visibility (Target)", label: "Fade (Normal Light)",      group: "targetvis",   attack: -4,  damage: 0,  multi: 0, defense: 0,  special: [] },
		fadeSunlight:      { heading: "Visibility (Target)", label: "Fade (Sunlight)",          group: "targetvis",   attack: -2,  damage: 0,  multi: 0, defense: 0,  special: [] },
		// His label says "No Defense" for Darkness; his missile SET gives none. The code is kept.
		environmentDim:    { heading: "Visibility (Environment)", label: "Partial Darkness (Dim)", group: "environment", attack: -4, damage: 0, multi: 0, defense: 2,  special: [] },
		environmentDark:   { heading: "Visibility (Environment)", label: "Darkness",            group: "environment", attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Blind"] },
		coverTarget:       { heading: "Cover (Target)",   label: "Behind Cover",                group: "",            attack: -4,  damage: 0,  multi: 0, defense: 0,  special: [] },
		// His SET tests sit_self_one_eye but never asks the sheet for it (it is missing from that
		// getAttrs list), so on his sheet One Eye silently does nothing. His label and his own test
		// both say -2; that is what is built. docs/UPSTREAM-ISSUES.md records it.
		selfOneEye:        { heading: "Attacker Disability", label: "One Eye",                  group: "",            attack: -2,  damage: 0,  multi: 0, defense: 0,  special: [] },
		selfBlind:         { heading: "Attacker Disability", label: "Blind",                    group: "",            attack: -8,  damage: 0,  multi: 0, defense: 0,  special: ["Blind"], noDef: true }
	};

	// Target size, shared by both panels and one-of across all twenty-four -- his
	// clearSizeModsOtherThan. The steps top out at +10 bigger but go to -12 smaller, as his SET has
	// them; the gap is his.
	//                     key         steps   attack
	export const SITUATIONAL_SIZE = {};
	for (var tmpstep = 1; tmpstep <= 12; tmpstep++) {
		SITUATIONAL_SIZE["bigger" + tmpstep]  = { heading: "Target Size Difference", label: `${tmpstep} Bigger`,  group: "size", attack: Math.min(tmpstep, 10), damage: 0, multi: 0, defense: 0, special: [] };
	}
	for (var tmpstep = 1; tmpstep <= 12; tmpstep++) {
		SITUATIONAL_SIZE["smaller" + tmpstep] = { heading: "Target Size Difference", label: `${tmpstep} Smaller`, group: "size", attack: -tmpstep,             damage: 0, multi: 0, defense: 0, special: [] };
	}

	// The optional body-area size, also shared, and one-of among its six.
	//                     key         label                                   attack
	export const SITUATIONAL_AREA = {
		areaGiant:     { heading: "Target Body Area (Optional)", label: "Giant (Dragon's Belly)",              group: "area", attack: 4,  damage: 0, multi: 0, defense: 0, special: [] },
		areaLarge:     { heading: "Target Body Area (Optional)", label: "Large (Dragon's Neck)",               group: "area", attack: 2,  damage: 0, multi: 0, defense: 0, special: [] },
		areaOversize:  { heading: "Target Body Area (Optional)", label: "Oversize (Centaur Belly)",            group: "area", attack: 1,  damage: 0, multi: 0, defense: 0, special: [] },
		areaUndersize: { heading: "Target Body Area (Optional)", label: "Undersized (Forearm, Mid-Torso, Shin)", group: "area", attack: -2, damage: 0, multi: 0, defense: 0, special: [] },
		areaSmall:     { heading: "Target Body Area (Optional)", label: "Small (Neck)",                        group: "area", attack: -4, damage: 0, multi: 0, defense: 0, special: [] },
		areaTiny:      { heading: "Target Body Area (Optional)", label: "Tiny (Hand/Foot)",                    group: "area", attack: -6, damage: 0, multi: 0, defense: 0, special: [] }
	};

	// This is the function which returns every option one panel offers, in the order it shows
	// them. tmpkind is "melee" or "missile"; anything else is no panel at all.
	export function getSituationalOptions(tmpkind) {
		if (tmpkind == "melee")   { return { ...SITUATIONAL_MELEE,   ...SITUATIONAL_SIZE, ...SITUATIONAL_AREA }; }
		if (tmpkind == "missile") { return { ...SITUATIONAL_MISSILE, ...SITUATIONAL_SIZE, ...SITUATIONAL_AREA }; }
		return {};
	}

	// This is the function which ticks or unticks one option and returns the new selection, with
	// his exclusions applied: ticking an option clears the others in its group, and a medium or
	// longer range clears double and triple fire, which "is only allowed at point blank or short
	// range". Ticking Wrong Type/Size also ticks Override Type Check, as his handler does.
	//
	// Options set by a skill roll are refused here -- tmpforce is how the roll itself sets them.
	export function toggleSituationalOption(tmpkind, tmpselected, tmpkey, tmpforce) {
		var tmpoptions = getSituationalOptions(tmpkind);
		var tmpoption = tmpoptions[tmpkey];
		var tmpout = (tmpselected ?? []).filter(k => tmpoptions[k]);
		if (!tmpoption) { return tmpout; }
		if ((tmpoption.skill || tmpoption.roll) && !tmpforce) { return tmpout; }

		if (tmpout.includes(tmpkey)) {
			return tmpout.filter(k => k != tmpkey);
		}

		if (tmpoption.group) {
			tmpout = tmpout.filter(k => tmpoptions[k].group != tmpoption.group);
		}
		// Only the range clears the fire, not the other way round: his two_proj handler does not
		// look at the range at all, so ticking it after Medium is allowed, as it is on his sheet.
		for (const tmpcleared of tmpoption.clears ?? []) {
			tmpout = tmpout.filter(k => k != tmpcleared);
		}
		tmpout.push(tmpkey);
		for (const tmpalso of tmpoption.sets ?? []) {
			if (!tmpout.includes(tmpalso)) { tmpout.push(tmpalso); }
		}
		return tmpout;
	}

	// This is the function which works out what a skill roll for one of the six roll-set options
	// does to the selection. His handlers (sheet-worker.js:19112 for Critical, and the same shape
	// for the other five) read the roll against the skill's chance plus the chosen weapon's skills
	// modifier:
	//
	//     critical success  -> the option AND its Crit
	//     success           -> the option alone
	//     failure           -> nothing
	//     critical failure  -> its Crit Fail alone
	//
	// and clear all three first, so a second roll replaces the first rather than adding to it.
	// tmpoutcome is one of SKILL_OUTCOMES in skills-rules.mjs. Returns the new selection.
	export function getSituationalRollResult(tmpkind, tmpselected, tmpkey, tmpoutcome) {
		var tmpoptions = getSituationalOptions(tmpkind);
		var tmpoption = tmpoptions[tmpkey];
		if (!tmpoption || !tmpoption.skill) { return (tmpselected ?? []).slice(); }

		var tmpfamily = Object.keys(tmpoptions).filter(k =>
			k == tmpkey || (tmpoptions[k].roll && tmpoptions[k].roll.skill == tmpoption.skill));
		var tmpout = (tmpselected ?? []).filter(k => tmpoptions[k] && !tmpfamily.includes(k));

		var tmpcrit = tmpfamily.find(k => tmpoptions[k].roll?.on == "crit");
		var tmpfail = tmpfamily.find(k => tmpoptions[k].roll?.on == "fail");
		if (tmpoutcome == "Critical success") {
			tmpout = toggleSituationalOption(tmpkind, tmpout, tmpkey, true);
			if (tmpcrit) { tmpout.push(tmpcrit); }
		} else if (tmpoutcome == "Succeeded") {
			tmpout = toggleSituationalOption(tmpkind, tmpout, tmpkey, true);
		} else if (tmpoutcome == "Critical failure") {
			if (tmpfail) { tmpout.push(tmpfail); }
		}
		return tmpout;
	}

	// This is the function which totals a selection the way his SET does.
	//
	//   tmpkind      "melee" or "missile" -- which panel was set; "" for none
	//   tmpselected  the keys ticked
	//   tmpmartial   { blindFighting, fullDefense, inStance } from the martial arts, all optional:
	//                blindFighting is the better of his martial_stance_blind_fighting and
	//                martial_lore_blind_fighting, added to hit whenever the attacker is blind or
	//                cannot see the target; fullDefense keeps the defence a blind attacker would
	//                lose; inStance switches off the two special engagements, which "cannot
	//                combine" with a martial stance.
	//
	// Returns { kind, attack, damage, multi, defense, noDefense, special, multiMissile, noAttack,
	// labels } -- labels being the chosen options by name, for the combat tab and the chat card.
	export function resolveSituationalMods(tmpkind, tmpselected, tmpmartial) {
		var tmpout = { kind: "", attack: 0, damage: 0, multi: 1, defense: 0, noDefense: false,
		               special: [], multiMissile: "", noAttack: false, labels: [], blindSkills: 0 };
		var tmpoptions = getSituationalOptions(tmpkind);
		if (!Object.keys(tmpoptions).length) { return tmpout; }
		tmpout.kind = tmpkind;

		var tmpmartialin = tmpmartial ?? {};
		var tmpmulti = 1;
		var tmpblindnodef = false;
		var tmpothernodef = false;
		for (const tmpkey of tmpselected ?? []) {
			var tmpoption = tmpoptions[tmpkey];
			if (!tmpoption) { continue; }
			// His "cannot combine martial stances with special engagements".
			if (tmpoption.engagement && tmpmartialin.inStance) { continue; }
			tmpout.attack  = tmpout.attack  + (parseInt(tmpoption.attack)  || 0);
			tmpout.damage  = tmpout.damage  + (parseInt(tmpoption.damage)  || 0);
			tmpout.defense = tmpout.defense + (parseInt(tmpoption.defense) || 0);
			tmpmulti = tmpmulti + (parseInt(tmpoption.multi) || 0);
			// A defence lost to blindness is kept apart from one lost any other way (a critically
			// failed Critical), since only the first is what a blind fighter can keep.
			if (tmpoption.noDef) {
				var tmpblindword = (tmpoption.special ?? []).some(w => w == "Blind" || w == "Can`t See Target");
				if (tmpblindword) { tmpblindnodef = true; } else { tmpothernodef = true; }
				tmpout.noDefense = true;
			}
			if (tmpoption.multiMissile) { tmpout.multiMissile = tmpoption.multiMissile; }
			for (const tmpword of tmpoption.special ?? []) {
				if (!tmpout.special.includes(tmpword)) { tmpout.special.push(tmpword); }
			}
			tmpout.labels.push(tmpoption.heading == tmpoption.label ? tmpoption.label
				: `${tmpoption.heading}: ${tmpoption.label}`);
		}
		if (tmpmulti > 3) { tmpmulti = 3; }            // x3 is the max damage
		tmpout.multi = tmpmulti;
		tmpout.noAttack = tmpout.special.includes("No Attack");

		// Martial blind fighting, whenever the attacker is blind or cannot see the target.
		//
		// His handleMeleeSet reads it for melee only. By the user's ruling of 2026-09-22 the BOOK's
		// Martial Lore figures are used, and the book gives them to "melee and missile weapons", so a
		// missile set reads Martial Lore's offset too (See without eyes stays melee-only, being a
		// melee stance -- martial-arts.mjs hands the two apart). The to-hit is an offset and is held
		// to the blindness penalty it offsets: "the practitioner does not gain additional bonuses once
		// the blindness penalties are negated". Damage and combat skills are the book's per-level
		// extras; skills comes back as blindSkills for the character to lay on its combat skills.
		//
		// "Full Defensive Mod" keeps the defence only against a BLIND loss of it. His handleMeleeSet
		// clears the No Defense override whatever caused it, so on his sheet a blind fighter who
		// critically failed a Critical kept their defence too; his own comment says what it is for,
		// "a blind fighter/Martial Lorist who can hear well enough to get defensive modifier anyway".
		var tmpblind = tmpout.special.includes("Blind") || tmpout.special.includes("Can`t See Target");
		if (tmpblind) {
			var tmppenalty = 0;
			for (const tmpkey of tmpselected ?? []) {
				var tmpblindoption = tmpoptions[tmpkey];
				if (!tmpblindoption) { continue; }
				var tmpwords = tmpblindoption.special ?? [];
				if ((tmpwords.includes("Blind") || tmpwords.includes("Can`t See Target")) && tmpblindoption.attack < 0) {
					tmppenalty = tmppenalty - tmpblindoption.attack;
				}
			}
			var tmpoffset = parseInt((tmpkind == "missile") ? tmpmartialin.missileBlindFighting : tmpmartialin.blindFighting) || 0;
			tmpout.attack = tmpout.attack + Math.min(tmpoffset, tmppenalty);
			tmpout.damage = tmpout.damage + (parseInt(tmpmartialin.damage) || 0);
			tmpout.blindSkills = parseInt(tmpmartialin.skills) || 0;
			if (tmpmartialin.fullDefense && tmpblindnodef && !tmpothernodef) { tmpout.noDefense = false; }
		}
		return tmpout;
	}

	// This is the function which cuts the character's standing situational modifiers down to one
	// attack. Set for melee and swinging a sword, they all apply; set for missile and swinging a
	// sword, none of the attack's own figures do -- his handlePhysicalAttacks zeroes the other
	// kind's to-hit, damage and multiplier (sheet-worker.js:64571-64640).
	//
	// His code leaves the special words in place across kinds (the line that would clear them is
	// commented out). They are cleared here too: a missile panel's "Max" or "+1 per Die" reaching a
	// sword blow cannot be meant, and the only word that has to cross -- Desperate Defense's
	// "No Attack" -- is melee's own. Recorded in docs/DECISIONS.md as a reading.
	//
	// The character's own defence is not part of this: it stands whatever they attack with.
	export function getSituationalForAttack(tmpsituation, tmpmode) {
		var tmpnone = { attack: 0, damage: 0, multi: 1, special: [], multiMissile: "", noAttack: false,
		                maxDamage: false, halfDamage: false, perDie: 0, labels: [] };
		if (!tmpsituation || !tmpsituation.kind) { return tmpnone; }
		// A weapon's mode (thrust, cut, smash, missile) or a creature attack's "melee"/"missile".
		var tmpismissile = (tmpmode == "missile");
		if ((tmpsituation.kind == "missile") != tmpismissile) { return tmpnone; }

		var tmpspecial = tmpsituation.special ?? [];
		var tmpperdie = 0;
		if (tmpspecial.includes("+1 per Die")) { tmpperdie = tmpperdie + 1; }
		if (tmpspecial.includes("-1 per Die")) { tmpperdie = tmpperdie - 1; }
		return {
			attack: parseInt(tmpsituation.attack) || 0,
			damage: parseInt(tmpsituation.damage) || 0,
			multi: parseFloat(tmpsituation.multi) || 1,
			special: tmpspecial.slice(),
			multiMissile: tmpsituation.multiMissile ?? "",
			noAttack: !!tmpsituation.noAttack,
			maxDamage: tmpspecial.includes("Max"),
			halfDamage: tmpspecial.includes("Half Dam"),
			perDie: tmpperdie,
			labels: (tmpsituation.labels ?? []).slice()
		};
	}

	// The special words the attack works out itself. Everything else is for the table to act on
	// -- where a Random Location lands, half reload time, the Agility save to keep hold of the
	// projectiles -- and is printed on the card rather than applied.
	export const SITUATIONAL_WORDS_APPLIED = ["Max", "Half Dam", "+1 per Die", "-1 per Die", "Called Shot", "No Attack"];

	// This is the function which picks out the words the card prints as notes, with his backtick
	// apostrophe ("Can`t See Target") turned back into an ordinary one.
	export function getSituationalNotes(tmpspecial) {
		return (tmpspecial ?? []).filter(w => !SITUATIONAL_WORDS_APPLIED.includes(w)).map(w => ("" + w).replace("`", "'"));
	}


//==================================================================================================================
// @MARKER DAMAGE
//==================================================================================================================

	// This is the function which picks the damage dice for a weapon in a given attack mode.
	// A Spear thrown and an Axe Hammer thrusting use their bracketed damage instead.
	export function getWeaponDamageDice(tmpweapon, tmpmode) {
		if (tmpweapon.damageAlt && tmpweapon.damageAltMode == tmpmode) { return tmpweapon.damageAlt; }
		return tmpweapon.damage;
	}

	// This is the function which works out the Strength damage bonus for an attack.
	// Ported from handlePhysicalAttacks (sheet-worker.js:64783-64800).
	//
	// Strength adds to melee damage only; projectile weapons get none. Held in two hands, a
	// positive bonus is doubled -- but a NEGATIVE bonus is halved, so a weak character is not
	// punished twice for using both hands. parseInt truncates toward zero, as in his code, so
	// -3 halves to -1.
	export function getStrengthDamageMod(tmpmeleeDamage, tmpmode, tmptwohanded) {
		if (!MELEE_MODES.includes(tmpmode)) { return 0; }
		var tmpmod = parseInt(tmpmeleeDamage) || 0;
		if (tmptwohanded) {
			if (tmpmod > 0) { tmpmod = parseInt(tmpmod * 2); }
			else if (tmpmod < 0) { tmpmod = parseInt(tmpmod / 2); }
		}
		return tmpmod;
	}

	// This is the function which gives the flat +2 damage a melee weapon held in two hands does --
	// his DamMod2Hand=2 in the same block of handlePhysicalAttacks (sheet-worker.js:64784-64793),
	// printed on his card as "2Handed(+2)" (65045). The Player's Guide's Rule of 2 (p.182, "Using a
	// Weapon with Two Hands"): "x2 Strength damage modifier, +2 damage, -2 weapon speed". The x2 is
	// getStrengthDamageMod above; this is the +2. Melee only, as his test is (thrust, cut or smash).
	//
	// Bug reports 0.20.10:1 and 0.22.5:2 asked for "+2 to hit". Neither his code nor the book has a
	// to-hit bonus for two hands -- both have this +2 damage, which the port had not applied, so 0.22.0
	// shipped the damage; 0.22.1 built a to-hit bonus as well on his word, and he retracted it on
	// 2026-10-07 (bug retraction 0.22.1:5: "only damage"), so 0.24.2 took it out again. The book's
	// -2 speed is in neither his sheet nor the port, and is UPSTREAM-ISSUES item 115 rather than built
	// here (the sheet outranks the book).
	export function getTwoHandedDamageBonus(tmpmode, tmptwohanded) {
		if (!tmptwohanded || !MELEE_MODES.includes(tmpmode)) { return 0; }
		return 2;
	}

	// @MARKER BODY WEIGHT DAMAGE
	// His getWeightDamageAdj (sheet-worker.js:83259-83301), the Player's Guide's "Body Weight Damage
	// Modifiers" table (p.179, PDF page 197): what a being's own weight adds to, or takes off, the
	// damage it does.
	// The book says "when the character attacks with any melee weapon"; his setCombatModifierValues
	// (82170) folds it into combat_mod_damage, the one standing damage figure every attack reads.
	//
	// Each row is the band's UPPER bound, exclusive, walked in order, which is exactly what his else-if
	// chain does -- 10.5 lb is in the first band because it is under 11, as his "tempweight<11" has it.
	// Nothing at all (0, blank) adjusts nothing. His 350-399 branch is written "tempweight>249", a
	// slip that changes no answer because 250-349 were already caught by the branches before it.
	// The book's table has two misprinted rows -- "300-349" twice, the first at +2, and "2000-3999"
	// twice, the first at +12 -- which his sheet reads as the evident 250-299 and 1200-1999. Same
	// answer either way; the sheet is the one followed.
	//
	//          under  adjust        band         the book's example
	export const WEIGHT_DAMAGE_ADJUST = [
		[    11, -5 ],       // 1-10 lb        a rat
		[    26, -4 ],       // 11-25          a fairy
		[    51, -3 ],       // 26-50          a dog
		[    76, -2 ],       // 51-75          a midfolk
		[   100, -1 ],       // 76-99          an elf
		[   200,  0 ],       // 100-199        a human
		[   250,  1 ],       // 200-249        a dwarf
		[   300,  2 ],       // 250-299        a goblin
		[   350,  3 ],       // 300-349        a saurian
		[   400,  4 ],       // 350-399        a troll
		[   500,  5 ],       // 400-499        an ogre
		[   600,  6 ],       // 500-599        a centaur
		[   800,  8 ],       // 600-799        a wyvern
		[  1200, 10 ],       // 800-1199       a small giant
		[  2000, 12 ],       // 1200-1999      a giant
		[  4000, 14 ],       // 2000-3999      a large giant
		[  8000, 16 ],       // 4000-7999      a titan
		[ 10000, 18 ]        // 8000-9999      a dragon; 10,000 lb or more is +20, a large dragon
	];

	// This is the function which gives the body-weight damage adjustment for a weight in pounds.
	//
	// A CREATURE's is floored at 0: his own comment at sheet-worker.js:82173 reads "weight is already
	// factored into smaller creature damage modifiers", so a small creature is not docked for being
	// small -- only a big one is paid for being big. A character's is signed both ways.
	export function getWeightDamageAdjust(tmpweight, tmpiscreature) {
		var tmppounds = parseFloat(tmpweight) || 0;
		var tmpadjust = 0;
		if (tmppounds > 0) {
			tmpadjust = 20;
			for (const [tmpunder, tmpvalue] of WEIGHT_DAMAGE_ADJUST) {
				if (tmppounds < tmpunder) { tmpadjust = tmpvalue; break; }
			}
		}
		if (tmpiscreature && tmpadjust < 0) { tmpadjust = 0; }
		return tmpadjust;
	}

	// This is the function which combines damage multipliers. The Player's Guide: "no matter
	// how many multipliers to damage one can gain, base damage may never be multiplied by more
	// than three."
	export function combineDamageMultipliers(tmplist) {
		var tmpmulti = 1;
		for (const tmpvalue of tmplist) { tmpmulti = tmpmulti * (parseFloat(tmpvalue) || 1); }
		if (tmpmulti > 3) { tmpmulti = 3; }
		return tmpmulti;
	}


//==================================================================================================================
// @MARKER ARMOUR
//==================================================================================================================

	// This is the function which works out how much damage gets through the armour at the struck
	// area. Ported from handleBodyDamage (sheet-worker.js:71276-71321).
	//
	// The damage falls into one of four bands against the area's total armour -- under a
	// quarter, quarter to half, half to full, or over -- and that band's value from
	// ARMOR_BLOCKING decides what happens:
	//     negative  ->  damage + (total armour x value)   armour subtracts a fraction of itself
	//     positive  ->  damage x value                    only that share gets through
	//     zero      ->  no damage at all
	// The band edges are strict (">"), so damage exactly equal to the armour falls in the
	// half-to-full band.
	// This is the function which reads a damage type as the armour tables spell it: "Death" is
	// "Life/Death", "Holy" is "Aura/Divine" (BLOCKING_TYPE_OF, combat-tables.mjs); a spelling the map
	// does not know is returned as it came, and the tables' own "Other" row catches what they lack.
	export function getBlockingDamageType(tmptype) {
		var tmpname = String(tmptype ?? "").trim();
		return Object.hasOwn(BLOCKING_TYPE_OF, tmpname) ? BLOCKING_TYPE_OF[tmpname] : tmpname;
	}

	export function blockDamage(tmpdamage, tmptype, tmptotalarmor, tmpbypass) {
		tmptype = getBlockingDamageType(tmptype);
		var tmpdmg = parseInt(tmpdamage) || 0;
		if (tmpbypass) { return tmpdmg; }

		var tmpblock = ARMOR_BLOCKING[tmptype] ?? ARMOR_BLOCKING["Other"];
		var tmpfull = parseInt(tmptotalarmor) || 0;
		if (tmpfull < 0) { tmpfull = 0; }
		var tmphalf = parseInt(tmpfull * 0.5) || 0;
		var tmpquarter = parseInt(tmpfull * 0.25) || 0;

		var tmpvalue;
		if      (tmpdmg > tmpfull)    { tmpvalue = tmpblock[3]; }
		else if (tmpdmg > tmphalf)    { tmpvalue = tmpblock[2]; }
		else if (tmpdmg > tmpquarter) { tmpvalue = tmpblock[1]; }
		else                          { tmpvalue = tmpblock[0]; }

		// Rounded UP, as the book's own examples are ("halved and rounded up": 19 smashing against a
		// 20-point helm puts 10 through, p.189) and as his bug report 0.22.7:1 has them. His code
		// truncated (parseInt); a 15-point cut against 20 armour put 3 through where the book puts 4.
		if (tmpvalue < 0)      { tmpdmg = Math.ceil(tmpdmg + (tmpfull * tmpvalue)); }
		else if (tmpvalue > 0) { tmpdmg = Math.ceil(tmpdmg * tmpvalue); }
		else                   { tmpdmg = 0; }

		if (tmpdmg < 0) { tmpdmg = 0; }
		return tmpdmg;
	}

	// This is the function which finds the strongest material among the armour covering an
	// area. Its degradation divider is the one that applies (getBestArmorType, sheet-worker.js:
	// 118887).
	export function getStrongestMaterial(tmpmaterials) {
		var tmpbest = "";
		var tmpbestrank = -1;
		for (const tmpmaterial of tmpmaterials) {
			var tmprank = ARMOR_MATERIAL_RANK[tmpmaterial] ?? 0;
			if (tmprank > tmpbestrank) { tmpbest = tmpmaterial; tmpbestrank = tmprank; }
		}
		return tmpbest;
	}

	// This is the function which works out how much damage the armour itself takes.
	// Ported from getArmorDamage (sheet-worker.js:118851).
	//
	// The damage used is the damage BEFORE armour blocked any of it. It is divided by the
	// strongest material's divider for that family of damage, truncated. Acid and Obliteration
	// strike the armour at full value. Magical armour is never degraded -- it can only be
	// destroyed, which is handled elsewhere.
	//
	// His version has two bugs that defeat its own intent: it walks the area's armour list but
	// indexes the character's full equipped list, and its magic check compares array elements to
	// "+" so it is never true. The intent is implemented here. See docs/UPSTREAM-ISSUES.md.
	export function getArmorDamage(tmpdamage, tmptype, tmpmaterial, tmpismagic) {
		tmptype = getBlockingDamageType(tmptype);
		if (tmpismagic) { return 0; }
		var tmpdmg = parseInt(tmpdamage) || 0;
		if (tmptype == "Acid" || tmptype == "Obliteration") { return tmpdmg; }

		var tmpdivider = ARMOR_DAMAGE_DIVIDERS[tmpmaterial];
		if (!tmpdivider) { return 0; }

		var tmpindex = -1;
		if (tmptype == "Cutting") { tmpindex = 0; }
		else if (tmptype == "Thrusting" || tmptype == "Piercing") { tmpindex = 1; }
		else if (["Smashing", "Crushing", "Force", "Sonic", "Kinetic"].includes(tmptype)) { tmpindex = 2; }
		else if (["Constricting", "Aura/Divine", "Life/Death"].includes(tmptype)) { tmpindex = 3; }
		if (tmpindex < 0) { return 0; }

		var tmpdiv = parseFloat(tmpdivider[tmpindex]) || 1;
		return parseInt(tmpdmg / tmpdiv) || 0;
	}


	// This is the function which applies a target's pain threshold to a blow, before anything
	// else touches it. (handleBodyDamage, sheet-worker.js:71186-71193.)
	//
	// His field is a SIGNED modifier on incoming damage, not a level a blow has to get over.
	// The note beside it on his own sheet reads "reduces or adds to all incoming damage (-/+)",
	// so a negative pain threshold is a tougher character and a positive one a more tender one,
	// and the number is simply added. The Famorian "High Pain Threshold" evoke takes a further
	// point off; nothing sets that yet, because the evoke system is its own piece of work, but
	// the argument is here so the arithmetic is complete and wiring it up later is one line.
	//
	// The result is deliberately NOT floored at zero. His is not either: the floor comes further
	// down the pipeline, after the magical pre-reductions, and resolveAreaDamage applies it.
	export function applyPainThreshold(tmpdamage, tmppainthreshold, tmphighpainthreshold) {
		var tmpvalue = parseInt(tmpdamage) || 0;
		tmpvalue = tmpvalue + (parseInt(tmppainthreshold) || 0);
		if (tmphighpainthreshold) { tmpvalue = tmpvalue - 1; }
		return tmpvalue;
	}

	// This is the function which runs a blow against the armour at one area, in his order
	// (handleBodyDamage, sheet-worker.js:71274-71358):
	//   1. armour blocks some or all of it, by band
	//   2. the armour takes its own damage, worked from the damage BEFORE blocking
	//   3. natural hide (a creature's tough skin, etc.) then takes its share off what is left
	//
	// The target's pain threshold has already been applied by then -- it is the first thing his
	// handler does, above all of this -- so pass the damage through applyPainThreshold first.
	//
	// Whether a blow lands at all is decided BEFORE any of this, by blowLands below. His whole
	// apply block, armour damage and hide and absorption and the store alike, sits inside
	// `if (!isLost && !noDamageInput)` (line 71322), so a blow of under 1 does nothing whatever.
	//
	//   tmpinput = { damage, type, totalArmor, bypass, hide, material, isMagicArmor }
	export function resolveAreaDamage(tmpinput) {
		var tmporiginal = parseInt(tmpinput.damage) || 0;
		if (tmporiginal < 0) { tmporiginal = 0; }

		var tmpnet = blockDamage(tmporiginal, tmpinput.type, tmpinput.totalArmor, tmpinput.bypass);

		var tmparmordamage = 0;
		if (!tmpinput.bypass && (parseInt(tmpinput.totalArmor) || 0) > 0) {
			tmparmordamage = getArmorDamage(tmporiginal, tmpinput.type, tmpinput.material, tmpinput.isMagicArmor);
			if (tmparmordamage > tmpinput.totalArmor) { tmparmordamage = parseInt(tmpinput.totalArmor); }
		}

		var tmphide = parseInt(tmpinput.hide) || 0;
		if (tmphide > 0) { tmpnet = tmpnet - tmphide; }
		if (tmpnet < 0) { tmpnet = 0; }

		return { net: tmpnet, blocked: tmporiginal - tmpnet, armorDamage: tmparmordamage };
	}

	// @MARKER MAGICAL PROTECTION
	// Everything here sits ABOVE the armour in his pipeline: it happens to the damage before any
	// worn armour is asked to block it. The order is his (handleBodyDamage, sheet-worker.js:
	// 71249-71272) and it is worth keeping, because these subtract rather than scale and the
	// floor at zero only lands once, at the end.

	// This is the function which says whether a damage type is endured -- shrugged off entirely.
	// A tag on anything worn does it: "Enduring Frost", or the blanket "Enduring All", which
	// covers nine of his ten types but not Obliteration. See ENDURED_BY, generated from his own
	// switch, and docs/UPSTREAM-ISSUES.md item 20 for the asymmetry.
	export function isEndured(tmpdamagetype, tmpwornnames) {
		var tmptags = ENDURED_BY[getBlockingDamageType(tmpdamagetype)];
		if (!tmptags) { return false; }
		var tmpworn = (tmpwornnames ?? []).join(",");
		for (const tmptag of tmptags) {
			if (tmpworn.includes(tmptag)) { return true; }
		}
		return false;
	}

	// This is the function which says whether a blow rebounds off a "Rebound" item. Only the five
	// physical damage types do (sheet-worker.js:71222); magic and the elements pass straight by.
	export function isRebounded(tmpdamagetype, tmpwornnames) {
		if (!REBOUNDED_TYPES.includes(getBlockingDamageType(tmpdamagetype))) { return false; }
		return (tmpwornnames ?? []).join(",").includes("Rebound");
	}

	// This is the function which totals the magical weave protecting one area.
	// Ported from getWeaveValue (sheet-worker.js:119188).
	//
	// A weave is magical CLOTHING tagged "[Magical Weave]" -- all three conditions, since his
	// test is clothing AND weave AND magical. What it is worth at an area is that garment's own
	// armour value there plus its magical plus, DOUBLED, and several weaves add up.
	//
	// It comes off the damage like hide rather than like armour, and his blocking then works
	// from the armour total with the weave taken back out, so it is never counted twice.
	export function getWeaveValue(tmpworn, tmpslot) {
		var tmptotal = 0;
		if (!tmpslot) { return 0; }
		for (const tmpitem of tmpworn ?? []) {
			if (tmpitem.system?.flexibility != "Clothing") { continue; }
			if (!String(tmpitem.name ?? "").includes("[Magical Weave]")) { continue; }
			var tmpplus = parseInt(tmpitem.system?.magicBonus) || 0;
			if (tmpplus <= 0) { continue; }              // his test is "the name carries a +"
			var tmpvalue = parseInt(tmpitem.system?.coverage?.[tmpslot]) || 0;
			tmptotal = tmptotal + ((tmpvalue + tmpplus) * 2);
		}
		return tmptotal;
	}

	// This is the function which runs a blow past everything magical protecting the target,
	// before any worn armour sees it. Ported from handleBodyDamage (sheet-worker.js:71249-71272),
	// in his order:
	//   1. invulnerability scales the whole blow by how magical the weapon is
	//   2. spiritual armour subtracts
	//   3. force armour subtracts
	//   4. outer kinetic armour subtracts
	//   5. a magic shield subtracts, unless the blow bypasses armour
	//   6. a magical weave subtracts, counted as hide
	//   7. and only then is the result floored at zero
	//
	// Invulnerability is the one that scales rather than subtracts: a weapon with no magical plus
	// does nothing at all to an invulnerable target, +1 or +2 does a quarter, +3 or +4 a half,
	// and +5 or better lands in full.
	//
	// Where these values come from is a separate piece of work. His checkSpiritForceArmorModifiers
	// (line 106966) sets each to the BEST of what worn magic items grant and the Game Master's own
	// modifier -- they take the maximum rather than stacking -- and the items that grant them are
	// named by the deferred magic subsystems. Until then they are entered by hand.
	//
	//   tmpinput = { invulnerable, magicPlus, spiritArmor, forceArmor, outerKinetic,
	//                magicShield, weave, bypass }
	//
	// Returns { damage, weave } -- what is left, and the weave that was used, which the caller
	// must take back out of the armour total so it is not counted a second time.
	export function applyMagicalReductions(tmpdamage, tmpinput) {
		var tmpvalue = parseInt(tmpdamage) || 0;
		var tmpweave = parseInt(tmpinput.weave) || 0;

		if (tmpinput.invulnerable && tmpvalue != 0) {
			var tmpplus = parseInt(tmpinput.magicPlus) || 0;
			if (tmpplus < 1)      { tmpvalue = 0; }                          // no plus, no damage
			else if (tmpplus < 3) { tmpvalue = parseInt(tmpvalue * 0.25) || 0; }   // +1/+2 = a quarter
			else if (tmpplus < 5) { tmpvalue = parseInt(tmpvalue * 0.5) || 0; }    // +3/+4 = a half
			// +5 and better lands in full
		}

		tmpvalue = tmpvalue - (parseInt(tmpinput.spiritArmor) || 0);
		tmpvalue = tmpvalue - (parseInt(tmpinput.forceArmor) || 0);
		tmpvalue = tmpvalue - (parseInt(tmpinput.outerKinetic) || 0);
		if (!tmpinput.bypass) { tmpvalue = tmpvalue - (parseInt(tmpinput.magicShield) || 0); }
		tmpvalue = tmpvalue - tmpweave;
		if (tmpvalue < 0) { tmpvalue = 0; }

		return { damage: tmpvalue, weave: tmpweave };
	}

	// This is the function which says whether a blow does anything at all.
	//
	// His whole apply block is wrapped in `if (!isLost && !noDamageInput)` (sheet-worker.js:71322),
	// and noDamageInput is read from the RAW damage figure, before the pain threshold is added
	// (line 71188). So a hit that rolled under 1 damage does nothing whatever -- no wounds, no
	// armour damage, no absorption spent -- however large a positive pain threshold the target
	// carries. An area already marked LOST cannot be hurt either; lost limbs are not modelled
	// yet, so that argument is here for when they are.
	export function blowLands(tmprawdamage, tmpisareaLost) {
		if (tmpisareaLost) { return false; }
		return (parseInt(tmprawdamage) || 0) >= 1;
	}

	// This is the function which spends a target's damage absorption on a blow.
	// Ported from handleBodyDamage (sheet-worker.js:71359-71366), where it is the very last thing
	// to touch the damage -- after armour has blocked its share and after natural hide.
	//
	// Absorption is a POOL, not a per-blow reduction: it takes what it can off the damage and is
	// itself spent by the same amount, so it wears out. Both figures are worked from the values
	// before either changed, then floored at zero, which is his arithmetic exactly.
	//
	// Where the pool comes from is a separate piece of work. His checkSpiritForceArmorModifiers
	// (line 106966) refills it to the best of a "Rune Absorption: +N" on worn armour and the
	// Game Master's own modifier, every time equipment changes -- and the runes that feed it are
	// a deferred subsystem. Until then the pool is simply entered and spent.
	//
	// Returns { damage, pool } -- what gets through, and what is left in the pool.
	export function absorbDamage(tmpdamage, tmppool) {
		var tmpvalue = parseInt(tmpdamage) || 0;
		var tmpabsorb = parseInt(tmppool) || 0;
		if (tmpabsorb <= 0) { return { damage: tmpvalue, pool: tmpabsorb > 0 ? tmpabsorb : 0 }; }

		var tmpleft = tmpabsorb - tmpvalue;
		var tmpthrough = tmpvalue - tmpabsorb;
		if (tmpthrough < 0) { tmpthrough = 0; }
		if (tmpleft < 0) { tmpleft = 0; }
		return { damage: tmpthrough, pool: tmpleft };
	}


//==================================================================================================================
// @MARKER BODY AND WOUNDS
//==================================================================================================================

	// This is the function which reads a body chart into areas.
	// Ported from createBodyAreas (sheet-worker.js:180208).
	//
	// A chart is written "Head(Vital:x1),Neck(Vital:x1/2),...". An area is Vital if its details
	// say so and a Limb otherwise -- which is how his code treats wings, tails and the rest. The
	// multiplier is matched in his exact order; the order matters because "x1" appears inside
	// "x1/2" and "x10", so it has to be tested last.
	//
	// An area's name is its key -- the wounds and armour damage are stored under it -- so a chart that
	// names an area twice would give two areas one record, and two inputs of one name, which the sheet's
	// form reads back as an array and every edit then fails. His Segmented Worm does exactly that: Left
	// and Right Foot12 twice over, where the second pair was surely meant to be 13 (UPSTREAM-ISSUES). A
	// repeated name is kept as a separate area, marked " (2)", " (3)"..., and the chart's order kept.
	export function parseBodyChart(tmpchart) {
		var tmpareas = [];
		if (!tmpchart) { return tmpareas; }
		var tmpseen = {};
		for (const tmpentry of String(tmpchart).split(",")) {
			var tmpopen = tmpentry.lastIndexOf("(");
			var tmpname = (tmpopen >= 0 ? tmpentry.slice(0, tmpopen) : tmpentry).trim();
			tmpseen[tmpname] = (tmpseen[tmpname] ?? 0) + 1;
			if (tmpseen[tmpname] > 1) { tmpname = `${tmpname} (${tmpseen[tmpname]})`; }
			var tmpdetails = tmpopen >= 0 ? tmpentry.slice(tmpopen + 1).replace(")", "") : "";
			tmpareas.push({
				name: tmpname,
				type: tmpdetails.includes("Vital") ? "Vital" : "Limb",
				multiplier: getAreaMultiplier(tmpdetails)
			});
		}
		return tmpareas;
	}

	// This is the function which reads an area's Endurance multiplier out of its details.
	//
	// Follows his order (createBodyAreas, sheet-worker.js:180218-180241) with one change. His code
	// tests "x1/2" before "x1/20", and since "x1/20" contains "x1/2", an area marked x1/20 gets
	// half Endurance instead of a twentieth. No stock body chart uses x1/20 -- it can only arise
	// from his custom body area builder -- so it has never shown in play, but the longer
	// fractions are tested first here. Recorded in docs/UPSTREAM-ISSUES.md.
	export function getAreaMultiplier(tmpdetails) {
		var tmpd = String(tmpdetails);
		if (tmpd.includes("x2"))    { return 2; }
		if (tmpd.includes("x3"))    { return 3; }
		if (tmpd.includes("x4"))    { return 4; }
		if (tmpd.includes("x5"))    { return 5; }
		if (tmpd.includes("x6"))    { return 6; }
		if (tmpd.includes("x7"))    { return 7; }
		if (tmpd.includes("x8"))    { return 8; }
		if (tmpd.includes("x9"))    { return 9; }
		if (tmpd.includes("x10"))   { return 10; }
		if (tmpd.includes("x1/20")) { return 0.05; }  // before x1/2, which it contains
		if (tmpd.includes("x1/10")) { return 0.1; }
		if (tmpd.includes("x1/4"))  { return 0.25; }
		if (tmpd.includes("x1/2"))  { return 0.5; }
		if (tmpd.includes("x1"))    { return 1; }     // last, because "x1" appears in all the others
		return 1;
	}

	// This is the function which returns the body chart for a body type, as areas.
	//
	// Parsed once per chart and kept: _prepareBody asks for it on EVERY derive of every actor --
	// each wound, each item, each flag -- and the charts never change. A copy of the areas is
	// handed out, not the cached list itself, so a caller that decorates its areas (as both
	// _prepareBody routines do) cannot bend the chart for the next one.
	var tmpbodychartcache = new Map();
	export function getBodyChart(tmpbodytype) {
		var tmpchart = BODY_CHARTS[tmpbodytype] ?? BODY_CHARTS["Humanoid"];
		var tmpareas = tmpbodychartcache.get(tmpchart);
		if (!tmpareas) {
			tmpareas = parseBodyChart(tmpchart);
			tmpbodychartcache.set(tmpchart, tmpareas);
		}
		return tmpareas.map(tmparea => ({ ...tmparea }));
	}

	// @MARKER TOKEN BAR
	// This is the function which gives the figure a token's resource bar draws: how far a being is
	// from shock. Shock is the one overall threshold both actor types carry (Endurance x 3 for a
	// character, the stat block's figure or Endurance x 3 for a creature), and total wounds against it
	// is what the Combat tab's Shock box already shows as "wounds / shock".
	//
	// The bar is drawn as what is LEFT, Shock less the wounds, never below 0. Foundry colours its
	// first bar green when full and red when empty, so a bar of wounds would show an unhurt creature
	// as an empty red bar. `wounds` rides along for anything that wants the other reading.
	//
	// A being immune to shock (a creature's Shock Immune) has a Shock of 0, and a bar with a maximum
	// of 0 is one Foundry does not draw at all -- which is right: there is nothing to run out of.
	//
	// Not in his sheet: Roll20 has token bars of its own, set by hand. Chosen for this port (the
	// provisional D9 of the creature audit, docs/DECISIONS.md 2026-09-23).
	export function getShockBar(tmpshock, tmptotalwounds) {
		var tmpmax = parseInt(tmpshock) || 0;
		var tmpwounds = parseInt(tmptotalwounds) || 0;
		if (tmpmax < 0) { tmpmax = 0; }
		var tmpleft = tmpmax - tmpwounds;
		if (tmpleft < 0) { tmpleft = 0; }
		return { value: tmpleft, max: tmpmax, wounds: tmpwounds };
	}

	// This is the function which finds which armour-family covers a body type.
	//
	// His code matches with includes(), so one branch serves every chart whose name contains the
	// family word -- "Humanoid" covers all eleven Humanoid variants. No chart matches two
	// families, so the first hit is the only hit.
	// Returns "" for the twenty-three body types he wrote no branch for; those take no protection
	// from worn armour, in his sheet as in this port.
	export function getArmorFamily(tmpbodytype) {
		var tmptype = String(tmpbodytype ?? "");
		for (const tmpfamily of Object.keys(ARMOR_COVERAGE_BY_BODY_TYPE)) {
			if (tmptype.includes(tmpfamily)) { return tmpfamily; }
		}
		return "";
	}

	// This is the function which says which armour slot covers one area of one body type, and
	// whether that area needs a particular kind of armour to be covered at all.
	//
	// Ported from getArmorValuesByBodyTypeAndArmor, with one deliberate difference. His version
	// switches on the area's POSITION in the body chart; two of his branches have drifted out of
	// step with the charts they serve, so a position-keyed port would put armour on the wrong
	// limb (docs/UPSTREAM-ISSUES.md items 17 and 18). This keys by area name, which is what the
	// comments on his own cases say each position was meant to be.
	//
	// Returns { slot, requiresItem }. slot is "" when nothing covers the area. requiresItem is
	// the text an armour's name must contain for it to count there -- a centaur's quarters and
	// legs are covered by barding and by nothing else -- and "" when any armour counts.
	export function getAreaArmorSlot(tmpbodytype, tmpareaname) {
		var tmpfamily = getArmorFamily(tmpbodytype);
		if (!tmpfamily) { return { slot: "", requiresItem: "" }; }
		return {
			slot: ARMOR_COVERAGE_BY_BODY_TYPE[tmpfamily][tmpareaname] ?? "",
			requiresItem: ARMOR_REQUIRES_ITEM[tmpfamily]?.[tmpareaname] ?? ""
		};
	}

	// This is the function which totals the armour covering one area, from the layers worn.
	// Kept here rather than in each actor model, because a character and a creature work out
	// their body the same way and only differ in where the Endurance comes from.
	//
	// Returns { armor, materials, layers } before any accumulated damage is taken off.
	export function getAreaArmor(tmpbodytype, tmpareaname, tmpworn) {
		var tmpcover = getAreaArmorSlot(tmpbodytype, tmpareaname);
		var tmpout = { armor: 0, materials: [], layers: [], slot: tmpcover.slot };
		if (!tmpcover.slot) { return tmpout; }

		for (const tmpitem of tmpworn ?? []) {
			// A gated area only counts armour of the right kind, whatever else is worn over it.
			if (tmpcover.requiresItem && !String(tmpitem.name ?? "").includes(tmpcover.requiresItem)) {
				continue;
			}
			var tmpvalue = parseInt(tmpitem.system?.coverage?.[tmpcover.slot]) || 0;
			if (tmpvalue > 0) {
				tmpout.armor = tmpout.armor + tmpvalue;
				tmpout.materials.push(tmpitem.system.material);
				tmpout.layers.push(tmpitem.name);
			}
		}
		return tmpout;
	}

	// @MARKER SHIELD COVER
	// A shield is a FIFTH layer, worn over the four armour ones, and it covers a run of areas
	// down one side of the body rather than a single slot. Ported from equipShield
	// (sheet-worker.js:103777); unequipShield needs nothing here, since it only clears the layer.

	// This is the function which reads a shield's size out of its name. His equipShield tests the
	// name with includes() in this order, so "Shield(Body/Steel)" is a Body shield. Anything with
	// no size in its name is not one of his shields and covers nothing.
	export function getShieldSize(tmpitemname) {
		var tmpname = "" + (tmpitemname ?? "");
		for (const tmpsize of SHIELD_SIZES) {
			if (tmpname.includes(tmpsize)) { return tmpsize; }
		}
		return "";
	}

	// This is the function which finds which shield-family covers a body type. Same substring
	// match his includes() does, and the same eight families the armour coverage has. Returns ""
	// for the twenty-three body types he wrote no branch for, which carry no shield.
	export function getShieldFamily(tmpbodytype) {
		var tmptype = "" + (tmpbodytype ?? "");
		for (const tmpfamily of Object.keys(SHIELD_COVERAGE)) {
			if (tmptype.includes(tmpfamily)) { return tmpfamily; }
		}
		return "";
	}

	// This is the function which gives a shield its own armour value.
	//
	// Every shield carries its value in the LEFT HAND column whichever hand it is really held in
	// -- his comment at equipShield says so outright, "All shields have at least armor value in
	// area 13 (use this as the basis)" -- so the column is read rather than the covered area's.
	//
	// A magical shield adds its plus and then doubles the whole lot. That is his arithmetic as
	// written, not a misreading: a +2 shield of 10 becomes 24, not 12.
	//
	// His rune modifiers (Rune Strenghthen, Rune Armor) are added before the doubling in his
	// version. Runes are a deferred subsystem here, so nothing supplies them yet; the slot for
	// them is where his is, so adding them later is a one-line change.
	export function getShieldValue(tmpshield) {
		var tmpvalue = parseInt(tmpshield?.system?.coverage?.handLeft) || 0;
		var tmpplus = parseInt(tmpshield?.system?.magicBonus) || 0;
		if (tmpplus > 0) {
			tmpvalue = tmpvalue + tmpplus;
			tmpvalue = tmpvalue * 2;
		}
		return tmpvalue;
	}

	// This is the function which lists the areas one shield covers on one body.
	//
	// A shield is held in the off hand, so a right-hander is covered down the LEFT side. His code
	// tests only for "Left" and treats everything else as right-handed, which is how
	// "Ambidextrous" -- a value his racial code really does set -- ends up shielded on the right.
	// That is followed here rather than invented away.
	//
	// A Buckler is the one size worn two ways: strapped to the forearm, or held in the hand,
	// which is his equip_buckler_on_wrist flag.
	//
	// The list returned is the FAMILY's, so it can name an area a particular chart in that family
	// does not have -- a plain Snake has four areas and no arms at all -- and it can name the same
	// area under two spellings, since a hooved Humanoid calls its foot a hoof. Neither matters,
	// because everything downstream asks about areas the chart really has, one at a time. No chart
	// carries both a spelling and its alias, so nothing is ever counted twice.
	export function getShieldAreas(tmpbodytype, tmpshield, tmphandedness) {
		var tmpfamily = getShieldFamily(tmpbodytype);
		if (!tmpfamily) { return []; }

		var tmpsize = getShieldSize(tmpshield?.name);
		if (!tmpsize) { return []; }
		if (tmpsize == "Buckler" && tmpshield?.system?.bucklerOnWrist) { tmpsize = "Buckler(Wrist)"; }

		var tmphand = (("" + (tmphandedness ?? "")) == "Left") ? "Left" : "Right";
		return SHIELD_COVERAGE[tmpfamily][tmpsize]?.[tmphand] ?? [];
	}

	// This is the function which totals the shields covering one area.
	//
	// Kept separate from getAreaArmor rather than folded into it, because a shield is his own
	// fifth layer: he stores it in bodyarea*_shield_layer5 apart from the four armour layers, and
	// clears that layer wholesale when the shield comes off. Armour damage is tracked per area
	// against the worn layers and does not touch it.
	//
	// Returns { armor, layers } -- the value added at this area, and which shields added it.
	export function getAreaShield(tmpbodytype, tmpareaname, tmpshields, tmphandedness) {
		var tmpout = { armor: 0, layers: [] };
		for (const tmpshield of tmpshields ?? []) {
			if (!getShieldAreas(tmpbodytype, tmpshield, tmphandedness).includes(tmpareaname)) {
				continue;
			}
			var tmpvalue = getShieldValue(tmpshield);
			if (tmpvalue > 0) {
				tmpout.armor = tmpout.armor + tmpvalue;
				tmpout.layers.push(tmpshield.name);
			}
		}
		return tmpout;
	}

	// @MARKER OFF-HAND FIGHTING

	// This is the function which says whether a weapon is being used in the off hand.
	//
	// Off-handedness is DERIVED, never stored. The weapon carries which hand it is in
	// ("right" / "left" / "both") and the actor carries handedness; a weapon is off-hand when
	// those disagree. A weapon held in BOTH hands is not off-hand -- there is no spare hand for
	// a second weapon, which is the situation the whole penalty exists to describe.
	//
	// AMBIDEXTROUS HAS NO OFF HAND AT ALL. All three of his penalty functions short-circuit on
	// handedness before they ever look at Agility (sheet-worker.js:83307, 83331, 83351), so
	// ambidexterity is the ABSENCE of the cost rather than a bonus laid on top of it.
	//
	// Note the deliberate asymmetry with getShieldAreas above, which lets "Ambidextrous" fall
	// through its else branch and read as right-handed. Both behaviours are his, in different
	// functions; neither is invented away here.
	export function isOffhandWeapon(tmphand, tmphandedness) {
		var tmpwielded = "" + (tmphand ?? "right");
		if (tmpwielded == "both") { return false; }

		var tmphanded = "" + (tmphandedness ?? "");
		if (tmphanded == "Ambidextrous") { return false; }

		var tmpdominant = (tmphanded == "Left") ? "left" : "right";
		return tmpwielded != tmpdominant;
	}

	// This is the function which reads one Agility-banded off-hand penalty.
	//
	// tmpkind is "melee", "damage" or "skill". THE THREE TABLES DO NOT SHARE BAND EDGES -- melee
	// reaches zero at Agility 19, damage and skills at 20 -- so each is read from its own rows and
	// none is inferred from another.
	//
	// Any rating outside every band returns zero, which covers both his "<=0" branch and the open
	// top of each chain without special-casing either.
	export function getOffhandPenalty(tmpkind, tmpagility, tmphandedness) {
		if (("" + (tmphandedness ?? "")) == "Ambidextrous") { return 0; }

		var tmpbands = OFFHAND_PENALTIES[tmpkind];
		if (!tmpbands) { return 0; }

		var tmprating = parseInt(tmpagility) || 0;
		for (const tmpband of tmpbands) {
			if (tmprating >= tmpband[0] && tmprating <= tmpband[1]) { return tmpband[2]; }
		}
		return 0;
	}

	// This is the function which works out what fighting with this weapon in the off hand costs.
	//
	// His handlePhysicalAttacks picks ONE of three tiers per weapon, and they do not stack -- Lore
	// is tested first and stops there:
	//
	//     Second Weapon Lore       -> no penalty at all
	//     Second Weapon Knowledge  -> the full banded penalty, bought down by the skill's levels
	//     neither                  -> the full banded penalty
	//
	// tmpknowledgechance is the "Second Weapon Knowledge" skill's own resolved percentage, ALREADY
	// gated by whether the class has reached the title that makes the discipline available at all
	// -- pass 0 when it has not, exactly as passing no skill in at all would read. This mirrors
	// how getLoreModifiers takes an already-resolved hasWeaponLore rather than re-deriving title
	// eligibility itself; the actor model is where class + title + the skill item all meet.
	//
	// The buy-down (sheet-worker.js:83188-83195): every 20% of the skill's chance removes one
	// point of the melee and damage penalty and 5% of the skill penalty, and the reduction can
	// cancel the penalty but never turn it positive. It starts from the SAME banded tables the
	// full-penalty tier reads -- his setSecondWeaponKnowValues seeds tempOffHandToHit etc. from
	// combat_mod_tohit_offhand and its siblings, which are exactly getOffhandMeleeAdj and its
	// siblings, before subtracting nothing else and adding the levels back on.
	//
	// Returns { offhand, tier, melee, damage, skill }. A weapon that is not in the off hand comes
	// back with tier "none" and three zeroes, so the caller can add these unconditionally.
	export function resolveOffhandPenalties(tmpweapon, tmpagility, tmphandedness, tmpknowledgechance) {
		var tmpout = { offhand: false, tier: "none", melee: 0, damage: 0, skill: 0 };

		var tmpsystem = tmpweapon?.system ?? tmpweapon ?? {};
		if (!isOffhandWeapon(tmpsystem.hand, tmphandedness)) { return tmpout; }
		tmpout.offhand = true;

		if (tmpsystem.secondWeaponLore) {
			tmpout.tier = "lore";
			return tmpout;
		}

		tmpout.melee  = getOffhandPenalty("melee",  tmpagility, tmphandedness);
		tmpout.damage = getOffhandPenalty("damage", tmpagility, tmphandedness);
		tmpout.skill  = getOffhandPenalty("skill",  tmpagility, tmphandedness);

		if (tmpsystem.secondWeaponKnowledge) {
			tmpout.tier = "knowledge";
			var tmplevels = Math.floor((parseInt(tmpknowledgechance) || 0) / 20);
			if (tmplevels > 0) {
				tmpout.melee  = Math.min(0, tmpout.melee  + tmplevels);
				tmpout.damage = Math.min(0, tmpout.damage + tmplevels);
				tmpout.skill  = Math.min(0, tmpout.skill  + (tmplevels * 5));
			}
		} else {
			tmpout.tier = "full";
		}
		return tmpout;
	}

	// This is the function which says which off-hand discipline, if any, a character holds in one
	// particular weapon -- the two flags resolveOffhandPenalties reads off the weapon.
	//
	// HELD PER WEAPON, NAMED ON THE CHARACTER. His sheet keeps one comma-separated list of
	// simplified weapon names for each discipline (second_know_list / second_lore_list), and a
	// weapon's own weaponN_2weapknow / weaponN_2weaplore flag is only ever switched on by finding
	// its name in that list -- handleSecondWeaponKnow and checkEquippedWeaponsAgainstSecondWeapon-
	// KnowList (sheet-worker.js:90648, 90855) both clear the flag when the name is missing. So the
	// list is the authority, and the flag is worked out from it here rather than stored.
	//
	// Holding the discipline at all is title eligibility, already resolved on the actor, exactly
	// as getLoreModifiers takes hasWeaponLore. A name on the list does nothing before the title.
	//
	//   tmpinput = {
	//       weaponName:               the weapon's name, customised or not
	//       hasSecondWeaponKnowledge: the class has reached the title for it
	//       hasSecondWeaponLore:      the class has reached the title for it
	//       secondWeaponKnowList:     his comma-separated list, or an array of names
	//       secondWeaponLoreList:     the same for Lore
	//   }
	//
	// Returns { secondWeaponKnowledge, secondWeaponLore }, both false when nothing applies.
	export function getSecondWeaponFlags(tmpinput) {
		var tmpknowlist = parseLoreList(tmpinput.secondWeaponKnowList);
		var tmplorelist = parseLoreList(tmpinput.secondWeaponLoreList);
		return {
			secondWeaponKnowledge: !!tmpinput.hasSecondWeaponKnowledge && isWeaponLored(tmpinput.weaponName, tmpknowlist),
			secondWeaponLore:      !!tmpinput.hasSecondWeaponLore      && isWeaponLored(tmpinput.weaponName, tmplorelist)
		};
	}

	// This is the function which gives how many more weapons a character may name for one of the
	// two off-hand disciplines. One weapon per title held in it, counting the title it was
	// acquired at -- his practitionerTitle, ((currentTitle-whenAcquired)+1) -- less the weapons
	// already named (set2ndWeaponKnowSheet, sheet-worker.js:49935). Can go negative, which is how
	// his sheet shows a list that has outgrown the title; it is reported, not trimmed.
	export function getSecondWeaponSlots(tmptitle, tmpwhenacquired, tmplist) {
		var tmpwhen = parseInt(tmpwhenacquired) || 0;
		if (tmpwhen == 0) { return 0; }                 // this class never acquires it
		var tmppractitioner = ((parseInt(tmptitle) || 0) - tmpwhen) + 1;
		if (tmppractitioner < 0) { tmppractitioner = 0; }
		return tmppractitioner - parseLoreList(tmplist).length;
	}

	// This is the function which gives how many of the round's ten seconds a character may spend
	// on off-hand actions (Player's Guide, "Timing in the Combat Round"): 5 by default, one more
	// for every 20% of Second Weapon Lore up to 5 extra, never past 10. An Ambidextrous character
	// already has the full 10 seconds in each hand, so the skill has nothing to add for them --
	// setSecondWeaponLoreValues (sheet-worker.js:83242-83250) writes 0 extra seconds in that case
	// rather than the level count, which is why this returns 10 outright instead of 5 + levels.
	//
	// This is the cap itself, not a pool spent down through a round -- nothing here tracks how
	// many of those seconds have been used yet.
	export function getOffhandSecondsCap(tmphandedness, tmploreschance) {
		if (("" + (tmphandedness ?? "")) == "Ambidextrous") { return 10; }
		var tmplevels = Math.min(5, Math.floor((parseInt(tmploreschance) || 0) / 20));
		return 5 + tmplevels;
	}

	// This is the function which gives one area's Endurance: the character's Endurance times the
	// area's multiplier, rounded up with his +0.99 idiom (createBodyAreas, sheet-worker.js:180250).
	export function getAreaEndurance(tmpendurance, tmpmultiplier) {
		return parseInt((tmpendurance * tmpmultiplier) + 0.99) || 0;
	}

	// This is the function which applies damage that has already got past the armour to one
	// area, and reports what it means. Ported from handleBodyDamage (sheet-worker.js:71368-71404).
	//
	//   tmpinput = {
	//       damage:        damage getting through
	//       areaWounds:    wounds already on this area
	//       areaEndurance: this area's Endurance
	//       vitality:      the character's Vitality rating
	//       totalWounds:   wounds across the whole body before this hit
	//       shock:         the character's Shock; 0 means immune to shock
	//   }
	//
	// Wounds on an area are capped at its Endurance plus Vitality. Past the area's Endurance a
	// Vitality save is needed; past Endurance plus Vitality the area's effect is triggered (a limb
	// disabled, a vital area lethal). Total wounds over Shock put the character into shock.
	// Anything over 9 points pierces the armour.
	export function applyAreaDamage(tmpinput) {
		var tmpdamage = parseInt(tmpinput.damage) || 0;
		var tmpwounds = parseInt(tmpinput.areaWounds) || 0;
		var tmpend = parseInt(tmpinput.areaEndurance) || 0;
		var tmpvit = parseInt(tmpinput.vitality) || 0;
		var tmpcap = tmpend + tmpvit;

		var tmpnewwounds = tmpwounds;
		var tmptotal = parseInt(tmpinput.totalWounds) || 0;
		if (tmpdamage > 0) {
			tmpnewwounds = tmpwounds + tmpdamage;
			if (tmpnewwounds > tmpcap) { tmpnewwounds = tmpcap; }
			tmptotal = tmptotal + tmpdamage;
		}

		var tmpeffect = false;
		var tmpvitsave = false;
		if ((tmpdamage + tmpwounds) > tmpcap)      { tmpeffect = true; }
		else if ((tmpdamage + tmpwounds) > tmpend) { tmpvitsave = true; }

		var tmpshock = parseInt(tmpinput.shock) || 0;
		var tmpinshock = (tmpshock != 0) && (tmptotal > tmpshock);

		return {
			wounds: tmpnewwounds,
			totalWounds: tmptotal,
			vitalitySaveNeeded: tmpvitsave,
			effectTriggered: tmpeffect,
			inShock: tmpinshock,
			armorPierced: tmpdamage > 9   // more than 9 through: the armour is pierced (printed on the damage card)
		};
	}


//==================================================================================================================
// @MARKER WEAPON AND MISSILE LORE
//==================================================================================================================

	// This is the function which strips a customised item name back to the name his lore lists
	// are keyed by. Ported from getSimplifiedName (sheet-worker.js).
	//
	// He writes a customised item as "...{Base Name}...", and everything outside the braces is
	// decoration. A name with no braces is already simple and comes back unchanged.
	export function getSimplifiedName(tmpcomplexname) {
		var tmpname = "" + (tmpcomplexname ?? "");
		if (tmpname == "undefined") { tmpname = ""; }
		var tmpopen = tmpname.lastIndexOf("{");
		var tmpclose = tmpname.lastIndexOf("}");
		if (tmpclose > tmpopen + 1) { return tmpname.slice(tmpopen + 1, tmpclose); }
		return tmpname;
	}

	// This is the function which reads one of his lore lists into names.
	// He keeps each as a single comma-separated string; blanks and stray spaces are dropped so a
	// trailing comma or a typed space cannot become an entry that matches nothing.
	export function parseLoreList(tmplist) {
		if (Array.isArray(tmplist)) { return tmplist.map(n => ("" + n).trim()).filter(n => n); }
		return ("" + (tmplist ?? "")).split(",").map(n => n.trim()).filter(n => n);
	}

	// This is the function which says whether a character has a lore skill yet.
	//
	// A class carries the title at which it acquires each, and zero means it never does -- true
	// of 59 of his 92 classes for Weapon Lore and 70 for Missile Lore.
	//
	// The test follows the ONE call site he wrote correctly, `(currentTitle+1)>whenAcquired`
	// (sheet-worker.js:82558), which for whole titles is exactly `title >= when`. Seven other
	// gates on the same two lores are written `currentTitle=>whenAcquired`, which builds an arrow
	// function instead of comparing and is therefore always true -- docs/UPSTREAM-ISSUES.md item
	// 19. Those are not reproduced: where his own code contradicts itself, the half that is
	// written correctly is the half that states the intent.
	export function hasLore(tmptitle, tmpwhenacquired) {
		var tmpwhen = parseInt(tmpwhenacquired) || 0;
		if (tmpwhen == 0) { return false; }          // this class never acquires it
		return (parseInt(tmptitle) || 0) >= tmpwhen;
	}

	// This is the function which says whether one weapon is specifically lored.
	// His lists hold SIMPLIFIED names, so the weapon's name is simplified before matching
	// (checkEquippedWeaponsAgainstWeaponLoreList, sheet-worker.js:90780).
	export function isWeaponLored(tmpweaponname, tmplorelist) {
		var tmpsimple = getSimplifiedName(tmpweaponname);
		if (!tmpsimple) { return false; }
		for (const tmpentry of tmplorelist ?? []) {
			if (getSimplifiedName(tmpentry) == tmpsimple) { return true; }
		}
		return false;
	}

	// What lore is worth. From the modifier list his sheet builds (sheet-worker.js:82559-82572
	// for Weapon Lore, 82592-82605 for Missile), and confirmed against the weapon-speed path.
	//
	// These are TOTALS, not additions on top of one another. A specifically lored weapon gets +3
	// to hit, NOT +2 general and +3 again -- his own comment in
	// getWeaponSpeedListingAdjustmentForModifier says so of the speed: "only give a -1 more, -1
	// is already accounted for in the general mod", making the lored weapon's total -2.
	//
	//            attack  damage  speed  skills
	export const LORE_GENERAL  = { attack: 2, damage: 4, speed: -1, skills: 10 };
	export const LORE_SPECIFIC = { attack: 3, damage: 6, speed: -2, skills: 20 };

	// This is the function which gives what lore is worth for one weapon in one attack.
	//
	// Weapon Lore covers melee, Missile Lore covers missile, and neither touches the other. A
	// character with the lore gets the general figures for every weapon of that kind, and the
	// larger specific figures instead for a weapon named in the matching list.
	//
	// Returns { attack, damage, speed, skills, specific } -- all zero when the lore is not held.
	export function getLoreModifiers(tmpinput) {
		var tmpismissile = !MELEE_MODES.includes(tmpinput.mode);
		var tmphas = tmpismissile ? tmpinput.hasMissileLore : tmpinput.hasWeaponLore;
		if (!tmphas) { return { attack: 0, damage: 0, speed: 0, skills: 0, specific: false }; }

		var tmplist = parseLoreList(tmpismissile ? tmpinput.missileLoreList : tmpinput.weaponLoreList);
		var tmpspecific = isWeaponLored(tmpinput.weaponName, tmplist);
		var tmpvalues = tmpspecific ? LORE_SPECIFIC : LORE_GENERAL;
		return { ...tmpvalues, specific: tmpspecific };
	}

	// @MARKER PROJECTILE LORE
	// Projectile Lore is the odd one of the lore family: it is worth damage PER DIE rather than a
	// flat figure, and it attaches to the ammunition rather than to the weapon in hand. A bow's
	// lore is read off the arrow it normally fires.

	// This is the function which reads the number of dice off a damage string.
	// Ported from getNumberOfDice: everything before the first "d". "2d6" is two dice, "8" is
	// none at all, which is what makes a flat-damage weapon get nothing from Projectile Lore.
	export function getNumberOfDice(tmpdicestring) {
		var tmpstring = "" + (tmpdicestring ?? "");
		var tmpat = tmpstring.indexOf("d");
		if (tmpat < 1) { return 0; }
		return parseInt(tmpstring.slice(0, tmpat)) || 0;
	}

	// This is the function which walks one of his ordered name chains and returns the first match.
	// The order is the whole point: "Bolted" is tested before "Bolt", so a bolted-leather piece
	// does not read as a crossbow bolt. See the tables' comment in module/combat-tables.mjs.
	function matchWeaponName(tmpname, tmpchain) {
		var tmpweapon = getSimplifiedName(tmpname);
		for (const [tmpsubstring, tmpvalue] of tmpchain) {
			if (tmpweapon.includes(tmpsubstring)) { return tmpvalue; }
		}
		return null;
	}

	// This is the function which says whether a weapon is ammunition -- an arrow, a bolt, a rock.
	export function isProjectileWeapon(tmpname) {
		return matchWeaponName(tmpname, PROJECTILE_MATCHES) === true;
	}

	// This is the function which says whether a weapon launches ammunition -- a bow, a crossbow.
	export function isLauncherWeapon(tmpname) {
		return matchWeaponName(tmpname, LAUNCHER_MATCHES) === true;
	}

	// This is the function which gives the projectile a launcher normally fires, so a Long Bow's
	// Projectile Lore is looked up against its Arrow. Returns "" for anything not a launcher.
	export function getProjectileForLauncher(tmpname) {
		return matchWeaponName(tmpname, LAUNCHER_PROJECTILE) ?? "";
	}

	// @MARKER MULTIPLE MISSILE FIRE
	// Firing more than one missile at a time, and the two skills that pay the penalty down.
	//
	// The penalties are the Player's Guide's, under "Unconventional Attacks" (p.182), and his
	// sheet's three situational checkboxes carry exactly the same figures
	// (sheet-worker.js:73015-73017), so book and sheet agree here and nothing had to be chosen.

	// The three ways of firing more than once at a time.
	//
	//                                            shots  attack  damage  repeats
	//                                            -----  ------  ------  -------
	export const MULTI_MISSILE_MODES = {
		twoWeapons:       { label: "Two weapons at once",  shots: 2, attack: -4, damage: 0,   repeats: false },
		twoProjectiles:   { label: "Two projectiles",      shots: 2, attack: -4, damage: -6,  repeats: true },
		threeProjectiles: { label: "Three projectiles",    shots: 3, attack: -8, damage: -12, repeats: true }
	};

	// What each 25% of Multiple Missile Knowledge buys back. Master's Manual, the skill's own
	// General Usage: "For every 25% of the skill chance, the penalties are removed by -1 for hit
	// rolls and -2 for damage rolls" -- and his sheet reads the same, floor(chance/25) levels with
	// the bonus capped at the penalty it is cancelling (sheet-worker.js:64672-64684).
	//
	// Note the 25, where every other skill in the system steps at 20. It is the skill's own text
	// and his code both, so it is not a typo in either.
	export const MULTI_MISSILE_PER_LEVEL = { attack: 1, damage: 2 };

	// "Firing two weapons at once, one in each hand" costs -4 "(ambidextrous or not) in addition to
	// the normal off-hand weapon penalties" (Player's Guide, p.182). The parenthesis is the point:
	// an Ambidextrous character escapes the off-hand penalty and does NOT escape this one, so the
	// two are added independently and this function knows nothing about handedness.

	// This is the function which reads a list of learned launcher/missile combinations.
	//
	// Both skills are learned per combination rather than once: "A skill roll is required to learn
	// each particular combination of missile weapon type and projectile type... if the skill user
	// goes and gets her arrows barbed she will have to reroll". His sheet stores them exactly as it
	// stores a lore list -- one comma-separated string -- with each entry a "Launcher/Missile" pair
	// and the launcher reading "Thrown" for a weapon thrown from the hand.
	export function parseMissileCombos(tmplist) {
		var tmpout = [];
		for (const tmpentry of parseLoreList(tmplist)) {
			var tmpat = tmpentry.indexOf("/");
			if (tmpat < 1) { continue; }
			tmpout.push({
				launcher: tmpentry.slice(0, tmpat).trim(),
				missile: tmpentry.slice(tmpat + 1).trim()
			});
		}
		return tmpout;
	}

	// This is the function which says whether a learned combination covers the weapon in hand.
	//
	// The weapon may be either half of the pair: a character firing a Long Bow and a character
	// holding the Arrow it fires are both covered by "Long Bow/Arrow". A pair whose two halves do
	// not actually go together covers nothing, which is what stops a mistyped combo from applying
	// to every bow in the game.
	//
	// His fourth and fifth match branches (sheet-worker.js:64699-64703) are for a launcher loaded
	// with something other than its normal ammunition -- his switchedProjectiles path. Nothing in
	// this port switches a launcher's ammunition yet, so those two are deliberately not ported
	// rather than half-built.
	export function hasMissileCombo(tmpweaponname, tmpcombos) {
		var tmpweapon = getSimplifiedName(tmpweaponname);
		if (!tmpweapon) { return false; }

		for (const tmpcombo of tmpcombos ?? []) {
			var tmpnormal = getProjectileForLauncher(tmpcombo.launcher);
			if (tmpweapon == tmpcombo.launcher && tmpnormal == tmpcombo.missile) { return true; }
			if (tmpweapon == tmpcombo.missile) {
				if (tmpcombo.launcher == "Thrown") { return true; }
				if (tmpnormal == tmpcombo.missile) { return true; }
			}
		}
		return false;
	}

	// This is the function which works out what firing more than one missile costs this character.
	//
	//   tmpinput = {
	//       mode:        a key of MULTI_MISSILE_MODES, or "" for an ordinary single shot
	//       weaponName:  the weapon being fired
	//       knowChance:  the character's own Multiple Missile Knowledge percentage
	//       knowList:    the combinations learned with Knowledge
	//       loreList:    the combinations learned with Lore
	//   }
	//
	// The tiers do not stack, and Lore is tested first, exactly as the off-hand skills resolve:
	//
	//     Multiple Missile Lore       -> no penalty at all, for a learned combination
	//     Multiple Missile Knowledge  -> the penalty, bought down 1/2 per 25% of the skill
	//     neither                     -> the full penalty
	//
	// A combination that has not been learned pays full whatever the skill percentage is, because
	// the skill is learned per combination rather than held in general -- which is why both lists
	// are passed rather than a pair of booleans.
	//
	// Returns { attack, damage, shots, repeats, tier, levels }. An ordinary shot comes back with
	// tier "none" and zeroes, so the caller can add these unconditionally.
	export function resolveMultiMissile(tmpinput) {
		var tmpmode = MULTI_MISSILE_MODES[tmpinput?.mode];
		if (!tmpmode) {
			return { attack: 0, damage: 0, shots: 1, repeats: false, tier: "none", levels: 0 };
		}

		var tmpout = {
			attack: tmpmode.attack, damage: tmpmode.damage,
			shots: tmpmode.shots, repeats: tmpmode.repeats,
			tier: "full", levels: 0
		};

		if (hasMissileCombo(tmpinput.weaponName, parseMissileCombos(tmpinput.loreList))) {
			tmpout.tier = "lore";
			tmpout.attack = 0;
			tmpout.damage = 0;
			return tmpout;
		}

		if (hasMissileCombo(tmpinput.weaponName, parseMissileCombos(tmpinput.knowList))) {
			tmpout.tier = "knowledge";
			tmpout.levels = Math.floor((parseInt(tmpinput.knowChance) || 0) / 25);
			if (tmpout.levels > 0) {
				tmpout.attack = Math.min(0, tmpout.attack + (tmpout.levels * MULTI_MISSILE_PER_LEVEL.attack));
				tmpout.damage = Math.min(0, tmpout.damage + (tmpout.levels * MULTI_MISSILE_PER_LEVEL.damage));
			}
		}
		return tmpout;
	}

	// @MARKER ACQUIRING A MULTIPLE MISSILE COMBINATION
	// Both skills are learned one launcher/missile pair at a time, by a skill roll against the
	// skill's own chance. Ported from handleRollMultiMissileKnow (sheet-worker.js:88805) and
	// handleRollMultiMissileLore (88950), which are identical apart from which list and chance
	// they read. This only resolves the pure outcome of one roll; rolling the die, reading the
	// character's own chance and writing the list back are the caller's job (see the Combat tab
	// button this needs -- reported to the coordinator, since neither
	// templates/actor/tab-combat.hbs nor the rest of module/sheets/actor-character-sheet.mjs is
	// this workstream's file).
	//
	// NOTE FOR THE COORDINATOR: docs/sonnet/2026-09-16-multi-missile.md item 1 says the skills
	// "carry the skills' Critical Failure rule: a failed attempt locks that specific combination
	// out until the skill chance increases." No such lockout exists in either function above --
	// there is no failed-attempt list anywhere in sheet-worker.js or the sheet's own attributes,
	// and a failed roll does nothing but report failure, the same as an ordinary skill check. His
	// generic "Critical Failure" result (sheet-worker.js:29439, more than 20 over the chance) is
	// not even tested in either function -- both branch only on originalRoll>totalChance. Ported
	// as his code actually reads; the lockout is not implemented here because it is not there to
	// port. Worth asking him directly whether he meant to write it and did not, or the note's
	// author was thinking of a different skill.

	// His isWeaponThrown (sheet-worker.js:86481-86533): an ordered chain of name substrings, the
	// same shape as PROJECTILE_MATCHES in combat-tables.mjs. NOT added to that file because it is
	// a GENERATED file (see its own header) with no entry for this function in
	// tools/extract/extract_combat_tables.py's source list, which this workstream does not own
	// either -- so it is hand-kept here instead, in the same order-matters spirit.
	//
	// THE ORDER MATTERS and is preserved exactly. "Dagger" is tested before "Dagger(Parrying)" and
	// "Dagger(Throwing)", which his own chain can therefore never reach -- the same kind of
	// unreachable branch already documented on getSizeWeightMultiplier above, left rather than
	// guessed at.
	const THROWN_WEAPON_MATCHES = [
		"Pebble(Fairy Sling)", "Bullet(Fairy Sling)", "Rock(Sling)", "Rock(Wrist Sling)",
		"Fairy Knife", "Fairy Dagger", "Fairy Hand Axe", "Fairy Hand Hammer", "Fairy Spear",
		"Giant Knife", "Giant Dagger", "Giant Hand Axe", "Giant Hand Hammer", "Giant Spear",
		"Titan Spear", "Dart(Blow Gun)", "Javelin(Wood)", "Stick(Throwing)",
		"Chakram(Edged Rings)", "Throwing Star", "Dagger", "Dagger(Parrying)", "Dagger(Throwing)",
		"Knife", "Hand Axe", "Hand Hammer", "Hooked Net", "Javelin", "Spear", "Spear Sword",
		"Stake", "Stake Staff", "Trident", "Caltrops(Calvary)", "Caltrops(Footmen)",
		"Cloak(Hooked)", "Cloak(Weighted)", "Bola", "Boomerang(Metal)", "Boomerang(Wood)",
		"Knife(Obsidian)", "Knife(Stone)", "Heroic Dagger", "Heroic Spear", "Shot(Ballista)",
		"Shot(Heavy Ballista)", "Shot(Light Ballista)", "Boulder(Catapult)",
		"Greek Fire(Catapult)", "Boulder(Trebuchet)"
	];

	// This is the function which says whether a weapon is thrown as a missile in its own right --
	// a dagger, a hand axe, a javelin -- rather than being launched from something else.
	export function isThrownWeapon(tmpname) {
		var tmpweapon = "" + (tmpname ?? "");
		for (const tmpsubstring of THROWN_WEAPON_MATCHES) {
			if (tmpweapon.includes(tmpsubstring)) { return true; }
		}
		return false;
	}

	// His simplifyProjectileName (sheet-worker.js:87083-87105): trims a projectile's name to
	// everything before its first ")" or "/", whichever comes first -- "Arrow(Long Bow/Broadhead)"
	// and "Arrow(Long Bow/Normal)" both simplify to "Arrow(Long Bow", which is what lets one
	// launcher match every arrowhead variant fired from it.
	function simplifyProjectileName(tmpname) {
		var tmpstring = "" + (tmpname ?? "");
		for (var tmpi = 0; tmpi < tmpstring.length; tmpi++) {
			if (tmpstring[tmpi] == ")" || tmpstring[tmpi] == "/") { return tmpstring.slice(0, tmpi); }
		}
		return tmpstring;
	}

	// His getLauncherFromProjectile (sheet-worker.js:86842-86939): an ordered chain like the one
	// above, hand-kept here for the same reason. A projectile can name more than one launcher (a
	// Bolt(Crossbow) fires from four Crossbow variants), so the right side is an array here rather
	// than the comma-joined string his own sheet reads with .includes() -- an array of exact names
	// does the same matching without the comma-parsing.
	const MISSILE_LAUNCHER_MATCHES = [
		["Arrow(Fairy Composite Bow", ["Fairy Composite Bow"]],
		["Arrow(Fairy Great Bow", ["Fairy Great Bow"]],
		["Arrow(Fairy Long Bow", ["Fairy Long Bow"]],
		["Arrow(Fairy Short Bow", ["Fairy Short Bow"]],
		["Arrow(Fairy Hand Crossbow", ["Fairy Hand Crossbow"]],
		["Arrow(Fairy Heavy Crossbow", ["Fairy Heavy Crossbow"]],
		["Arrow(Fairy Crossbow", ["Fairy Crossbow"]],
		// Not in his chain. His panel and his prices call the fairy crossbow bolts "Arrow(Fairy ...
		// Crossbow/...)", and so does this chain; his VALUES call them "Bolt(...)" (79792 on), and the
		// weapons pack, built from his values, holds only the Bolt spelling. So the Bolt that is actually
		// bought or dropped on a sheet finds its crossbow too (module/shop-rules.mjs @MARKER NAME ALIASES).
		["Bolt(Fairy Hand Crossbow", ["Fairy Hand Crossbow"]],
		["Bolt(Fairy Heavy Crossbow", ["Fairy Heavy Crossbow"]],
		["Bolt(Fairy Crossbow", ["Fairy Crossbow"]],
		["Pebble(Fairy Sling)", ["Fairy Sling"]],
		["Bullet(Fairy Sling)", ["Fairy Sling"]],
		["Arrow(Giant Short Bow", ["Giant Short Bow"]],
		["Arrow(Giant Long Bow", ["Giant Long Bow"]],
		["Arrow(Giant Great Bow", ["Giant Great Bow"]],
		["Arrow(Titan Bow", ["Titan Bow"]],
		["Arrow(Long Bow", ["Bow(Long)"]],
		["Arrow(Composite Bow", ["Bow(Composite)"]],
		["Arrow(Compound Bow", ["Bow(Compound)"]],
		["Arrow(Great Bow", ["Bow(Great)"]],
		["Arrow(Horn Bow", ["Bow(Horn)"]],
		["Arrow(Recurve Bow", ["Bow(Recurve)"]],
		["Arrow(Short Bow", ["Bow(Short)"]],
		["Arrow(Welsh Bow", ["Bow(Welsh)"]],
		["Ball(Cannon)", ["Cannon(Early)", "Cannon", "Cannon(Heavy)"]],
		["Grape Shot(Cannon)", ["Cannon(Early)", "Cannon", "Cannon(Heavy)"]],
		["Exploding(Cannon)", ["Cannon(Early)", "Cannon", "Cannon(Heavy)"]],
		["Lead Ball(Early Gun)", ["Early Derringer", "Single Shot Pistol", "Blunder Buss", "Long Rifle"]],
		["Bolt(Heavy Crossbow", ["Crossbow(Heavy)", "Crossbow(Heavy/Double)", "Crossbow(Heavy/Over-Under)", "Crossbow(Heavy/Repeating)"]],
		["Bolt(Hand Crossbow", ["Crossbow(Hand)", "Crossbow(Hand/Double)", "Crossbow(Hand/Over-Under)", "Crossbow(Hand/Repeating)"]],
		["Bolt(Crossbow", ["Crossbow", "Crossbow(Double)", "Crossbow(Over-Under)", "Crossbow(Repeating)"]],
		["Rock(Sling", ["Sling"]],
		["Rock(Wrist Sling", ["Wrist Sling"]],
		["Bullet(Sling", ["Sling"]],
		["Bullet(Wrist Sling", ["Wrist Sling"]],
		["Arrow(Primitive Bow", ["Bow(Primitive)"]],
		["Dart(Blow Gun", ["Blow Gun"]],
		["Javelin(Wood)", ["At’alta(Javelin Thrower)"]],
		["Stick(Throwing)", ["At’alta(Javelin Thrower)"]],
		["Bolt(Ballista", ["Ballista"]],
		["Shot(Ballista", ["Ballista"]],
		["Bolt(Heavy Ballista", ["Ballista(Heavy)"]],
		["Shot(Heavy Ballista", ["Ballista(Heavy)"]],
		["Bolt(Light Ballista", ["Ballista(Light)"]],
		["Shot(Light Ballista", ["Ballista(Light)"]],
		["Boulder(Catapult)", ["Catapult"]],
		["Greek Fire(Catapult)", ["Catapult"]],
		["Boulder(Trebuchet)", ["Trebuchet"]],
		["Greek Fire(Trebuchet)", ["Trebuchet"]]
	];

	// This is the function which reads the launcher(s) a given projectile is fired from.
	export function getLaunchersForProjectile(tmpname) {
		var tmpsimple = simplifyProjectileName("" + (tmpname ?? ""));
		for (const [tmpsubstring, tmplaunchers] of MISSILE_LAUNCHER_MATCHES) {
			if (tmpsimple.includes(tmpsubstring)) { return tmplaunchers; }
		}
		return [];
	}

	// This is the function which says whether a chosen launcher and missile go together at all --
	// his comboMatch, tested before a combination can be learned. Neither list nor chance matters
	// here; this only says the pair is a real combination. His three-branch if/else-if (thrown,
	// then ammunition, then launcher-named-directly) collapses to this because the last two
	// branches run the identical check.
	export function isValidMissileCombo(tmpLauncher, tmpMissile) {
		var tmplauncher = ("" + (tmpLauncher ?? "")).trim();
		var tmpmissile = ("" + (tmpMissile ?? "")).trim();
		if (!tmplauncher || !tmpmissile) { return false; }

		if (isThrownWeapon(tmpmissile)) { return tmplauncher == "Thrown"; }
		if (isProjectileWeapon(tmpmissile) || isLauncherWeapon(tmplauncher)) {
			return getLaunchersForProjectile(tmpmissile).includes(tmplauncher);
		}
		return false;
	}

	// This is the function which works out the pure outcome of one acquisition roll, in his own
	// early-exit order: no launcher chosen, the combo already known, no missile chosen, the pair
	// does not go together, the skill chance is under 1%, then pass or fail against the chance.
	// His "isAutomatic" branch (a Game Master override for a creature) is left out -- this is the
	// character flow, and a creature's override belongs with the creature sheet that reads it.
	//
	//   tmpinput = {
	//       launcher:  the launcher chosen, or "Thrown" for a weapon thrown from the hand
	//       missile:   the missile chosen
	//       chance:    the character's own chance in this skill, Knowledge or Lore
	//       list:      the combinations already learned, his comma-separated string
	//       roll:      the 1d100 already rolled
	//   }
	//
	// Returns { outcome, reason, list }. outcome is one of "noLauncher", "noMissile",
	// "alreadyKnown", "invalidCombo", "noChance", "failed", "succeeded" -- list carries the
	// combination forward ONLY on success, and is the input list unchanged otherwise.
	export function resolveMissileComboAcquisition(tmpinput) {
		var tmplauncher = ("" + (tmpinput?.launcher ?? "")).trim();
		var tmpmissile = ("" + (tmpinput?.missile ?? "")).trim();
		var tmpchance = parseInt(tmpinput?.chance) || 0;
		var tmpcombos = parseMissileCombos(tmpinput?.list);
		var tmproll = parseInt(tmpinput?.roll) || 0;
		var tmpentry = tmplauncher + "/" + tmpmissile;
		var tmpout = { outcome: "", reason: "", list: tmpinput?.list ?? "" };

		if (!tmplauncher) {
			tmpout.outcome = "noLauncher";
			tmpout.reason = "No launcher was selected. Nothing done.";
		} else if (tmpcombos.some(tmpcombo => tmpcombo.launcher == tmplauncher && tmpcombo.missile == tmpmissile)) {
			tmpout.outcome = "alreadyKnown";
			tmpout.reason = `${tmpentry} is already known. Nothing done.`;
		} else if (!tmpmissile) {
			tmpout.outcome = "noMissile";
			tmpout.reason = "No missile was selected. Nothing done.";
		} else if (!isValidMissileCombo(tmplauncher, tmpmissile)) {
			tmpout.outcome = "invalidCombo";
			tmpout.reason = `${tmplauncher} and ${tmpmissile} do not go together. Nothing done.`;
		} else if (tmpchance < 1) {
			tmpout.outcome = "noChance";
			tmpout.reason = "There is no chance to acquire this, even if attempted. Nothing done.";
		} else if (tmproll > tmpchance) {
			tmpout.outcome = "failed";
			tmpout.reason = `Rolled ${tmproll}% against a ${tmpchance}% chance. Failed.`;
		} else {
			tmpout.outcome = "succeeded";
			tmpout.reason = `Rolled ${tmproll}% against a ${tmpchance}% chance. Succeeded.`;
			tmpout.list = tmpout.list ? `${tmpout.list},${tmpentry}` : tmpentry;
		}
		return tmpout;
	}

	// This is the function which gives Projectile Lore's damage for one attack.
	// Ported from handlePhysicalAttacks (sheet-worker.js:64518-64545 and 64990).
	//
	// It applies only to a launcher or to ammunition, and only to a character who has the lore.
	// The projectile checked is the ammunition itself, or the one the launcher normally fires.
	// Worth +1 per damage die generally, +2 per die for a projectile named in the list -- and as
	// with the other lores the specific figure REPLACES the general one rather than adding to it.
	//
	// Returns { damage, perDie, dice, projectile, specific }.
	export function getProjectileLoreDamage(tmpinput) {
		var tmpout = { damage: 0, perDie: 0, dice: 0, projectile: "", specific: false };
		if (!tmpinput.hasProjectileLore) { return tmpout; }

		var tmplauncher = isLauncherWeapon(tmpinput.weaponName);
		var tmpammo = isProjectileWeapon(tmpinput.weaponName);
		if (!tmplauncher && !tmpammo) { return tmpout; }

		tmpout.projectile = tmplauncher
			? getProjectileForLauncher(tmpinput.weaponName)
			: getSimplifiedName(tmpinput.weaponName);

		tmpout.specific = isWeaponLored(tmpout.projectile, tmpinput.projectileLoreList);
		tmpout.perDie = tmpout.specific ? 2 : 1;
		tmpout.dice = getNumberOfDice(tmpinput.damageDice);
		tmpout.damage = tmpout.dice * tmpout.perDie;
		return tmpout;
	}

//==================================================================================================================
// @MARKER TIME
//==================================================================================================================

	// This is the function which gives a character's initiative modifier: the BETTER of the
	// Agility and Intelligence adjustments -- lower is better, and they are not added together --
	// plus armour and anything else. (sheet-worker.js:82366-82372.)
	export function getInitiativeModifier(tmpaglinit, tmpintinit, tmpother) {
		var tmpagl = parseInt(tmpaglinit) || 0;
		var tmpint = parseInt(tmpintinit) || 0;
		return Math.min(tmpagl, tmpint) + (parseInt(tmpother) || 0);
	}

	// This is the function which turns an initiative total into the second of the round a
	// character begins acting in. Lower is earlier. Nobody starts before second 1 -- a negative
	// result only decides who goes first within it -- and every point below -10 buys an extra
	// second of action, up to ten more (Player's Guide, Agility / Initiative Adjustment).
	export function getActingSecond(tmptotal) {
		var tmpvalue = parseInt(tmptotal) || 0;
		var tmpextra = 0;
		if (tmpvalue < -10) { tmpextra = Math.min(10, -10 - tmpvalue); }
		return { second: Math.max(1, tmpvalue), extraSeconds: tmpextra };
	}

	// This is the function which gives how long a swing takes: the weapon's speed plus every
	// speed modifier (Strength, Agility and armour), never below the weapon's minimum speed.
	// (sheet-worker.js:82388-82394.)
	export function getWeaponSpeed(tmpspeed, tmpminspeed, tmpmodifiers) {
		var tmpvalue = (parseInt(tmpspeed) || 0) + (parseInt(tmpmodifiers) || 0);
		var tmpmin = parseInt(tmpminspeed) || 0;
		if (tmpvalue < tmpmin) { tmpvalue = tmpmin; }
		return tmpvalue;
	}

// @MARKER MOVEMENT
//==================================================================================================================
// How far a character travels, at three scales at once: per hour (miles), per 10 second combat
// round (feet), and per second (feet).
//
// A RACE'S MOVEMENT FIGURES ARE MODIFIERS, NOT FINISHED RATES. His calcMovement
// (sheet-worker.js:30856) switches on Agility for a base and ADDS the race's figure to it:
//
//     setAttrs({move_walk_hourly: 2+racetmpwalkhourly+tmpwalktemphourlymod});
//
// so a race carrying 0/0/0 -- Human(Civilized) among them -- is a race with NO MODIFIER, and
// walks at the full base for its Agility. It is not a race that cannot walk. The Player's Guide
// prints the same split on page 36: base tables by Agility, then a separate "Racial Movement
// Modifiers" table, and his Human(Barbaric) row is that table's +1/+10/+1, +2/+20/+2, +2/+30/+3
// to the digit.
//==================================================================================================================

	// This is the function which reads the base distances for an Agility rating.
	//
	// His switch runs 0 to 30 with no default, so a rating above it would leave whatever the
	// previous character's values happened to be. Here the top band is held instead, which is the
	// same answer his sheet gives for 30 and a defined one for anything past it.
	export function getMovementBase(tmpagility) {
		var tmprating = parseInt(tmpagility) || 0;
		if (tmprating < 0) { tmprating = 0; }

		for (const tmpband of MOVEMENT_BASE) {
			if (tmprating >= tmpband[0] && tmprating <= tmpband[1]) { return tmpband[2]; }
		}
		return MOVEMENT_BASE[MOVEMENT_BASE.length - 1][2];
	}

	// This is the function which finishes one movement rate: base for the Agility, plus the race's
	// modifier, times the race's speed multiplier.
	//
	// A speed multiplier of 0 means NO multiplier. That is his sentinel, not a stationary race --
	// calcSpecialMovement says so in as many words: "most races are 0 (this makes the multiplier 1".
	//
	// A NEGATIVE multiplier is ignored the same way, because it is not a coherent quantity: a
	// multiplier scales a rate, it does not reverse its direction. Only Elf(Sea) and Elf(Ice) carry
	// one, both -10, against 0 for the other 103 races, and his own sheet multiplies straight
	// through it into large negative distances. Those two are also the only elves of eleven with no
	// disease-resistance modifier, where every other elf has one -- a -10 in this column beside a
	// hole in the one before it. Read as a mis-keyed cell and skipped; see UPSTREAM-ISSUES.md
	// item 24. They then walk and swim like any other elf, rather than at the floor below.
	//
	// tmpfloor is what a NEGATIVE rate becomes at this scale. The Player's Guide (p.36): a race
	// whose penalties "cause a negative movement rate" has it "reduced to 1 mile (hourly), 10 feet
	// (10 seconds) or 1 foot (1 second)". Only a rate below zero is lifted -- a rate that lands on
	// zero honestly, as Agility 0-1 does, stays zero, which is what his sheet shows.
	//
	// HIS SHEET HAS NO SUCH FLOOR, so a rate pushed below zero is lifted here as the book says. It is
	// no longer what Elf(Sea) and Elf(Ice) land on: their -10 "speed multiplier" is a disease
	// resistance entered one column to the right, and the build moves it back (RACE_VALUE_REPAIRS,
	// tools/extract/column_maps.py; UPSTREAM-ISSUES item 24). A multiplier of zero or less is also read
	// as "none" below, so a stray one cannot reverse a rate. The floor stays for what really reaches
	// it: a Civilized Dwarf at Agility 5 goes under it on walking modifiers alone.
	export function resolveMovementRate(tmpbase, tmpracemod, tmpmultiplier, tmpfloor) {
		var tmpmulti = parseFloat(tmpmultiplier) || 0;
		if (tmpmulti <= 0) { tmpmulti = 1; }

		var tmprate = ((parseFloat(tmpbase) || 0) + (parseFloat(tmpracemod) || 0)) * tmpmulti;
		if (tmprate < 0) { tmprate = tmpfloor; }
		return Math.round(tmprate * 10) / 10;
	}

// @MARKER SPECIAL MOVEMENT
//==================================================================================================================
// The extra rate some races have -- Fly, Gallop, Swim, Scurry, Slither -- which is never written as
// a distance. It is written RELATIVE to another of the character's own rates: the name of a base
// rate, with a multiplier and an additive beside it, for each of the three scales.
//
// From calcSpecialMovement (sheet-worker.js:32110). 26 of his 105 races have one.
//
// THE FIVE KINDS DO NOT SHARE A FORMULA, which is why this is a table rather than one expression:
// only Scurry adds its additive, and Slither alone ignores the race's speed multiplier. Reading
// one kind's shape off another would be wrong for four of the five.
//==================================================================================================================

	// What each kind of special movement does with the additive and the race's speed multiplier.
	// Slither also REPLACES ordinary movement rather than adding to it -- his comment: "Slither is
	// the only movement sssssnake people have", and "Snakes can`t jump".
	const SPECIAL_MOVEMENT_SHAPES = {
		"Fly:":     { usesMod: false, usesSpeedMultiplier: true,  replacesMovement: false },
		"Gallop:":  { usesMod: false, usesSpeedMultiplier: true,  replacesMovement: false },
		"Swim:":    { usesMod: false, usesSpeedMultiplier: true,  replacesMovement: false },
		"Scurry:":  { usesMod: true,  usesSpeedMultiplier: true,  replacesMovement: false },
		"Slither:": { usesMod: false, usesSpeedMultiplier: false, replacesMovement: true  }
	};

	// This is the function which says whether a kind of special movement is the only movement its
	// race has, rather than an extra on top of walking.
	export function specialMovementReplacesOther(tmpname) {
		var tmpshape = SPECIAL_MOVEMENT_SHAPES[("" + (tmpname ?? "")).trim()];
		return tmpshape ? tmpshape.replacesMovement : false;
	}

	// This is the function which works the special rate out into real distances.
	//
	// tmpmovement is the character's ALREADY-RESOLVED walk and run, so "Walk" means this
	// character's finished walking rate rather than the race's modifier.
	//
	// The base rate is named per scale in his data, but his own code branches on the HOURLY name
	// alone and uses it for all three; that is followed here. All 26 races agree across the three
	// anyway, so the two readings cannot currently diverge.
	//
	// A multiplier of 0 means one, the same sentinel as the race speed multiplier.
	//
	// An unrecognised kind or base name resolves to nothing rather than throwing or guessing: a new
	// name in his data is a new fact about his system and should be read before being encoded.
	//
	// ONE DELIBERATE DEPARTURE FROM HIS LIVE CODE, for magical flight. His INT line multiplies by a
	// further literal 30 / 30 / 3 on top of the race's own multiplier (sheet-worker.js:32397). Three
	// things say that is a slip rather than the rule:
	//
	//   - Mephyt(Fire) and Mephyt(Ice), the only two races that use INT, carry per-scale multipliers
	//     of 0.75 / 30 / 3 where every other race's are uniform. Those only make sense applied on
	//     their own -- 30 feet per 10 seconds is exactly ten times 3 feet per second.
	//   - With his extra literals the ten-second rate becomes ONE HUNDRED times the one-second rate
	//     instead of ten, which no other rate in the system does.
	//   - The version commented out directly above that line (32366-32368) is exactly this: the
	//     multiplier alone, with no literal factor.
	//
	// So the multiplier is applied on its own here. This is sheet-versus-sheet rather than
	// sheet-versus-book, so the standing "the sheet wins" rule does not settle it. Two races are
	// affected and it is one line to put back. Logged for him as UPSTREAM-ISSUES.md item 25.
	export function resolveSpecialMovement(tmpname, tmpspecial, tmpmovement, tmpspeedmultiplier, tmpintelligence) {
		var tmpout = { hourly: 0, tenSec: 0, oneSec: 0 };
		if (!tmpspecial || !tmpmovement) { return tmpout; }

		var tmpshape = SPECIAL_MOVEMENT_SHAPES[("" + (tmpname ?? "")).trim()];
		if (!tmpshape) { return tmpout; }

		var tmpbasename = ("" + (tmpspecial.hourly ?? "")).trim().toLowerCase();
		if (tmpbasename != "walk" && tmpbasename != "run" && tmpbasename != "int") { return tmpout; }

		// Magical flight reads Intelligence and takes no speed multiplier -- his comment on the
		// INT branch: "it never has a multiplier, even for speed".
		var tmpspeed = parseFloat(tmpspeedmultiplier) || 0;
		if (tmpspeed <= 0) { tmpspeed = 1; }   // 0 is his "none"; negative is incoherent, see above
		if (!tmpshape.usesSpeedMultiplier || tmpbasename == "int") { tmpspeed = 1; }

		// The same floor the ordinary rates take, for a special rate that modifiers drag below zero. A
		// negative speed multiplier no longer can (it is read as none, above); before the Elf(Sea)
		// and Elf(Ice) -10 was repaired as a disease resistance, it swam them at -150 miles an hour.
		var tmpfloors = { hourly: 1, tenSec: 10, oneSec: 1 };

		for (const tmpscale of ["hourly", "tenSec", "oneSec"]) {
			var tmpmulti = parseFloat(tmpspecial[tmpscale + "Multiplier"]) || 0;
			if (tmpmulti == 0) { tmpmulti = 1; }

			var tmpmod = tmpshape.usesMod ? (parseFloat(tmpspecial[tmpscale + "Mod"]) || 0) : 0;

			var tmpbase = 0;
			if (tmpbasename == "int") {
				tmpbase = parseFloat(tmpintelligence) || 0;
			} else {
				tmpbase = parseFloat((tmpmovement[tmpbasename] ?? {})[tmpscale]) || 0;
			}

			var tmprate = (((tmpbase * tmpmulti) + tmpmod) * tmpspeed);
			if (tmprate < 0) { tmprate = tmpfloors[tmpscale]; }
			tmpout[tmpscale] = Math.round(tmprate * 10) / 10;
		}
		return tmpout;
	}

// @MARKER ENCUMBRANCE
//==================================================================================================================
// Ported from his calcEncumbrance (sheet-worker.js:81745), which both of his sheets call -- the
// character's and the creature's -- so both actor models call resolveEncumbrance below rather
// than each keeping its own copy.
//
// What his function does, in order:
//     1. the four bands: a quarter, half, three quarters and the whole of load limit x body weight
//     2. armour and general equipment are totalled and then scaled by the being's SIZE
//     3. weapons are added unscaled -- his comment: "there are different weapon versions for
//        different sized beings already"
//     4. each item's own weight is scaled by its magical plus (+1 is x.9 down to +10 at x.05)
//     5. the total is read against the bands for his status label
//
// What is NOT ported yet, each needing something the port does not have:
//     - Lighten Load, Spirit of the Donkey and the temporary weight/capacity modifiers -- magic
//       items, which are the deferred magic phase
//
// His sheet stops at the status label. It never slows anyone down: encumbrance_status is written
// and nothing reads it. The Player's Guide does (Encumbrance, p.38) -- 3/4 speed slightly
// encumbered, 1/2 encumbered, 1/4 heavily encumbered and no running or sprinting -- so the speed
// factor is returned beside the label, and the character's sheet shows its movement at the
// current load NEXT TO the unencumbered rates his sheet shows, rather than replacing them. See
// UPSTREAM-ISSUES.md item 31.
//==================================================================================================================

	// His status labels, and the book's penalty for each. "Over weight(cannot move)" is his own
	// wording, and the only place his sheet says anything about movement at all.
	// The penalty text is the Player's Guide's own Encumbrance Table wording, movement half only
	// (fatigue belongs to the fatigue rules, which are not ported).
	const ENCUMBRANCE_BANDS = [
		//  status                         speedFactor  canRun  penalty
		{ status: "Not encumbered",            speedFactor: 1,    canRun: true,  penalty: "" },
		{ status: "Slightly encumbered",       speedFactor: 0.75, canRun: true,  penalty: "3/4 speed" },
		{ status: "Encumbered",                speedFactor: 0.5,  canRun: true,  penalty: "1/2 speed" },
		{ status: "Heavily encumbered",        speedFactor: 0.25, canRun: false, penalty: "1/4 speed, cannot run or sprint" },
		{ status: "Over weight(cannot move)",  speedFactor: 0,    canRun: false, penalty: "cannot move" }
	];

	// His magical-plus weight adjustments (getItemWeight). A plus outside 1-10 has no case in his
	// switch and so weighs as normal.
	const MAGIC_WEIGHT_MULTIPLIERS = {
		// plus: multiplier
		1: 0.9,  2: 0.8,  3: 0.7,  4: 0.6,  5: 0.5,
		6: 0.4,  7: 0.3,  8: 0.2,  9: 0.1,  10: 0.05
	};

	// This is the function which gives the multiplier his calcEncumbrance puts on armour and
	// general equipment for the size of the being carrying it. Six to seven feet is the standard
	// and takes no adjustment; smaller beings carry smaller gear, bigger ones bigger.
	//
	// Height 0 means "not entered", and takes no adjustment. His character creation always sets a
	// height, but a port actor starts at 0, and his ladder would read that as "under one foot" and
	// shrink the whole load to a hundredth. That is the one deliberate difference.
	//
	// Under one foot his code tests weight<21, then weight<20 -- which can never be reached, since
	// anything under 20 is already under 21 -- then everything else. The unreachable branch
	// (x.0075) is left out rather than guessed at; UPSTREAM-ISSUES.md item 31 asks.
	export function getSizeWeightMultiplier(tmpheightinches, tmpbodyweight) {
		var tmpinches = parseInt(tmpheightinches) || 0;
		var tmpweight = parseFloat(tmpbodyweight) || 0;
		if (tmpinches <= 0) { return 1; }

		if (tmpinches < 12) {          // under 1 foot
			return (tmpweight < 21) ? 0.005 : 0.01;
		} else if (tmpinches < 24) {   // under 2 feet
			if (tmpweight < 21) { return 0.02; } else if (tmpweight < 40) { return 0.05; } else { return 0.1; }
		} else if (tmpinches < 36) {   // under 3 feet
			if (tmpweight < 41) { return 0.1; } else if (tmpweight < 80) { return 0.2; } else { return 0.3; }
		} else if (tmpinches < 48) {   // under 4 feet
			if (tmpweight < 61) { return 0.3; } else if (tmpweight < 100) { return 0.4; } else { return 0.5; }
		} else if (tmpinches < 60) {   // under 5 feet
			if (tmpweight < 81) { return 0.5; } else if (tmpweight < 120) { return 0.6; } else { return 0.7; }
		} else if (tmpinches < 72) {   // under 6 feet
			if (tmpweight < 101) { return 0.7; } else if (tmpweight < 150) { return 0.8; } else { return 0.9; }
		} else if (tmpinches < 84) {   // under 7 feet -- the standard, no adjustment
			return 1;
		} else if (tmpinches < 96) {   // under 8 feet
			if (tmpweight < 201) { return 1.0; } else if (tmpweight < 350) { return 1.1; } else { return 1.2; }
		} else if (tmpinches < 108) {  // under 9 feet
			if (tmpweight < 301) { return 1.3; } else if (tmpweight < 500) { return 1.4; } else { return 1.5; }
		} else if (tmpinches < 120) {  // under 10 feet
			if (tmpweight < 401) { return 1.6; } else if (tmpweight < 800) { return 1.7; } else { return 1.8; }
		} else if (tmpinches < 132) {  // under 11 feet
			if (tmpweight < 701) { return 1.9; } else if (tmpweight < 1000) { return 2; } else { return 2.1; }
		}
		// eleven feet and over goes by weight alone
		if (tmpweight < 1501)  { return 2.2; }
		if (tmpweight < 1801)  { return 2.4; }
		if (tmpweight < 2201)  { return 2.6; }
		if (tmpweight < 2801)  { return 2.8; }
		if (tmpweight < 3501)  { return 3; }
		if (tmpweight < 4501)  { return 3.5; }
		if (tmpweight < 6001)  { return 4; }
		if (tmpweight < 8001)  { return 4.5; }
		if (tmpweight < 11001) { return 5; }
		if (tmpweight < 14001) { return 6; }
		if (tmpweight < 20001) { return 7; }
		if (tmpweight < 30001) { return 8; }
		if (tmpweight < 40001) { return 9; }
		return 10;                     // 40001+
	}

	// This is the function which gives the multiplier a magical plus puts on an item's weight.
	export function getMagicWeightMultiplier(tmpplus) {
		return MAGIC_WEIGHT_MULTIPLIERS[parseInt(tmpplus) || 0] ?? 1;
	}

	// His quality-tag weight adjustments (getItemWeight, sheet-worker.js:81979-81990), read off
	// the item's `quality` field rather than parsed out of its name. Average, the blank choice,
	// takes no adjustment. A magical plus REPLACES this rather than stacking with it -- his code
	// only reaches this branch "if not magical" -- so resolveEncumbrance below only applies it
	// when the item's magicBonus is 0.
	const QUALITY_WEIGHT_MULTIPLIERS = {
		// quality:   multiplier
		Shoddy:  1.75,
		Poor:    1.1,
		Good:    0.9,
		High:    0.8,
		Master:  0.75
	};

	// This is the function which gives the multiplier a non-magical item's quality tag puts on
	// its weight. Blank, unrecognised or absent all fall through to 1 (average).
	export function getQualityWeightMultiplier(tmpquality) {
		return QUALITY_WEIGHT_MULTIPLIERS[("" + (tmpquality ?? "")).trim()] ?? 1;
	}

	// This is the function which reads a carried weight against the four bands and returns his
	// label, with the book's speed factor and whether the being can still run.
	export function getEncumbranceBand(tmpcarried, tmpbands) {
		var tmpindex = 4;
		if      (tmpcarried <= tmpbands.none)     { tmpindex = 0; }
		else if (tmpcarried <= tmpbands.slight)   { tmpindex = 1; }
		else if (tmpcarried <= tmpbands.moderate) { tmpindex = 2; }
		else if (tmpcarried <= tmpbands.heavy)    { tmpindex = 3; }
		return ENCUMBRANCE_BANDS[tmpindex];
	}

	// This is the function which works out everything encumbrance-related for one being.
	//
	// tmpitems is the actor's items -- anything with a system.weight. Only what is equipped or
	// carried counts; a mount or a stash is not on the being. A tagalong's weight is already part
	// of another item (a scabbard is part of the sword), so it is skipped.
	// This is the function which says whether a thing weighs nothing to carry, his "[Float]"
	// (sheet-worker.js:81815 and its five siblings, one per carried-item list).
	//
	// HIS MARKER IS IN THE NAME, not in a field: his code asks whether the item's name contains
	// "[Float]", so a player marks a raft or a bladder of air by typing it into the name at the
	// table. No shipped item carries it, which is why it is a marker rather than data. The name
	// check is honoured here so a player who knows his convention gets his behaviour -- and a
	// `floats` field is read as well, which is the tidier way to say the same thing on a sheet
	// with real fields.
	export function itemFloats(tmpitem) {
		if (tmpitem?.system?.floats) { return true; }
		return ("" + (tmpitem?.name ?? "")).toLowerCase().includes("[float]");
	}

	export function resolveEncumbrance(tmpitems, tmploadlimit, tmpbodyweight, tmpheightinches) {
		var tmpmaxload = (parseFloat(tmploadlimit) || 0) * (parseFloat(tmpbodyweight) || 0);
		var tmpsizemulti = getSizeWeightMultiplier(tmpheightinches, tmpbodyweight);

		var tmpscaled = 0;     // armour and general equipment -- scaled by size
		var tmpweapons = 0;    // weapons -- never scaled by size
		for (const tmpitem of (tmpitems ?? [])) {
			var tmpsys = tmpitem.system ?? {};
			if (tmpsys.weight === undefined) { continue; }
			if (tmpsys.isTagalong) { continue; }
			if (itemFloats(tmpitem)) { continue; }
			if (tmpsys.location != "equipped" && tmpsys.location != "carried") { continue; }

			// A magical plus and a quality tag never stack -- his getItemWeight only reads the
			// quality tag "if not magical". Zero is his (and this port's) "not magical".
			var tmpmagicbonus = parseInt(tmpsys.magicBonus) || 0;
			var tmpqualitymulti = (tmpmagicbonus == 0) ? getQualityWeightMultiplier(tmpsys.quality) : 1;

			// A Gravity rune adds or takes off weight -- his getWeaponWeightListingChanges, with the
			// rune's own words for which way (getGravityRune in weapon-custom-rules.mjs).
			var tmpweight = (parseFloat(tmpsys.weight) || 0)
			              * getMagicWeightMultiplier(tmpsys.magicBonus)
			              * tmpqualitymulti
			              * getGravityRune(tmpsys).weightMulti
			              * (tmpsys.quantity ?? 1);
			if (tmpitem.type == "weapon") { tmpweapons = tmpweapons + tmpweight; }
			else                          { tmpscaled  = tmpscaled  + tmpweight; }
		}
		var tmpcarried = (tmpscaled * tmpsizemulti) + tmpweapons;

		var tmpenc = {
			carried:        parseFloat(tmpcarried.toFixed(1)),
			maxLoad:        parseFloat(tmpmaxload.toFixed(1)),
			none:           parseFloat((tmpmaxload * 0.25).toFixed(1)),
			slight:         parseFloat((tmpmaxload * 0.5).toFixed(1)),
			moderate:       parseFloat((tmpmaxload * 0.75).toFixed(1)),
			heavy:          parseFloat(tmpmaxload.toFixed(1)),
			sizeMultiplier: tmpsizemulti
		};
		var tmpband = getEncumbranceBand(tmpcarried, tmpenc);
		tmpenc.status      = tmpband.status;
		tmpenc.speedFactor = tmpband.speedFactor;
		tmpenc.canRun      = tmpband.canRun;
		tmpenc.penalty     = tmpband.penalty;
		return tmpenc;
	}

	// This is the function which gives a being's movement at its current load, per the Player's
	// Guide: every rate times the band's speed factor, and no running at all once heavily
	// encumbered. Special movement is left alone -- flying has encumbrance rules of its own in the
	// book (gliding ratios), which are not a speed factor.
	export function resolveLoadedMovement(tmpmovement, tmpencumbrance) {
		var tmpfactor = tmpencumbrance.speedFactor ?? 1;
		var tmpout = {};
		for (const tmpmode of ["walk", "jog", "run"]) {
			var tmpmodefactor = (tmpmode == "run" && !tmpencumbrance.canRun) ? 0 : tmpfactor;
			tmpout[tmpmode] = {};
			for (const tmpscale of ["hourly", "tenSec", "oneSec"]) {
				var tmprate = (parseFloat((tmpmovement[tmpmode] ?? {})[tmpscale]) || 0) * tmpmodefactor;
				tmpout[tmpmode][tmpscale] = Math.round(tmprate * 10) / 10;
			}
		}
		return tmpout;
	}

// @MARKER ADD NEW combat rule functions HERE
// @END (CODE)
